package com.vyaparai.app

import com.vyaparai.app.domain.usecases.GstCalculationUseCase
import org.junit.Assert.*
import org.junit.Test

class GstCalculationTest {

    @Test
    fun testTaxInclusiveGst() {
        // Price ₹118 with 18% inclusive GST -> Taxable: ₹100, CGST: ₹9, SGST: ₹9, Total: ₹118
        val result = GstCalculationUseCase.calculateItemTax(
            unitPrice = 118.0,
            quantity = 1.0,
            gstRate = 18.0,
            isTaxInclusive = true,
            isInterState = false
        )

        assertEquals(100.0, result.taxableAmount, 0.01)
        assertEquals(9.0, result.cgstAmount, 0.01)
        assertEquals(9.0, result.sgstAmount, 0.01)
        assertEquals(0.0, result.igstAmount, 0.01)
        assertEquals(18.0, result.totalGst, 0.01)
        assertEquals(118.0, result.finalTotal, 0.01)
    }

    @Test
    fun testTaxExclusiveGst() {
        // Price ₹100 with 18% exclusive GST -> Taxable: ₹100, CGST: ₹9, SGST: ₹9, Total: ₹118
        val result = GstCalculationUseCase.calculateItemTax(
            unitPrice = 100.0,
            quantity = 1.0,
            gstRate = 18.0,
            isTaxInclusive = false,
            isInterState = false
        )

        assertEquals(100.0, result.taxableAmount, 0.01)
        assertEquals(9.0, result.cgstAmount, 0.01)
        assertEquals(9.0, result.sgstAmount, 0.01)
        assertEquals(18.0, result.totalGst, 0.01)
        assertEquals(118.0, result.finalTotal, 0.01)
    }

    @Test
    fun testInterStateGst() {
        // Price ₹100 with 18% exclusive GST inter-state -> IGST: ₹18, CGST: 0, SGST: 0
        val result = GstCalculationUseCase.calculateItemTax(
            unitPrice = 100.0,
            quantity = 1.0,
            gstRate = 18.0,
            isTaxInclusive = false,
            isInterState = true
        )

        assertEquals(100.0, result.taxableAmount, 0.01)
        assertEquals(0.0, result.cgstAmount, 0.01)
        assertEquals(0.0, result.sgstAmount, 0.01)
        assertEquals(18.0, result.igstAmount, 0.01)
        assertEquals(118.0, result.finalTotal, 0.01)
    }

    @Test
    fun testZeroTaxGst() {
        // Essential food grains: Sugar/Rice at 0% GST
        val result = GstCalculationUseCase.calculateItemTax(
            unitPrice = 42.0,
            quantity = 2.0,
            gstRate = 0.0,
            isTaxInclusive = true
        )

        assertEquals(84.0, result.taxableAmount, 0.01)
        assertEquals(0.0, result.totalGst, 0.01)
        assertEquals(84.0, result.finalTotal, 0.01)
    }
}
