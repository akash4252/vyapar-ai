package com.vyaparai.app

import com.vyaparai.app.core.database.entities.ProductEntity
import com.vyaparai.app.domain.usecases.SmartPoUseCase
import org.junit.Assert.*
import org.junit.Test

class SmartPurchaseSuggestionTest {

    @Test
    fun testLowStockReplenishmentCalculation() {
        val lowStockProduct = ProductEntity(
            name = "Maggi 2-Minute Noodles",
            currentStock = 5.0,
            minimumStock = 20.0,
            maximumStock = 50.0,
            purchasePrice = 8.0,
            sellingPrice = 10.0
        )

        val suggestions = SmartPoUseCase.generateSuggestions(listOf(lowStockProduct))
        assertEquals(1, suggestions.size)
        val s = suggestions[0]
        assertEquals(45.0, s.suggestedQuantity, 0.001) // 50 - 5 = 45
        assertEquals(360.0, s.estimatedCost, 0.001) // 45 * 8 = 360
    }
}
