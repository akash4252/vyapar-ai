package com.vyaparai.app

import com.vyaparai.app.core.voice.BusinessQueryType
import com.vyaparai.app.core.voice.VoiceCommandResult
import com.vyaparai.app.core.voice.VoiceParserEngine
import org.junit.Assert.*
import org.junit.Test

class VoiceParserTest {

    @Test
    fun testParseSimpleProductAndQuantity() {
        val result = VoiceParserEngine.parse("Maggi 2")
        assertTrue(result is VoiceCommandResult.BillingCommand)
        val billing = result as VoiceCommandResult.BillingCommand
        assertEquals(1, billing.items.size)
        assertEquals("Maggi", billing.items[0].productName)
        assertEquals(2.0, billing.items[0].quantity, 0.001)
    }

    @Test
    fun testParseProductQuantityUnitAndPrice() {
        val result = VoiceParserEngine.parse("Sugar 2kg 80 rupees")
        assertTrue(result is VoiceCommandResult.BillingCommand)
        val billing = result as VoiceCommandResult.BillingCommand
        assertEquals(1, billing.items.size)
        assertEquals("Sugar", billing.items[0].productName)
        assertEquals(2.0, billing.items[0].quantity, 0.001)
        assertEquals("kg", billing.items[0].unit)
        assertEquals(80.0, billing.items[0].price ?: 0.0, 0.001)
    }

    @Test
    fun testParseMultiItemClause() {
        val result = VoiceParserEngine.parse("Maggi 2 and sugar 1 kilo")
        assertTrue(result is VoiceCommandResult.BillingCommand)
        val billing = result as VoiceCommandResult.BillingCommand
        assertEquals(2, billing.items.size)
        assertEquals("Maggi", billing.items[0].productName)
        assertEquals(2.0, billing.items[0].quantity, 0.001)
        assertEquals("sugar", billing.items[1].productName)
        assertEquals(1.0, billing.items[1].quantity, 0.001)
        assertEquals("kg", billing.items[1].unit)
    }

    @Test
    fun testParseHindiSpokenInput() {
        val result = VoiceParserEngine.parse("मैगी दो")
        assertTrue(result is VoiceCommandResult.BillingCommand)
        val billing = result as VoiceCommandResult.BillingCommand
        assertEquals("मैगी", billing.items[0].productName)
        assertEquals(2.0, billing.items[0].quantity, 0.001)
    }

    @Test
    fun testParseMarathiSpokenInput() {
        val result = VoiceParserEngine.parse("मॅगी दोन")
        assertTrue(result is VoiceCommandResult.BillingCommand)
        val billing = result as VoiceCommandResult.BillingCommand
        assertEquals("मॅगी", billing.items[0].productName)
        assertEquals(2.0, billing.items[0].quantity, 0.001)
    }

    @Test
    fun testParseVoiceKhataCredit() {
        val result = VoiceParserEngine.parse("Rahul ko 500 rupaye udhaar")
        assertTrue(result is VoiceCommandResult.KhataCreditCommand)
        val credit = result as VoiceCommandResult.KhataCreditCommand
        assertEquals("Rahul", credit.customerName)
        assertEquals(500.0, credit.amount, 0.001)
    }

    @Test
    fun testParseVoiceKhataPayment() {
        val result = VoiceParserEngine.parse("Rahul ne 300 diye")
        assertTrue(result is VoiceCommandResult.KhataPaymentCommand)
        val payment = result as VoiceCommandResult.KhataPaymentCommand
        assertEquals("Rahul", payment.customerName)
        assertEquals(300.0, payment.amount, 0.001)
    }

    @Test
    fun testParseBusinessVoiceQueryMarathi() {
        val result = VoiceParserEngine.parse("आजची विक्री किती?")
        assertTrue(result is VoiceCommandResult.BusinessQueryCommand)
        val query = result as VoiceCommandResult.BusinessQueryCommand
        assertEquals(BusinessQueryType.TODAY_SALES, query.queryType)
    }

    @Test
    fun testParseBusinessVoiceQueryProfit() {
        val result = VoiceParserEngine.parse("आज profit किती?")
        assertTrue(result is VoiceCommandResult.BusinessQueryCommand)
        val query = result as VoiceCommandResult.BusinessQueryCommand
        assertEquals(BusinessQueryType.TODAY_PROFIT, query.queryType)
    }

    @Test
    fun testParseBusinessVoiceQueryLowStock() {
        val result = VoiceParserEngine.parse("Low stock दाखव")
        assertTrue(result is VoiceCommandResult.BusinessQueryCommand)
        val query = result as VoiceCommandResult.BusinessQueryCommand
        assertEquals(BusinessQueryType.LOW_STOCK, query.queryType)
    }
}
