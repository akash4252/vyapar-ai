package com.vyaparai.app

import com.vyaparai.app.core.utils.CurrencyFormatter
import com.vyaparai.app.core.utils.IndianNumberToWords
import org.junit.Assert.*
import org.junit.Test

class CurrencyAndWordsTest {

    @Test
    fun testIndianCurrencyFormatting() {
        assertEquals("₹12,450.00", CurrencyFormatter.format(12450.0))
        assertEquals("₹1,25,500.00", CurrencyFormatter.format(125500.0))
        assertEquals("₹20.00", CurrencyFormatter.format(20.0))
    }

    @Test
    fun testIndianNumberToWords() {
        assertEquals("Rupees Twenty Only", IndianNumberToWords.convert(20.0))
        assertEquals("Rupees One Thousand Two Hundred and Fifty Only", IndianNumberToWords.convert(1250.0))
        assertEquals("Rupees Five Hundred and Fifty Paise Only", IndianNumberToWords.convert(500.50))
    }
}
