package com.vyaparai.app.presentation.screens.billing

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vyaparai.app.VyaparAiApplication
import com.vyaparai.app.core.database.entities.CustomerEntity
import com.vyaparai.app.core.database.entities.ProductEntity
import com.vyaparai.app.core.theme.VyaparGreenPrimary
import com.vyaparai.app.core.theme.VyaparSecondaryAmber
import com.vyaparai.app.core.utils.CurrencyFormatter
import com.vyaparai.app.core.voice.ParsedVoiceItem
import com.vyaparai.app.core.voice.VoiceCommandResult
import com.vyaparai.app.core.voice.VoiceParserEngine
import com.vyaparai.app.domain.usecases.CartItem
import com.vyaparai.app.presentation.common.*
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FastBillingPosScreen(
    onScanBarcodeClick: () -> Unit,
    onCheckoutClick: (List<CartItem>, CustomerEntity?) -> Unit,
    onBackClick: () -> Unit
) {
    val context = LocalContext.current
    val app = context.applicationContext as VyaparAiApplication
    val scope = rememberCoroutineScope()

    var searchQuery by remember { mutableStateOf("") }
    val searchResults by app.container.productRepository.searchProducts(searchQuery).collectAsState(initial = emptyList())
    val customers by app.container.customerKhataRepository.getAllCustomers().collectAsState(initial = emptyList())

    val cartItems = remember { mutableStateListOf<CartItem>() }
    var selectedCustomer by remember { mutableStateOf<CustomerEntity?>(null) }
    var showCustomerPicker by remember { mutableStateOf(false) }

    var isVoiceActive by remember { mutableStateOf(false) }
    var voiceModalResult by remember { mutableStateOf<VoiceCommandResult?>(null) }

    val nextInvoiceNumber by produceState(initialValue = "VX-2026-000001") {
        value = app.container.invoiceRepository.generateNextInvoiceNumber()
    }

    // Totals Calculation
    val subtotal = cartItems.sumOf { it.unitPrice * it.quantity }
    val totalDiscount = cartItems.sumOf { it.discount }
    val grandTotal = (subtotal - totalDiscount).coerceAtLeast(0.0)

    fun addProductToCart(product: ProductEntity, quantity: Double = 1.0) {
        val existingIndex = cartItems.indexOfFirst { it.product.id == product.id }
        if (existingIndex >= 0) {
            val existing = cartItems[existingIndex]
            cartItems[existingIndex] = existing.copy(quantity = existing.quantity + quantity)
        } else {
            cartItems.add(CartItem(product = product, quantity = quantity))
        }
        searchQuery = ""
    }

    Scaffold(
        topBar = {
            VyaparTopBar(
                title = "New Bill",
                subtitle = nextInvoiceNumber,
                showBackButton = true,
                onBackClick = onBackClick,
                actions = {
                    IconButton(onClick = { cartItems.clear() }) {
                        Icon(Icons.Default.DeleteSweep, contentDescription = "Clear Bill", tint = Color.White)
                    }
                }
            )
        },
        bottomBar = {
            if (cartItems.isNotEmpty()) {
                Surface(
                    shadowElevation = 8.dp,
                    color = MaterialTheme.colorScheme.surface
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "${cartItems.size} items in bill",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    text = CurrencyFormatter.format(grandTotal),
                                    style = MaterialTheme.typography.headlineMedium,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = VyaparGreenPrimary
                                )
                            }

                            Button(
                                onClick = { onCheckoutClick(cartItems.toList(), selectedCustomer) },
                                modifier = Modifier
                                    .height(52.dp)
                                    .widthIn(min = 160.dp),
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = VyaparGreenPrimary)
                            ) {
                                Text("PAY / BILL", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                Spacer(modifier = Modifier.width(6.dp))
                                Icon(Icons.Default.ArrowForward, contentDescription = null)
                            }
                        }
                    }
                }
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp)
        ) {
            Spacer(modifier = Modifier.height(12.dp))

            // Customer Selector Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surfaceVariant, shape = RoundedCornerShape(12.dp))
                    .clickable { showCustomerPicker = true }
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Person, contentDescription = null, tint = VyaparGreenPrimary)
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = selectedCustomer?.name ?: "Cash Customer (Tap to select)",
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 14.sp
                        )
                        if (selectedCustomer?.mobile != null) {
                            Text(
                                text = selectedCustomer!!.mobile!!,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
                Icon(Icons.Default.ArrowDropDown, contentDescription = null)
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Search Bar with Barcode Scanner & Mic Buttons
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Search product name, barcode...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                trailingIcon = {
                    Row {
                        IconButton(onClick = {
                            // Trigger voice speech parser
                            val testSpeech = "Maggi 2 and Sugar 1kg"
                            voiceModalResult = VoiceParserEngine.parse(testSpeech)
                        }) {
                            Icon(Icons.Default.Mic, contentDescription = "Voice Search", tint = VyaparSecondaryAmber)
                        }
                        IconButton(onClick = onScanBarcodeClick) {
                            Icon(Icons.Default.QrCodeScanner, contentDescription = "Scan Barcode", tint = VyaparGreenPrimary)
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                singleLine = true
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Search Suggestions dropdown if searching
            if (searchQuery.isNotBlank() && searchResults.isNotEmpty()) {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 240.dp)
                        .background(MaterialTheme.colorScheme.surface, shape = RoundedCornerShape(12.dp))
                ) {
                    items(searchResults) { product ->
                        ProductItemRow(
                            product = product,
                            onProductClick = { addProductToCart(product) },
                            onAddToCartClick = { addProductToCart(product) }
                        )
                    }
                }
                Spacer(modifier = Modifier.height(12.dp))
            }

            // Current Cart Items List
            if (cartItems.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.ShoppingCart,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.outline,
                            modifier = Modifier.size(64.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "Bill is empty",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = "Tap Mic to speak, Scan Barcode, or Search",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            } else {
                Text(
                    text = "Items in Bill (${cartItems.size})",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(6.dp))

                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                ) {
                    items(cartItems) { item ->
                        CartItemRow(
                            item = item,
                            onIncreaseQty = {
                                val idx = cartItems.indexOf(item)
                                if (idx >= 0) cartItems[idx] = item.copy(quantity = item.quantity + 1.0)
                            },
                            onDecreaseQty = {
                                val idx = cartItems.indexOf(item)
                                if (idx >= 0) {
                                    if (item.quantity > 1.0) {
                                        cartItems[idx] = item.copy(quantity = item.quantity - 1.0)
                                    } else {
                                        cartItems.removeAt(idx)
                                    }
                                }
                            },
                            onRemoveItem = { cartItems.remove(item) }
                        )
                    }
                }
            }
        }

        // Customer Picker Modal BottomSheet
        if (showCustomerPicker) {
            ModalBottomSheet(
                onDismissRequest = { showCustomerPicker = false },
                containerColor = MaterialTheme.colorScheme.surface
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp)
                ) {
                    Text(text = "Select Customer", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(12.dp))

                    ListItem(
                        headlineContent = { Text("Cash Customer (Walk-in)", fontWeight = FontWeight.Bold) },
                        modifier = Modifier.clickable {
                            selectedCustomer = null
                            showCustomerPicker = false
                        }
                    )
                    HorizontalDivider()

                    LazyColumn(modifier = Modifier.fillMaxWidth().heightIn(max = 300.dp)) {
                        items(customers) { customer ->
                            ListItem(
                                headlineContent = { Text(customer.name, fontWeight = FontWeight.SemiBold) },
                                supportingContent = { Text("Mobile: ${customer.mobile ?: "None"}") },
                                trailingContent = {
                                    if (customer.currentCreditBalance > 0) {
                                        Text(
                                            text = "Due: ${CurrencyFormatter.format(customer.currentCreditBalance)}",
                                            color = MaterialTheme.colorScheme.error,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 12.sp
                                        )
                                    }
                                },
                                modifier = Modifier.clickable {
                                    selectedCustomer = customer
                                    showCustomerPicker = false
                                }
                            )
                        }
                    }
                }
            }
        }

        // Voice Confirmation Sheet
        if (voiceModalResult != null) {
            VoiceConfirmationModal(
                commandResult = voiceModalResult!!,
                onConfirm = { result ->
                    if (result is VoiceCommandResult.BillingCommand) {
                        scope.launch {
                            for (voiceItem in result.items) {
                                val matches = app.container.productRepository.searchProductsList(voiceItem.productName)
                                if (matches.isNotEmpty()) {
                                    addProductToCart(matches.first(), voiceItem.quantity)
                                }
                            }
                            if (result.customerName != null) {
                                selectedCustomer = app.container.customerKhataRepository.findCustomerByName(result.customerName)
                            }
                        }
                    }
                    voiceModalResult = null
                },
                onDismiss = { voiceModalResult = null }
            )
        }
    }
}
