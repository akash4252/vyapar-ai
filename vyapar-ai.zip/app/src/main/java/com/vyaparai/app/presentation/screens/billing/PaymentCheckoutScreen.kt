package com.vyaparai.app.presentation.screens.billing

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vyaparai.app.VyaparAiApplication
import com.vyaparai.app.core.database.entities.CustomerEntity
import com.vyaparai.app.core.theme.VyaparGreenPrimary
import com.vyaparai.app.core.theme.VyaparSecondaryAmber
import com.vyaparai.app.core.utils.CurrencyFormatter
import com.vyaparai.app.domain.usecases.BillingCheckoutRequest
import com.vyaparai.app.domain.usecases.CartItem
import com.vyaparai.app.presentation.common.*
import kotlinx.coroutines.launch

data class PaymentModeOption(
    val id: String,
    val name: String,
    val icon: ImageVector
)

@Composable
fun PaymentCheckoutScreen(
    cartItems: List<CartItem>,
    customer: CustomerEntity?,
    onInvoiceCreated: (String) -> Unit,
    onBackClick: () -> Unit
) {
    val context = LocalContext.current
    val app = context.applicationContext as VyaparAiApplication
    val scope = rememberCoroutineScope()

    val business by app.container.settingsRepository.getBusiness().collectAsState(initial = null)

    val grandTotal = cartItems.sumOf { (it.unitPrice * it.quantity) - it.discount }
    var selectedMethod by remember { mutableStateOf("CASH") }
    var amountPaidInput by remember { mutableStateOf(grandTotal.toString()) }
    var cashGivenInput by remember { mutableStateOf(grandTotal.toString()) }
    var showUpiQrDialog by remember { mutableStateOf(false) }
    var isProcessing by remember { mutableStateOf(false) }

    val amountPaid = amountPaidInput.toDoubleOrNull() ?: grandTotal
    val cashGiven = cashGivenInput.toDoubleOrNull() ?: grandTotal
    val changeReturn = (cashGiven - grandTotal).coerceAtLeast(0.0)
    val remainingUdhaar = (grandTotal - amountPaid).coerceAtLeast(0.0)

    val paymentModes = listOf(
        PaymentModeOption("CASH", "Cash", Icons.Default.Payments),
        PaymentModeOption("UPI", "UPI QR", Icons.Default.QrCode),
        PaymentModeOption("CREDIT", "Credit (Khata)", Icons.Default.Book),
        PaymentModeOption("CARD", "Card", Icons.Default.CreditCard),
        PaymentModeOption("BANK", "Bank Transfer", Icons.Default.AccountBalance)
    )

    fun completeBilling() {
        if (isProcessing) return
        isProcessing = true
        scope.launch {
            try {
                val invoice = app.container.atomicBillingUseCase.execute(
                    BillingCheckoutRequest(
                        cartItems = cartItems,
                        customer = customer,
                        paymentMethod = selectedMethod,
                        amountPaid = if (selectedMethod == "CREDIT") 0.0 else amountPaid,
                        cashGiven = cashGiven
                    )
                )
                onInvoiceCreated(invoice.invoiceNumber)
            } catch (e: Exception) {
                e.printStackTrace()
                isProcessing = false
            }
        }
    }

    Scaffold(
        topBar = {
            VyaparTopBar(
                title = "Payment Checkout",
                subtitle = "${cartItems.size} items | ${CurrencyFormatter.format(grandTotal)}",
                showBackButton = true,
                onBackClick = onBackClick
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(20.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                // Grand Total Display Card
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(text = "TOTAL AMOUNT DUE", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = CurrencyFormatter.format(grandTotal),
                            style = MaterialTheme.typography.headlineLarge,
                            fontWeight = FontWeight.ExtraBold,
                            color = VyaparGreenPrimary
                        )
                        if (customer != null) {
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Billed to: ${customer.name}",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                Text(text = "Select Payment Method", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(10.dp))

                // Payment Method Selector Pills/Cards
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    for (mode in paymentModes.take(3)) {
                        val isSelected = selectedMethod == mode.id
                        Card(
                            modifier = Modifier
                                .weight(1f)
                                .height(72.dp)
                                .clickable {
                                    selectedMethod = mode.id
                                    if (mode.id == "UPI") showUpiQrDialog = true
                                }
                                .then(if (isSelected) Modifier.border(2.dp, VyaparGreenPrimary, RoundedCornerShape(12.dp)) else Modifier),
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = if (isSelected) VyaparGreenPrimary.copy(alpha = 0.12f) else MaterialTheme.colorScheme.surface
                            )
                        ) {
                            Column(
                                modifier = Modifier.fillMaxSize().padding(8.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center
                            ) {
                                Icon(imageVector = mode.icon, contentDescription = null, tint = if (isSelected) VyaparGreenPrimary else MaterialTheme.colorScheme.onSurfaceVariant)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(text = mode.name, fontSize = 12.sp, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium)
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Cash Calculation Fields
                if (selectedMethod == "CASH") {
                    OutlinedTextField(
                        value = cashGivenInput,
                        onValueChange = { cashGivenInput = it },
                        label = { Text("Cash Received from Customer") },
                        leadingIcon = { Text("₹", fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 12.dp)) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    if (changeReturn > 0) {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color(0xFFE8F5E9)),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(14.dp).fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("Change to Return:", fontWeight = FontWeight.Bold, color = Color(0xFF16A34A))
                                Text(CurrencyFormatter.format(changeReturn), fontWeight = FontWeight.ExtraBold, fontSize = 18.sp, color = Color(0xFF16A34A))
                            }
                        }
                    }
                }

                // Credit/Udhaar Warning
                if (selectedMethod == "CREDIT" || remainingUdhaar > 0) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFFEF2F2)),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text(
                                text = "Remaining ${CurrencyFormatter.format(if (selectedMethod == "CREDIT") grandTotal else remainingUdhaar)} will be added to ${customer?.name ?: "Customer"}'s Digital Khata",
                                color = Color(0xFFDC2626),
                                fontWeight = FontWeight.SemiBold,
                                style = MaterialTheme.typography.bodyMedium
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            VyaparPrimaryButton(
                text = if (isProcessing) "GENERATING INVOICE..." else "COMPLETE SALE & INVOICE",
                onClick = { completeBilling() },
                enabled = !isProcessing,
                icon = Icons.Default.ReceiptLong
            )
        }

        // UPI QR Dialog
        if (showUpiQrDialog && business?.upiId != null) {
            UpiQrDialog(
                businessName = business!!.name,
                upiId = business!!.upiId!!,
                amount = grandTotal,
                onDismiss = { showUpiQrDialog = false },
                onPaymentConfirmed = {
                    showUpiQrDialog = false
                    completeBilling()
                }
            )
        }
    }
}
