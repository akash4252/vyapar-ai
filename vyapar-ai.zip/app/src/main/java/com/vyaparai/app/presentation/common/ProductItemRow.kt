package com.vyaparai.app.presentation.common

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vyaparai.app.core.database.entities.ProductEntity
import com.vyaparai.app.core.theme.VyaparGreenPrimary
import com.vyaparai.app.core.utils.CurrencyFormatter

@Composable
fun ProductItemRow(
    product: ProductEntity,
    onProductClick: () -> Unit,
    onAddToCartClick: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val isLowStock = product.currentStock <= product.minimumStock

    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .clickable { onProductClick() },
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.5.dp)
    ) {
        Row(
            modifier = Modifier
                .padding(14.dp)
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = product.name,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1
                )
                Spacer(modifier = Modifier.height(4.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = CurrencyFormatter.format(product.sellingPrice),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = VyaparGreenPrimary
                    )
                    if (product.mrp > product.sellingPrice) {
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "MRP ${CurrencyFormatter.format(product.mrp)}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                Spacer(modifier = Modifier.height(4.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    val stockBg = if (isLowStock) Color(0xFFFEE2E2) else Color(0xFFE8F5E9)
                    val stockText = if (isLowStock) Color(0xFFDC2626) else Color(0xFF16A34A)
                    Box(
                        modifier = Modifier
                            .background(stockBg, shape = RoundedCornerShape(4.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = if (isLowStock) "Low Stock: ${product.currentStock.toInt()} ${product.unit}" else "Stock: ${product.currentStock.toInt()} ${product.unit}",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = stockText
                        )
                    }
                    if (!product.barcode.isNullOrBlank()) {
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "BC: ${product.barcode}",
                            fontSize = 10.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            if (onAddToCartClick != null) {
                FilledTonalButton(
                    onClick = onAddToCartClick,
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Icon(imageVector = Icons.Default.Add, contentDescription = "Add", modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("ADD", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
