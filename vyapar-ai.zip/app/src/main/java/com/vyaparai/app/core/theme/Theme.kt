package com.vyaparai.app.core.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val LightColorScheme = lightColorScheme(
    primary = VyaparGreenPrimary,
    onPrimary = VyaparGreenOnPrimary,
    primaryContainer = VyaparGreenContainer,
    onPrimaryContainer = VyaparGreenOnContainer,
    secondary = VyaparSecondaryAmber,
    onSecondary = VyaparOnSecondary,
    secondaryContainer = VyaparSecondaryContainer,
    onSecondaryContainer = VyaparOnSecondaryContainer,
    tertiary = VyaparTertiaryBlue,
    onTertiary = VyaparOnTertiary,
    tertiaryContainer = VyaparTertiaryContainer,
    onTertiaryContainer = VyaparOnTertiaryContainer,
    background = VyaparLightBackground,
    onBackground = VyaparLightOnSurface,
    surface = VyaparLightSurface,
    onSurface = VyaparLightOnSurface,
    surfaceVariant = VyaparLightSurfaceVariant,
    onSurfaceVariant = VyaparLightOnSurfaceVariant,
    outline = VyaparLightOutline,
    error = VyaparError
)

private val DarkColorScheme = darkColorScheme(
    primary = VyaparDarkPrimary,
    onPrimary = VyaparGreenOnPrimary,
    primaryContainer = VyaparGreenOnContainer,
    onPrimaryContainer = VyaparGreenContainer,
    secondary = VyaparSecondaryAmber,
    onSecondary = VyaparOnSecondary,
    secondaryContainer = VyaparOnSecondaryContainer,
    onSecondaryContainer = VyaparSecondaryContainer,
    tertiary = VyaparTertiaryBlue,
    onTertiary = VyaparOnTertiary,
    background = VyaparDarkBackground,
    onBackground = VyaparDarkOnSurface,
    surface = VyaparDarkSurface,
    onSurface = VyaparDarkOnSurface,
    surfaceVariant = VyaparDarkSurfaceVariant,
    onSurfaceVariant = VyaparDarkOnSurfaceVariant,
    outline = VyaparDarkOutline,
    error = VyaparError
)

@Composable
fun VyaparTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
    val view = LocalView.current

    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window
            window?.let {
                it.statusBarColor = colorScheme.primary.toArgb()
                WindowCompat.getInsetsController(it, view).isAppearanceLightStatusBars = false
            }
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = VyaparTypography,
        shapes = VyaparShapes,
        content = content
    )
}
