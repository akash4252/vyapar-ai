package com.vyaparai.app.presentation.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.navigation.NavController
import androidx.navigation.compose.currentBackStackEntryAsState
import com.vyaparai.app.core.theme.VyaparGreenPrimary

sealed class BottomNavItem(
    val route: String,
    val title: String,
    val icon: ImageVector
) {
    data object Home : BottomNavItem(NavRoutes.Dashboard.route, "Home", Icons.Default.Home)
    data object Billing : BottomNavItem(NavRoutes.FastBilling.route, "Billing", Icons.Default.AddShoppingCart)
    data object Inventory : BottomNavItem(NavRoutes.InventoryDashboard.route, "Inventory", Icons.Default.Inventory2)
    data object Khata : BottomNavItem(NavRoutes.DigitalKhata.route, "Khata", Icons.Default.Book)
    data object More : BottomNavItem(NavRoutes.SettingsHub.route, "Settings", Icons.Default.Settings)
}

@Composable
fun VyaparBottomBar(navController: NavController) {
    val items = listOf(
        BottomNavItem.Home,
        BottomNavItem.Billing,
        BottomNavItem.Inventory,
        BottomNavItem.Khata,
        BottomNavItem.More
    )

    val navBackStackEntry = navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry.value?.destination?.route

    val showBottomBar = items.any { it.route == currentRoute }

    if (showBottomBar) {
        NavigationBar(
            containerColor = MaterialTheme.colorScheme.surface,
            tonalElevation = NavigationBarDefaults.Elevation
        ) {
            items.forEach { item ->
                val isSelected = currentRoute == item.route
                NavigationBarItem(
                    icon = { Icon(item.icon, contentDescription = item.title) },
                    label = { Text(item.title) },
                    selected = isSelected,
                    onClick = {
                        if (currentRoute != item.route) {
                            navController.navigate(item.route) {
                                popUpTo(NavRoutes.Dashboard.route) { saveState = true }
                                launchSingleTop = true
                                restoreState = true
                            }
                        }
                    },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = VyaparGreenPrimary,
                        selectedTextColor = VyaparGreenPrimary,
                        indicatorColor = VyaparGreenPrimary.copy(alpha = 0.12f)
                    )
                )
            }
        }
    }
}
