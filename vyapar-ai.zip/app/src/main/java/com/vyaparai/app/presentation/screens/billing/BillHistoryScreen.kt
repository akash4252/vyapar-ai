package com.vyaparai.app.presentation.screens.billing

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.vyaparai.app.VyaparAiApplication
import com.vyaparai.app.core.theme.VyaparGreenPrimary
import com.vyaparai.app.core.utils.CurrencyFormatter
import com.vyaparai.app.core.utils.DateUtils
import com.vyaparai.app.presentation.common.VyaparTopBar

@Composable
fun BillHistoryScreen(
    onInvoiceClick: (String) -> Unit,
    onBackClick: () -> Unit
) {
    val context = LocalContext.current
    val app = context.applicationContext as VyaparAiApplication

    val invoices by app.container.invoiceRepository.getAllInvoices().collectAsState(initial = emptyList())
    var searchQuery by remember { mutableStateOf("") }

    val filteredInvoices = invoices.filter {
        val inv = it.invoice
        inv.invoiceNumber.contains(searchQuery, true) ||
                (inv.customerName?.contains(searchQuery, true) == true) ||
                (inv.customerMobile?.contains(searchQuery, true) == true)
    }

    Scaffold(
        topBar = {
            VyaparTopBar(
                title = "Bill History",
                subtitle = "${invoices.size} total bills",
                showBackButton = true,
                onBackClick = onBackClick
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
        ) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Search invoice number or customer...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                singleLine = true
            )

            Spacer(modifier = Modifier.height(16.dp))

            if (filteredInvoices.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("No invoices found", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(filteredInvoices) { item ->
                        val inv = item.invoice
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onInvoiceClick(inv.invoiceNumber) },
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .padding(16.dp)
                                    .fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text(text = inv.invoiceNumber, fontWeight = FontWeight.Bold)
                                    Text(
                                        text = inv.customerName ?: "Cash Customer",
                                        style = MaterialTheme.typography.bodyMedium
                                    )
                                    Text(
                                        text = "${DateUtils.formatDateTime(inv.createdAt)} | ${inv.paymentMethod}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    Text(
                                        text = CurrencyFormatter.format(inv.grandTotal),
                                        fontWeight = FontWeight.ExtraBold,
                                        color = VyaparGreenPrimary,
                                        style = MaterialTheme.typography.titleMedium
                                    )
                                    Text(
                                        text = "${item.items.size} items",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
