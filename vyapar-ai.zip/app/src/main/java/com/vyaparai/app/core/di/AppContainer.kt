package com.vyaparai.app.core.di

import android.content.Context
import com.vyaparai.app.core.database.AppDatabase
import com.vyaparai.app.data.repositories.*
import com.vyaparai.app.domain.repositories.*
import com.vyaparai.app.domain.usecases.AtomicBillingUseCase

interface AppContainer {
    val database: AppDatabase
    val productRepository: ProductRepository
    val invoiceRepository: InvoiceRepository
    val customerKhataRepository: CustomerKhataRepository
    val supplierPurchaseRepository: SupplierPurchaseRepository
    val settingsRepository: SettingsRepository
    val backupRepository: BackupRepository
    val atomicBillingUseCase: AtomicBillingUseCase
}

class DefaultAppContainer(private val context: Context) : AppContainer {
    override val database: AppDatabase by lazy {
        AppDatabase.getInstance(context)
    }

    override val productRepository: ProductRepository by lazy {
        ProductRepositoryImpl(database)
    }

    override val invoiceRepository: InvoiceRepository by lazy {
        InvoiceRepositoryImpl(database)
    }

    override val customerKhataRepository: CustomerKhataRepository by lazy {
        CustomerKhataRepositoryImpl(database)
    }

    override val supplierPurchaseRepository: SupplierPurchaseRepository by lazy {
        SupplierPurchaseRepositoryImpl(database)
    }

    override val settingsRepository: SettingsRepository by lazy {
        SettingsRepositoryImpl(database)
    }

    override val backupRepository: BackupRepository by lazy {
        BackupRepositoryImpl(database)
    }

    override val atomicBillingUseCase: AtomicBillingUseCase by lazy {
        AtomicBillingUseCase(database)
    }
}
