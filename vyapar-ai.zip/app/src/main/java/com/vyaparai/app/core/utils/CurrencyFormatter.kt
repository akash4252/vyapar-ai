package com.vyaparai.app.core.utils

import java.text.DecimalFormat
import java.util.Locale

object CurrencyFormatter {
    private val indianFormat = DecimalFormat("##,##,##0.00")
    private val compactFormat = DecimalFormat("##,##,##0")

    fun format(amount: Double, showDecimals: Boolean = true): String {
        val formattedNumber = if (showDecimals && amount % 1.0 != 0.0) {
            indianFormat.format(amount)
        } else if (showDecimals) {
            indianFormat.format(amount)
        } else {
            compactFormat.format(amount)
        }
        return "₹$formattedNumber"
    }

    fun formatCompact(amount: Double): String {
        return when {
            amount >= 1_00_00_000 -> String.format(Locale.ENGLISH, "₹%.2f Cr", amount / 1_00_00_000)
            amount >= 1_00_000 -> String.format(Locale.ENGLISH, "₹%.2f L", amount / 1_00_000)
            amount >= 1_000 -> String.format(Locale.ENGLISH, "₹%.1f K", amount / 1_000)
            else -> format(amount, showDecimals = false)
        }
    }
}
