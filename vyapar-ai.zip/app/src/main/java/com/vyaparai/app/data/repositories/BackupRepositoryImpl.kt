package com.vyaparai.app.data.repositories

import android.content.Context
import androidx.room.withTransaction
import com.vyaparai.app.core.database.AppDatabase
import com.vyaparai.app.core.database.entities.*
import com.vyaparai.app.core.security.KeystoreManager
import com.vyaparai.app.domain.repositories.BackupRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream

class BackupRepositoryImpl(
    private val database: AppDatabase
) : BackupRepository {

    override suspend fun createEncryptedBackup(context: Context): Result<File> = withContext(Dispatchers.IO) {
        try {
            val root = JSONObject()

            // 1. Business & Settings
            val business = database.settingsBusinessDao().getBusiness()
            if (business != null) {
                root.put("business", JSONObject().apply {
                    put("name", business.name)
                    put("ownerName", business.ownerName)
                    put("mobile", business.mobile)
                    put("gstin", business.gstin ?: "")
                    put("address", business.address ?: "")
                    put("upiId", business.upiId ?: "")
                })
            }

            // 2. Products
            val products = database.productDao().getAllProducts()
            val prodArray = JSONArray()
            for (p in products) {
                prodArray.put(JSONObject().apply {
                    put("name", p.name)
                    put("barcode", p.barcode ?: "")
                    put("unit", p.unit)
                    put("purchasePrice", p.purchasePrice)
                    put("sellingPrice", p.sellingPrice)
                    put("mrp", p.mrp)
                    put("gstRate", p.gstRate)
                    put("currentStock", p.currentStock)
                    put("minimumStock", p.minimumStock)
                })
            }
            root.put("products", prodArray)

            // 3. Customers
            val customers = database.customerKhataDao().getAllCustomers()
            val custArray = JSONArray()
            for (c in customers) {
                custArray.put(JSONObject().apply {
                    put("name", c.name)
                    put("mobile", c.mobile ?: "")
                    put("currentCreditBalance", c.currentCreditBalance)
                    put("totalSpent", c.totalSpent)
                    put("loyaltyPoints", c.loyaltyPoints)
                })
            }
            root.put("customers", custArray)

            val jsonString = root.toString()
            val encryptedBase64 = KeystoreManager.encrypt(jsonString)

            val dir = File(context.getExternalFilesDir(null), "backups")
            if (!dir.exists()) dir.mkdirs()
            val backupFile = File(dir, "vyapar_backup_${System.currentTimeMillis()}.enc")

            FileOutputStream(backupFile).use { it.write(encryptedBase64.toByteArray(Charsets.UTF_8)) }
            Result.success(backupFile)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun restoreEncryptedBackup(backupFile: File): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val encryptedBase64 = FileInputStream(backupFile).bufferedReader().use { it.readText() }
            val decryptedJson = KeystoreManager.decrypt(encryptedBase64)
            val root = JSONObject(decryptedJson)

            database.withTransaction {
                // Restore Business
                if (root.has("business")) {
                    val bObj = root.getJSONObject("business")
                    database.settingsBusinessDao().insertOrUpdateBusiness(
                        BusinessEntity(
                            id = 1,
                            name = bObj.getString("name"),
                            ownerName = bObj.optString("ownerName", ""),
                            mobile = bObj.optString("mobile", ""),
                            gstin = bObj.optString("gstin", null),
                            address = bObj.optString("address", null),
                            upiId = bObj.optString("upiId", null)
                        )
                    )
                }

                // Restore Products
                if (root.has("products")) {
                    val pArray = root.getJSONArray("products")
                    for (i in 0 until pArray.length()) {
                        val pObj = pArray.getJSONObject(i)
                        database.productDao().insertProduct(
                            ProductEntity(
                                name = pObj.getString("name"),
                                barcode = pObj.optString("barcode", null).takeIf { !it.isNullOrBlank() },
                                unit = pObj.optString("unit", "pcs"),
                                purchasePrice = pObj.optDouble("purchasePrice", 0.0),
                                sellingPrice = pObj.optDouble("sellingPrice", 0.0),
                                mrp = pObj.optDouble("mrp", 0.0),
                                gstRate = pObj.optDouble("gstRate", 0.0),
                                currentStock = pObj.optDouble("currentStock", 0.0),
                                minimumStock = pObj.optDouble("minimumStock", 5.0)
                            )
                        )
                    }
                }

                // Restore Customers
                if (root.has("customers")) {
                    val cArray = root.getJSONArray("customers")
                    for (i in 0 until cArray.length()) {
                        val cObj = cArray.getJSONObject(i)
                        database.customerKhataDao().insertCustomer(
                            CustomerEntity(
                                name = cObj.getString("name"),
                                mobile = cObj.optString("mobile", null).takeIf { !it.isNullOrBlank() },
                                currentCreditBalance = cObj.optDouble("currentCreditBalance", 0.0),
                                totalSpent = cObj.optDouble("totalSpent", 0.0),
                                loyaltyPoints = cObj.optInt("loyaltyPoints", 0)
                            )
                        )
                    }
                }
            }

            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun detectExistingBackup(context: Context): File? = withContext(Dispatchers.IO) {
        val dir = File(context.getExternalFilesDir(null), "backups")
        if (dir.exists() && dir.isDirectory) {
            val files = dir.listFiles { _, name -> name.endsWith(".enc") }
            files?.maxByOrNull { it.lastModified() }
        } else {
            null
        }
    }
}
