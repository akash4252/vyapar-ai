package com.vyaparai.app.core.database.daos

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import com.vyaparai.app.core.database.entities.InvoiceEntity
import com.vyaparai.app.core.database.entities.InvoiceItemEntity
import com.vyaparai.app.core.database.entities.PaymentEntity
import com.vyaparai.app.core.database.entities.SalesReturnEntity
import com.vyaparai.app.core.database.entities.SalesReturnItemEntity
import kotlinx.coroutines.flow.Flow

data class InvoiceWithItems(
    @androidx.room.Embedded val invoice: InvoiceEntity,
    @androidx.room.Relation(
        parentColumn = "id",
        entityColumn = "invoiceId"
    )
    val items: List<InvoiceItemEntity>
)

data class TopSellingProductSummary(
    val productId: Long,
    val productName: String,
    val totalQuantitySold: Double,
    val totalRevenue: Double
)

@Dao
interface InvoiceDao {
    @Transaction
    @Query("SELECT * FROM invoices ORDER BY createdAt DESC")
    fun getAllInvoicesWithItemsFlow(): Flow<List<InvoiceWithItems>>

    @Transaction
    @Query("SELECT * FROM invoices WHERE id = :id")
    suspend fun getInvoiceWithItemsById(id: Long): InvoiceWithItems?

    @Transaction
    @Query("SELECT * FROM invoices WHERE invoiceNumber = :invoiceNumber LIMIT 1")
    suspend fun getInvoiceByNumber(invoiceNumber: String): InvoiceWithItems?

    @Query("SELECT * FROM invoices WHERE createdAt BETWEEN :startTime AND :endTime ORDER BY createdAt DESC")
    fun getInvoicesBetweenDatesFlow(startTime: Long, endTime: Long): Flow<List<InvoiceEntity>>

    @Query("SELECT * FROM invoices WHERE createdAt BETWEEN :startTime AND :endTime ORDER BY createdAt DESC")
    suspend fun getInvoicesBetweenDates(startTime: Long, endTime: Long): List<InvoiceEntity>

    @Query("SELECT SUM(grandTotal) FROM invoices WHERE createdAt BETWEEN :startTime AND :endTime AND isCancelled = 0")
    fun getSalesSumBetweenDatesFlow(startTime: Long, endTime: Long): Flow<Double?>

    @Query("SELECT SUM(grandTotal) FROM invoices WHERE createdAt BETWEEN :startTime AND :endTime AND isCancelled = 0")
    suspend fun getSalesSumBetweenDates(startTime: Long, endTime: Long): Double?

    @Query("""
        SELECT SUM(item.totalAmount - (item.purchasePrice * item.quantity)) 
        FROM invoice_items item
        INNER JOIN invoices inv ON item.invoiceId = inv.id
        WHERE inv.createdAt BETWEEN :startTime AND :endTime AND inv.isCancelled = 0
    """)
    fun getProfitSumBetweenDatesFlow(startTime: Long, endTime: Long): Flow<Double?>

    @Query("""
        SELECT item.productId, item.productName, SUM(item.quantity) as totalQuantitySold, SUM(item.totalAmount) as totalRevenue
        FROM invoice_items item
        INNER JOIN invoices inv ON item.invoiceId = inv.id
        WHERE inv.isCancelled = 0
        GROUP BY item.productId, item.productName
        ORDER BY totalQuantitySold DESC
        LIMIT :limit
    """)
    fun getTopSellingProductsFlow(limit: Int = 5): Flow<List<TopSellingProductSummary>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertInvoice(invoice: InvoiceEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertInvoiceItems(items: List<InvoiceItemEntity>)

    @Update
    suspend fun updateInvoice(invoice: InvoiceEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPayment(payment: PaymentEntity): Long

    @Query("SELECT * FROM payments WHERE referenceType = 'INVOICE' AND referenceId = :invoiceId")
    suspend fun getPaymentsForInvoice(invoiceId: Long): List<PaymentEntity>

    // Sales Returns
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSalesReturn(returnEntity: SalesReturnEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSalesReturnItems(items: List<SalesReturnItemEntity>)

    @Query("SELECT * FROM sales_returns ORDER BY createdAt DESC")
    fun getAllSalesReturnsFlow(): Flow<List<SalesReturnEntity>>
}
