package com.vyaparai.app.domain.repositories

import com.vyaparai.app.core.database.daos.InvoiceWithItems
import com.vyaparai.app.core.database.daos.PurchaseOrderWithItems
import com.vyaparai.app.core.database.daos.PurchaseWithItems
import com.vyaparai.app.core.database.daos.TopSellingProductSummary
import com.vyaparai.app.core.database.entities.*
import kotlinx.coroutines.flow.Flow
import java.io.File

interface ProductRepository {
    fun getAllProducts(): Flow<List<ProductEntity>>
    suspend fun getProductById(id: Long): ProductEntity?
    suspend fun getProductByBarcode(barcode: String): ProductEntity?
    fun searchProducts(query: String): Flow<List<ProductEntity>>
    suspend fun searchProductsList(query: String): List<ProductEntity>
    fun getLowStockProducts(): Flow<List<ProductEntity>>
    fun getExpiringProducts(thresholdTimestamp: Long): Flow<List<ProductEntity>>
    fun getTotalValuation(): Flow<Double?>
    fun getProductCount(): Flow<Int>
    suspend fun insertOrUpdateProduct(product: ProductEntity, aliases: List<String> = emptyList()): Long
    suspend fun adjustStock(productId: Long, quantityChange: Double, reason: String, notes: String? = null)
    suspend fun deleteProduct(id: Long)
    suspend fun importProductsFromCsv(csvContent: String): Result<Int>
}

interface InvoiceRepository {
    fun getAllInvoices(): Flow<List<InvoiceWithItems>>
    suspend fun getInvoiceById(id: Long): InvoiceWithItems?
    suspend fun getInvoiceByNumber(number: String): InvoiceWithItems?
    fun getTodaySalesSum(): Flow<Double?>
    fun getTodayProfitSum(): Flow<Double?>
    fun getSalesSumBetween(start: Long, end: Long): Flow<Double?>
    fun getProfitSumBetween(start: Long, end: Long): Flow<Double?>
    fun getTopProducts(limit: Int = 5): Flow<List<TopSellingProductSummary>>
    suspend fun generateNextInvoiceNumber(): String
    suspend fun recordSalesReturn(salesReturn: SalesReturnEntity, items: List<SalesReturnItemEntity>)
}

interface CustomerKhataRepository {
    fun getAllCustomers(): Flow<List<CustomerEntity>>
    suspend fun getCustomerById(id: Long): CustomerEntity?
    fun searchCustomers(query: String): Flow<List<CustomerEntity>>
    suspend fun findCustomerByName(name: String): CustomerEntity?
    fun getKhataDebtors(): Flow<List<CustomerEntity>>
    fun getTotalPendingKhata(): Flow<Double?>
    suspend fun insertOrUpdateCustomer(customer: CustomerEntity): Long
    suspend fun recordKhataTransaction(
        customerId: Long,
        amount: Double,
        type: String, // SALE_CREDIT, PAYMENT_RECEIVED
        paymentMethod: String? = null,
        invoiceId: Long? = null,
        notes: String? = null
    )
    fun getCustomerTransactions(customerId: Long): Flow<List<CustomerTransactionEntity>>
    fun generateWhatsAppReminderMessage(customerName: String, businessName: String, balance: Double): String
}

interface SupplierPurchaseRepository {
    fun getAllSuppliers(): Flow<List<SupplierEntity>>
    suspend fun getSupplierById(id: Long): SupplierEntity?
    suspend fun insertOrUpdateSupplier(supplier: SupplierEntity): Long
    fun getAllPurchases(): Flow<List<PurchaseWithItems>>
    suspend fun getPurchaseById(id: Long): PurchaseWithItems?
    suspend fun createPurchase(purchase: PurchaseEntity, items: List<PurchaseItemEntity>): Long
    fun getAllPurchaseOrders(): Flow<List<PurchaseOrderWithItems>>
    suspend fun createPurchaseOrder(po: PurchaseOrderEntity, items: List<PurchaseOrderItemEntity>): Long
    suspend fun updatePurchaseOrderStatus(poId: Long, newStatus: String)
    fun getAllExpenses(): Flow<List<ExpenseEntity>>
    fun getTodayExpensesSum(): Flow<Double?>
    suspend fun addExpense(expense: ExpenseEntity): Long
}

interface SettingsRepository {
    fun getBusiness(): Flow<BusinessEntity?>
    suspend fun getBusinessOnce(): BusinessEntity?
    suspend fun saveBusiness(business: BusinessEntity): Long
    fun getInvoiceSettings(): Flow<InvoiceSettingsEntity?>
    suspend fun saveInvoiceSettings(settings: InvoiceSettingsEntity): Long
    fun getAppSettings(): Flow<AppSettingsEntity?>
    suspend fun saveAppSettings(settings: AppSettingsEntity): Long
    suspend fun loadDemoData(): Result<Unit>
    suspend fun clearDemoData(): Result<Unit>
}

interface BackupRepository {
    suspend fun createEncryptedBackup(context: android.content.Context): Result<File>
    suspend fun restoreEncryptedBackup(backupFile: File): Result<Unit>
    suspend fun detectExistingBackup(context: android.content.Context): File?
}
