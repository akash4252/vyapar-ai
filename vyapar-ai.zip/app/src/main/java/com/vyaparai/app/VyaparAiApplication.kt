package com.vyaparai.app

import android.app.Application
import com.vyaparai.app.core.di.AppContainer
import com.vyaparai.app.core.di.DefaultAppContainer

class VyaparAiApplication : Application() {

    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = DefaultAppContainer(this)
    }
}
