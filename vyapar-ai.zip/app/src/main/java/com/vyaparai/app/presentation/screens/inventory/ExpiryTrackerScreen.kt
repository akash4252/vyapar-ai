package com.vyaparai.app.presentation.screens.inventory

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.EventBusy
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vyaparai.app.VyaparAiApplication
import com.vyaparai.app.core.utils.DateUtils
import com.vyaparai.app.presentation.common.VyaparTopBar

@Composable
fun ExpiryTrackerScreen(
    onBackClick: () -> Unit
) {
    val context = LocalContext.current
    val app = context.applicationContext as VyaparAiApplication

    var selectedRangeDays by remember { mutableIntStateOf(30) } // 7, 30, 60

    val thresholdTimestamp = System.currentTimeMillis() + (selectedRangeDays.toLong() * 24 * 60 * 60 * 1000)
    val expiringProducts by app.container.productRepository.getExpiringProducts(thresholdTimestamp).collectAsState(initial = emptyList())

    Scaffold(
        topBar = {
            VyaparTopBar(
                title = "Expiry Tracker",
                subtitle = "Batch Expiry Monitoring",
                showBackButton = true,
                onBackClick = onBackClick
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
        ) {
            // Range Filter Tabs: 7 Days, 30 Days, 60 Days
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf(7, 30, 60).forEach { days ->
                    FilterChip(
                        selected = selectedRangeDays == days,
                        onClick = { selectedRangeDays = days },
                        label = { Text("Next $days Days") },
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            if (expiringProducts.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.EventBusy,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.outline,
                            modifier = Modifier.size(64.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "No Products Expiring in $selectedRangeDays Days",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "All batches are well within shelf life.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(expiringProducts) { product ->
                        val daysLeft = if (product.expiryDate != null) DateUtils.getDaysDifference(product.expiryDate) else 0
                        val isExpired = daysLeft <= 0
                        val badgeBg = if (isExpired) Color(0xFFFEE2E2) else Color(0xFFFEF3C7)
                        val badgeText = if (isExpired) Color(0xFFDC2626) else Color(0xFFD97706)

                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .padding(14.dp)
                                    .fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(text = product.name, fontWeight = FontWeight.Bold)
                                    Text(
                                        text = "Stock: ${product.currentStock.toInt()} ${product.unit} | Batch: ${product.batchNumber ?: "N/A"}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    if (product.expiryDate != null) {
                                        Text(
                                            text = "Expiry: ${DateUtils.formatDate(product.expiryDate)}",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                                Box(
                                    modifier = Modifier
                                        .background(badgeBg, shape = RoundedCornerShape(6.dp))
                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Text(
                                        text = if (isExpired) "EXPIRED" else "$daysLeft days left",
                                        color = badgeText,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 11.sp
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
