package com.vyaparai.app.data.demo

import androidx.room.withTransaction
import com.vyaparai.app.core.database.AppDatabase
import com.vyaparai.app.core.database.entities.*

object DemoDataPopulator {

    suspend fun populateDemoStore(database: AppDatabase) {
        database.withTransaction {
            val settingsDao = database.settingsBusinessDao()
            val productDao = database.productDao()
            val customerDao = database.customerKhataDao()
            val supplierDao = database.supplierPurchaseDao()

            // 1. Business Info
            settingsDao.insertOrUpdateBusiness(
                BusinessEntity(
                    id = 1,
                    name = "Shree Ganesh General Store",
                    ownerName = "Ganesh Patil",
                    mobile = "9876543210",
                    email = "shreeganeshstore@vyaparai.in",
                    address = "Shop No. 4, Market Road, Near Gandhi Chowk",
                    city = "Pune",
                    state = "Maharashtra",
                    pinCode = "411001",
                    gstin = "27ABCDE1234F1Z5",
                    upiId = "shreeganesh@upi",
                    shopType = "Kirana"
                )
            )

            settingsDao.insertOrUpdateInvoiceSettings(
                InvoiceSettingsEntity(
                    id = 1,
                    prefix = "VX-2026-",
                    startingNumber = 1,
                    nextInvoiceNumber = 1,
                    isGstEnabled = true,
                    isTaxInclusiveDefault = true
                )
            )

            // 2. Categories
            val catGrocery = productDao.insertCategory(CategoryEntity(name = "Grocery & Staples", colorHex = "#0F763E"))
            val catSnacks = productDao.insertCategory(CategoryEntity(name = "Snacks & Instant", colorHex = "#D97706"))
            val catPersonal = productDao.insertCategory(CategoryEntity(name = "Personal Care", colorHex = "#2563EB"))
            val catStationery = productDao.insertCategory(CategoryEntity(name = "Stationery", colorHex = "#7C3AED"))

            // 3. Products with Multi-lingual Aliases
            val p1 = productDao.insertProduct(
                ProductEntity(
                    name = "Maggi 2-Minute Noodles 70g",
                    barcode = "8901058852371",
                    sku = "MAG-70",
                    categoryId = catSnacks,
                    unit = "pcs",
                    purchasePrice = 8.0,
                    sellingPrice = 10.0,
                    mrp = 12.0,
                    gstRate = 5.0,
                    openingStock = 20.0,
                    currentStock = 20.0,
                    minimumStock = 5.0,
                    maximumStock = 50.0
                )
            )
            productDao.insertAliases(
                listOf(
                    ProductAliasEntity(productId = p1, alias = "Maggi", language = "EN"),
                    ProductAliasEntity(productId = p1, alias = "Maggie", language = "EN"),
                    ProductAliasEntity(productId = p1, alias = "मैगी", language = "HI"),
                    ProductAliasEntity(productId = p1, alias = "मॅगी", language = "MR")
                )
            )

            val p2 = productDao.insertProduct(
                ProductEntity(
                    name = "Madhur Pure Sugar 1kg",
                    barcode = "8906010040012",
                    sku = "SUG-1KG",
                    categoryId = catGrocery,
                    unit = "kg",
                    purchasePrice = 38.0,
                    sellingPrice = 42.0,
                    mrp = 45.0,
                    gstRate = 0.0,
                    openingStock = 50.0,
                    currentStock = 50.0,
                    minimumStock = 10.0,
                    maximumStock = 100.0
                )
            )
            productDao.insertAliases(
                listOf(
                    ProductAliasEntity(productId = p2, alias = "Sugar", language = "EN"),
                    ProductAliasEntity(productId = p2, alias = "चीनी", language = "HI"),
                    ProductAliasEntity(productId = p2, alias = "साखर", language = "MR")
                )
            )

            val p3 = productDao.insertProduct(
                ProductEntity(
                    name = "Basmati Rice Rozana 1kg",
                    barcode = "8901234567890",
                    sku = "RIC-1KG",
                    categoryId = catGrocery,
                    unit = "kg",
                    purchasePrice = 65.0,
                    sellingPrice = 80.0,
                    mrp = 90.0,
                    gstRate = 0.0,
                    openingStock = 30.0,
                    currentStock = 30.0,
                    minimumStock = 8.0,
                    maximumStock = 60.0
                )
            )
            productDao.insertAliases(
                listOf(
                    ProductAliasEntity(productId = p3, alias = "Rice", language = "EN"),
                    ProductAliasEntity(productId = p3, alias = "चावल", language = "HI"),
                    ProductAliasEntity(productId = p3, alias = "तांदूळ", language = "MR")
                )
            )

            val p4 = productDao.insertProduct(
                ProductEntity(
                    name = "Amul Taaza Milk 500ml",
                    barcode = "8901262010052",
                    sku = "MLK-500",
                    categoryId = catGrocery,
                    unit = "packet",
                    purchasePrice = 25.0,
                    sellingPrice = 28.0,
                    mrp = 28.0,
                    gstRate = 0.0,
                    openingStock = 25.0,
                    currentStock = 25.0,
                    minimumStock = 5.0,
                    maximumStock = 40.0
                )
            )
            productDao.insertAliases(
                listOf(
                    ProductAliasEntity(productId = p4, alias = "Milk", language = "EN"),
                    ProductAliasEntity(productId = p4, alias = "दूध", language = "HI"),
                    ProductAliasEntity(productId = p4, alias = "दूध", language = "MR")
                )
            )

            val p5 = productDao.insertProduct(
                ProductEntity(
                    name = "Tata Tea Gold 250g",
                    barcode = "8901052002130",
                    sku = "TEA-250",
                    categoryId = catGrocery,
                    unit = "packet",
                    purchasePrice = 110.0,
                    sellingPrice = 135.0,
                    mrp = 145.0,
                    gstRate = 5.0,
                    openingStock = 15.0,
                    currentStock = 15.0,
                    minimumStock = 4.0,
                    maximumStock = 30.0
                )
            )
            productDao.insertAliases(
                listOf(
                    ProductAliasEntity(productId = p5, alias = "Tea", language = "EN"),
                    ProductAliasEntity(productId = p5, alias = "चाय", language = "HI"),
                    ProductAliasEntity(productId = p5, alias = "चहा", language = "MR")
                )
            )

            val p6 = productDao.insertProduct(
                ProductEntity(
                    name = "Parle-G Gold Biscuits 100g",
                    barcode = "8901719101015",
                    sku = "BIS-100",
                    categoryId = catSnacks,
                    unit = "packet",
                    purchasePrice = 8.5,
                    sellingPrice = 10.0,
                    mrp = 10.0,
                    gstRate = 18.0,
                    openingStock = 40.0,
                    currentStock = 40.0,
                    minimumStock = 10.0,
                    maximumStock = 80.0
                )
            )
            productDao.insertAliases(
                listOf(
                    ProductAliasEntity(productId = p6, alias = "Biscuits", language = "EN"),
                    ProductAliasEntity(productId = p6, alias = "Parle-G", language = "EN"),
                    ProductAliasEntity(productId = p6, alias = "बिस्कुट", language = "HI"),
                    ProductAliasEntity(productId = p6, alias = "बिस्कीट", language = "MR")
                )
            )

            val p7 = productDao.insertProduct(
                ProductEntity(
                    name = "Dettol Bathing Soap 75g",
                    barcode = "8901396112001",
                    sku = "SOP-75",
                    categoryId = catPersonal,
                    unit = "pcs",
                    purchasePrice = 30.0,
                    sellingPrice = 38.0,
                    mrp = 40.0,
                    gstRate = 18.0,
                    openingStock = 20.0,
                    currentStock = 20.0,
                    minimumStock = 5.0,
                    maximumStock = 40.0
                )
            )
            productDao.insertAliases(
                listOf(
                    ProductAliasEntity(productId = p7, alias = "Soap", language = "EN"),
                    ProductAliasEntity(productId = p7, alias = "साबुन", language = "HI"),
                    ProductAliasEntity(productId = p7, alias = "साबण", language = "MR")
                )
            )

            // 4. Customers
            val c1 = customerDao.insertCustomer(
                CustomerEntity(
                    name = "Rahul Sharma",
                    mobile = "9822012345",
                    address = "Near Ganesh Temple, Pune",
                    openingBalance = 0.0,
                    currentCreditBalance = 0.0,
                    totalSpent = 450.0,
                    loyaltyPoints = 4
                )
            )
            customerDao.insertCustomer(
                CustomerEntity(
                    name = "Amit Deshmukh",
                    mobile = "9822054321",
                    address = "Flat 201, Shanti Heights",
                    openingBalance = 0.0,
                    currentCreditBalance = 0.0,
                    totalSpent = 1200.0,
                    loyaltyPoints = 12
                )
            )
            customerDao.insertCustomer(
                CustomerEntity(
                    name = "Priya Joshi",
                    mobile = "9822099887",
                    address = "Plot 14, Ideal Colony",
                    openingBalance = 0.0,
                    currentCreditBalance = 0.0,
                    totalSpent = 850.0,
                    loyaltyPoints = 8
                )
            )
            customerDao.insertCustomer(
                CustomerEntity(
                    name = "Sneha Kulkarni",
                    mobile = "9822077665",
                    address = "B-Wing, Sai Residency",
                    openingBalance = 0.0,
                    currentCreditBalance = 0.0,
                    totalSpent = 300.0,
                    loyaltyPoints = 3
                )
            )

            // 5. Suppliers
            supplierDao.insertSupplier(
                SupplierEntity(
                    name = "ABC Distributors Pvt Ltd",
                    companyName = "ABC Distributors",
                    mobile = "9890123456",
                    gstin = "27AABCA1234F1Z8",
                    address = "Marketyard, Gultekdi, Pune",
                    openingBalance = 0.0,
                    currentOutstanding = 0.0
                )
            )
            supplierDao.insertSupplier(
                SupplierEntity(
                    name = "Maharashtra Wholesale Traders",
                    companyName = "Maharashtra Wholesale",
                    mobile = "9890654321",
                    gstin = "27AABCM5678F1Z2",
                    address = "Bhawani Peth, Pune",
                    openingBalance = 0.0,
                    currentOutstanding = 0.0
                )
            )
        }
    }

    suspend fun clearAllData(database: AppDatabase) {
        database.withTransaction {
            database.clearAllTables()
        }
    }
}
