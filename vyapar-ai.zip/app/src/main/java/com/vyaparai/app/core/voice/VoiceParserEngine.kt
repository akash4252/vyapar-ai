package com.vyaparai.app.core.voice

sealed interface VoiceCommandResult {
    data class BillingCommand(
        val items: List<ParsedVoiceItem>,
        val customerName: String? = null,
        val paymentMethod: String? = null,
        val isCredit: Boolean = false
    ) : VoiceCommandResult

    data class KhataCreditCommand(
        val customerName: String,
        val amount: Double,
        val notes: String? = null
    ) : VoiceCommandResult

    data class KhataPaymentCommand(
        val customerName: String,
        val amount: Double,
        val notes: String? = null
    ) : VoiceCommandResult

    data class KhataQueryCommand(
        val customerName: String
    ) : VoiceCommandResult

    data class BusinessQueryCommand(
        val queryType: BusinessQueryType
    ) : VoiceCommandResult

    data class UnknownCommand(
        val rawSpeech: String
    ) : VoiceCommandResult
}

enum class BusinessQueryType {
    TODAY_SALES,
    TODAY_PROFIT,
    LOW_STOCK,
    TOP_PRODUCTS,
    MONTHLY_SALES,
    PURCHASE_SUGGESTIONS
}

data class ParsedVoiceItem(
    val productName: String,
    val quantity: Double = 1.0,
    val unit: String = "pcs",
    val price: Double? = null
)

object VoiceParserEngine {

    fun parse(rawSpeech: String): VoiceCommandResult {
        if (rawSpeech.isBlank()) return VoiceCommandResult.UnknownCommand(rawSpeech)

        val normalized = HindiMarathiNormalizer.normalizeDevanagariDigits(rawSpeech).trim()
        val lower = normalized.lowercase()

        // 1. Check Business Intelligence queries (Marathi / Hindi / English)
        if (lower.contains("vikri") || lower.contains("bikri") || lower.contains("sales") || lower.contains("विक्री") || lower.contains("बिक्री")) {
            return if (lower.contains("month") || lower.contains("mahina") || lower.contains("mahinayachi") || lower.contains("महिना")) {
                VoiceCommandResult.BusinessQueryCommand(BusinessQueryType.MONTHLY_SALES)
            } else {
                VoiceCommandResult.BusinessQueryCommand(BusinessQueryType.TODAY_SALES)
            }
        }
        if (lower.contains("profit") || lower.contains("munafa") || lower.contains("fayda") || lower.contains("नफा") || lower.contains("मुनाफा")) {
            return VoiceCommandResult.BusinessQueryCommand(BusinessQueryType.TODAY_PROFIT)
        }
        if (lower.contains("low stock") || lower.contains("stock kami") || lower.contains("stock kam") || lower.contains("स्टॉक कमी") || lower.contains("कम स्टॉक")) {
            return VoiceCommandResult.BusinessQueryCommand(BusinessQueryType.LOW_STOCK)
        }
        if (lower.contains("top product") || lower.contains("jasta vikla") || lower.contains("jyada bika") || lower.contains("विकला")) {
            return VoiceCommandResult.BusinessQueryCommand(BusinessQueryType.TOP_PRODUCTS)
        }
        if (lower.contains("purchase karaycha") || lower.contains("order karu") || lower.contains("खरीदी")) {
            return VoiceCommandResult.BusinessQueryCommand(BusinessQueryType.PURCHASE_SUGGESTIONS)
        }

        // 2. Check Voice Khata Commands
        // Examples: "Rahul ko 500 udhaar", "Rahul ke naam 500 likho", "Rahulला ५०० उधार"
        val udhaarRegex = Regex("""([a-zA-Z\u0900-\u097F]+)\s*(?:ko|ke naam|la|ला|को)?\s*(\d+(?:\.\d+)?)\s*(?:rupaye|rupees|rs|रुपये)?\s*(?:udhaar|udhar|likho|उधार|लिहा)""", RegexOption.IGNORE_CASE)
        val udhaarMatch = udhaarRegex.find(normalized)
        if (udhaarMatch != null) {
            val customer = udhaarMatch.groupValues[1].trim()
            val amount = udhaarMatch.groupValues[2].toDoubleOrNull() ?: 0.0
            return VoiceCommandResult.KhataCreditCommand(customerName = customer, amount = amount)
        }

        // Examples: "Rahul ne 300 diye", "Priya ka 200 jama karo", "Rahulने ३०० दिले"
        val jamaRegex = Regex("""([a-zA-Z\u0900-\u097F]+)\s*(?:ne|ka|ne|ने|चा|ने)?\s*(\d+(?:\.\d+)?)\s*(?:rupaye|rupees|rs|रुपये)?\s*(?:diye|jama|jama karo|dile|दिले|जमा)""", RegexOption.IGNORE_CASE)
        val jamaMatch = jamaRegex.find(normalized)
        if (jamaMatch != null) {
            val customer = jamaMatch.groupValues[1].trim()
            val amount = jamaMatch.groupValues[2].toDoubleOrNull() ?: 0.0
            return VoiceCommandResult.KhataPaymentCommand(customerName = customer, amount = amount)
        }

        // Examples: "Rahul ka khata dikhao", "Rahul ka balance kitna hai", "Rahulचे खाते दाखवा"
        val khataQueryRegex = Regex("""([a-zA-Z\u0900-\u097F]+)\s*(?:ka|ke|che|चे|चा|का)?\s*(?:khata|balance|khate|खाते|बैलन्स)""", RegexOption.IGNORE_CASE)
        val khataQueryMatch = khataQueryRegex.find(normalized)
        if (khataQueryMatch != null) {
            val customer = khataQueryMatch.groupValues[1].trim()
            return VoiceCommandResult.KhataQueryCommand(customerName = customer)
        }

        // 3. Billing Parser
        // Support comma or 'and' / 'aur' / 'आणि' multi-item clauses
        val splitClauses = normalized.split(Regex("""(?i)\s+(?:and|aur|aani|ani|व|आणि|और|,)\s+"""))
        val parsedItems = mutableListOf<ParsedVoiceItem>()
        var extractedCustomer: String? = null

        // Check if customer name mentioned at beginning: "Rahul ke naam pe Maggi 3" or "Customer Amit: Maggi 2"
        var workingText = normalized
        val customerPrefixRegex = Regex("""^(?:customer|for|ke naam pe|naam)\s+([a-zA-Z\u0900-\u097F]+)[:\s]+""", RegexOption.IGNORE_CASE)
        val customerPrefixMatch = customerPrefixRegex.find(workingText)
        if (customerPrefixMatch != null) {
            extractedCustomer = customerPrefixMatch.groupValues[1].trim()
            workingText = workingText.substring(customerPrefixMatch.range.last + 1).trim()
        }

        val clausesToParse = if (extractedCustomer != null) {
            workingText.split(Regex("""(?i)\s+(?:and|aur|aani|ani|व|आणि|और|,)\s+"""))
        } else {
            splitClauses
        }

        for (clause in clausesToParse) {
            val item = parseSingleItemClause(clause)
            if (item != null) {
                parsedItems.add(item)
            }
        }

        if (parsedItems.isNotEmpty()) {
            return VoiceCommandResult.BillingCommand(
                items = parsedItems,
                customerName = extractedCustomer
            )
        }

        return VoiceCommandResult.UnknownCommand(rawSpeech)
    }

    private fun parseSingleItemClause(clause: String): ParsedVoiceItem? {
        val trimmed = clause.trim()
        if (trimmed.isBlank()) return null

        val tokens = trimmed.split(Regex("""\s+"""))
        if (tokens.isEmpty()) return null

        // Pattern A: "Sugar 2kg 80 rupees" -> [Sugar, 2, kg, 80, rupees]
        // Pattern B: "Maggi 2" -> [Maggi, 2]
        // Pattern C: "Milk 3 packets" -> [Milk, 3, packets]
        // Pattern D: "मैगी दो" -> [मैगी, दो]
        // Pattern E: "2 kg Sugar" -> [2, kg, Sugar]

        var productName = ""
        var quantity = 1.0
        var unit = "pcs"
        var price: Double? = null

        var i = 0
        val nameTokens = mutableListOf<String>()

        while (i < tokens.size) {
            val token = tokens[i]
            val lowerToken = token.lowercase()

            // Check if price indicator: "80 rupees", "rs 80", "₹80"
            if (lowerToken.startsWith("₹") || lowerToken == "rs" || lowerToken == "rupees" || lowerToken == "rupaye" || lowerToken == "रुपये") {
                if (lowerToken.startsWith("₹")) {
                    price = lowerToken.substring(1).toDoubleOrNull()
                } else if (i + 1 < tokens.size) {
                    val nextNum = HindiMarathiNormalizer.parseNumber(tokens[i + 1])
                    if (nextNum != null) {
                        price = nextNum
                        i++
                    }
                }
                i++
                continue
            }

            // Check attached quantity+unit like "2kg" or "500g"
            val qtyUnitRegex = Regex("""^(\d+(?:\.\d+)?)([a-zA-Z\u0900-\u097F]+)$""")
            val qtyUnitMatch = qtyUnitRegex.find(token)
            if (qtyUnitMatch != null) {
                quantity = qtyUnitMatch.groupValues[1].toDoubleOrNull() ?: 1.0
                unit = HindiMarathiNormalizer.normalizeUnit(qtyUnitMatch.groupValues[2]) ?: "pcs"
                i++
                continue
            }

            // Check if numeric token
            val num = HindiMarathiNormalizer.parseNumber(token)
            if (num != null) {
                // Peek next token: is it a unit? ("kg", "litre", "packet")
                if (i + 1 < tokens.size) {
                    val nextUnit = HindiMarathiNormalizer.normalizeUnit(tokens[i + 1])
                    if (nextUnit != null) {
                        quantity = num
                        unit = nextUnit
                        i += 2
                        continue
                    }
                }
                // Peek next token: is it "rupees"?
                if (i + 1 < tokens.size && (tokens[i + 1].equals("rupees", true) || tokens[i + 1].equals("rupaye", true) || tokens[i + 1].equals("रुपये", true))) {
                    price = num
                    i += 2
                    continue
                }
                // Otherwise it's item quantity
                quantity = num
                i++
                continue
            }

            // Check standalone unit token
            val standaloneUnit = HindiMarathiNormalizer.normalizeUnit(token)
            if (standaloneUnit != null) {
                unit = standaloneUnit
                i++
                continue
            }

            // Token is part of product name
            nameTokens.add(token)
            i++
        }

        productName = nameTokens.joinToString(" ").trim()
        if (productName.isBlank()) return null

        return ParsedVoiceItem(
            productName = productName,
            quantity = quantity,
            unit = unit,
            price = price
        )
    }
}
