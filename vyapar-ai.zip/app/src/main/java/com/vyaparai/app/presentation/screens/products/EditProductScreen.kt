package com.vyaparai.app.presentation.screens.products

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.vyaparai.app.VyaparAiApplication
import com.vyaparai.app.core.database.entities.ProductEntity
import com.vyaparai.app.presentation.common.ConfirmActionDialog
import com.vyaparai.app.presentation.common.VyaparPrimaryButton
import com.vyaparai.app.presentation.common.VyaparTopBar
import kotlinx.coroutines.launch

@Composable
fun EditProductScreen(
    productId: Long,
    onSuccess: () -> Unit,
    onBackClick: () -> Unit
) {
    val context = LocalContext.current
    val app = context.applicationContext as VyaparAiApplication
    val scope = rememberCoroutineScope()

    var product by remember { mutableStateOf<ProductEntity?>(null) }
    var name by remember { mutableStateOf("") }
    var barcode by remember { mutableStateOf("") }
    var sellingPrice by remember { mutableStateOf("") }
    var purchasePrice by remember { mutableStateOf("") }
    var currentStock by remember { mutableStateOf("") }
    var minimumStock by remember { mutableStateOf("") }
    var showDeleteDialog by remember { mutableStateOf(false) }

    LaunchedEffect(productId) {
        val p = app.container.productRepository.getProductById(productId)
        if (p != null) {
            product = p
            name = p.name
            barcode = p.barcode ?: ""
            sellingPrice = p.sellingPrice.toString()
            purchasePrice = p.purchasePrice.toString()
            currentStock = p.currentStock.toString()
            minimumStock = p.minimumStock.toString()
        }
    }

    Scaffold(
        topBar = {
            VyaparTopBar(
                title = "Edit Product",
                showBackButton = true,
                onBackClick = onBackClick,
                actions = {
                    IconButton(onClick = { showDeleteDialog = true }) {
                        Icon(Icons.Default.Delete, contentDescription = "Delete Product")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(20.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Product Name") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                )
                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = barcode,
                    onValueChange = { barcode = it },
                    label = { Text("Barcode") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                )
                Spacer(modifier = Modifier.height(12.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedTextField(
                        value = sellingPrice,
                        onValueChange = { sellingPrice = it },
                        label = { Text("Selling Price (₹)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(12.dp)
                    )
                    OutlinedTextField(
                        value = purchasePrice,
                        onValueChange = { purchasePrice = it },
                        label = { Text("Purchase Price (₹)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(12.dp)
                    )
                }
                Spacer(modifier = Modifier.height(12.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedTextField(
                        value = currentStock,
                        onValueChange = { currentStock = it },
                        label = { Text("Current Stock") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(12.dp)
                    )
                    OutlinedTextField(
                        value = minimumStock,
                        onValueChange = { minimumStock = it },
                        label = { Text("Minimum Stock") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(12.dp)
                    )
                }
            }

            VyaparPrimaryButton(
                text = "UPDATE PRODUCT",
                onClick = {
                    val p = product ?: return@VyaparPrimaryButton
                    val sPrice = sellingPrice.toDoubleOrNull() ?: p.sellingPrice
                    val pPrice = purchasePrice.toDoubleOrNull() ?: p.purchasePrice
                    val cStock = currentStock.toDoubleOrNull() ?: p.currentStock
                    val mStock = minimumStock.toDoubleOrNull() ?: p.minimumStock

                    scope.launch {
                        app.container.productRepository.insertOrUpdateProduct(
                            p.copy(
                                name = name.trim(),
                                barcode = barcode.trim().takeIf { it.isNotBlank() },
                                sellingPrice = sPrice,
                                purchasePrice = pPrice,
                                currentStock = cStock,
                                minimumStock = mStock,
                                updatedAt = System.currentTimeMillis()
                            )
                        )
                        onSuccess()
                    }
                },
                icon = Icons.Default.Save
            )
        }

        if (showDeleteDialog) {
            ConfirmActionDialog(
                title = "Delete Product",
                message = "Are you sure you want to remove ${product?.name} from your catalog?",
                confirmText = "Delete",
                onConfirm = {
                    scope.launch {
                        app.container.productRepository.deleteProduct(productId)
                        showDeleteDialog = false
                        onSuccess()
                    }
                },
                onDismiss = { showDeleteDialog = false }
            )
        }
    }
}
