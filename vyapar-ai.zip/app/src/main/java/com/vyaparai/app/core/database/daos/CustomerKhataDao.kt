package com.vyaparai.app.core.database.daos

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.vyaparai.app.core.database.entities.CustomerEntity
import com.vyaparai.app.core.database.entities.CustomerTransactionEntity
import com.vyaparai.app.core.database.entities.LoyaltyAccountEntity
import com.vyaparai.app.core.database.entities.LoyaltyTransactionEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface CustomerKhataDao {
    @Query("SELECT * FROM customers ORDER BY name ASC")
    fun getAllCustomersFlow(): Flow<List<CustomerEntity>>

    @Query("SELECT * FROM customers ORDER BY name ASC")
    suspend fun getAllCustomers(): List<CustomerEntity>

    @Query("SELECT * FROM customers WHERE id = :id")
    suspend fun getCustomerById(id: Long): CustomerEntity?

    @Query("SELECT * FROM customers WHERE name LIKE '%' || :query || '%' OR mobile LIKE '%' || :query || '%'")
    fun searchCustomers(query: String): Flow<List<CustomerEntity>>

    @Query("SELECT * FROM customers WHERE name LIKE :name LIMIT 1")
    suspend fun findCustomerByName(name: String): CustomerEntity?

    @Query("SELECT * FROM customers WHERE currentCreditBalance > 0 ORDER BY currentCreditBalance DESC")
    fun getKhataDebtorsFlow(): Flow<List<CustomerEntity>>

    @Query("SELECT SUM(currentCreditBalance) FROM customers")
    fun getTotalPendingKhataFlow(): Flow<Double?>

    @Query("SELECT SUM(currentCreditBalance) FROM customers")
    suspend fun getTotalPendingKhata(): Double?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCustomer(customer: CustomerEntity): Long

    @Update
    suspend fun updateCustomer(customer: CustomerEntity)

    @Query("UPDATE customers SET currentCreditBalance = currentCreditBalance + :delta, totalSpent = totalSpent + :spentDelta WHERE id = :customerId")
    suspend fun updateCustomerBalance(customerId: Long, delta: Double, spentDelta: Double = 0.0)

    // Customer / Khata Transactions
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCustomerTransaction(transaction: CustomerTransactionEntity): Long

    @Query("SELECT * FROM customer_transactions WHERE customerId = :customerId ORDER BY date DESC")
    fun getCustomerTransactionsFlow(customerId: Long): Flow<List<CustomerTransactionEntity>>

    @Query("SELECT * FROM customer_transactions WHERE customerId = :customerId ORDER BY date DESC")
    suspend fun getCustomerTransactions(customerId: Long): List<CustomerTransactionEntity>

    // Loyalty
    @Query("SELECT * FROM loyalty_accounts WHERE customerId = :customerId LIMIT 1")
    suspend fun getLoyaltyAccount(customerId: Long): LoyaltyAccountEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateLoyaltyAccount(account: LoyaltyAccountEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLoyaltyTransaction(tx: LoyaltyTransactionEntity): Long

    @Query("SELECT * FROM loyalty_transactions WHERE customerId = :customerId ORDER BY date DESC")
    fun getLoyaltyTransactionsFlow(customerId: Long): Flow<List<LoyaltyTransactionEntity>>
}
