package com.vyaparai.app.presentation.navigation

import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.navArgument
import com.vyaparai.app.presentation.screens.ai.AiBusinessAssistantScreen
import com.vyaparai.app.presentation.screens.backup.BackupRestoreScreen
import com.vyaparai.app.presentation.screens.billing.*
import com.vyaparai.app.presentation.screens.dashboard.DashboardHomeScreen
import com.vyaparai.app.presentation.screens.expenses.ExpenseManagerScreen
import com.vyaparai.app.presentation.screens.inventory.*
import com.vyaparai.app.presentation.screens.khata.*
import com.vyaparai.app.presentation.screens.launch.SplashScreen
import com.vyaparai.app.presentation.screens.onboarding.*
import com.vyaparai.app.presentation.screens.products.*
import com.vyaparai.app.presentation.screens.purchases.*
import com.vyaparai.app.presentation.screens.reports.*
import com.vyaparai.app.presentation.screens.security.AppLockSecurityScreen
import com.vyaparai.app.presentation.screens.settings.LanguageSettingsScreen
import com.vyaparai.app.presentation.screens.settings.PrinterSettingsScreen
import com.vyaparai.app.presentation.screens.settings.SettingsHubScreen
import com.vyaparai.app.presentation.screens.suppliers.SupplierListScreen
import com.vyaparai.app.presentation.screens.suppliers.SupplierProfileDetailScreen

@Composable
fun VyaparNavHost(navController: NavHostController) {
    Scaffold(
        bottomBar = { VyaparBottomBar(navController = navController) }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = NavRoutes.Splash.route,
            modifier = Modifier.padding(innerPadding)
        ) {
            // Launch & Onboarding
            composable(NavRoutes.Splash.route) {
                SplashScreen(
                    onNavigateToHome = {
                        navController.navigate(NavRoutes.Dashboard.route) {
                            popUpTo(NavRoutes.Splash.route) { inclusive = true }
                        }
                    },
                    onNavigateToOnboarding = {
                        navController.navigate(NavRoutes.OnboardingWelcome.route) {
                            popUpTo(NavRoutes.Splash.route) { inclusive = true }
                        }
                    },
                    onNavigateToLock = {
                        navController.navigate(NavRoutes.AppLockSecurity.route) {
                            popUpTo(NavRoutes.Splash.route) { inclusive = true }
                        }
                    }
                )
            }

            composable(NavRoutes.AppLockSecurity.route) {
                AppLockSecurityScreen(
                    onUnlockSuccess = {
                        navController.navigate(NavRoutes.Dashboard.route) {
                            popUpTo(NavRoutes.AppLockSecurity.route) { inclusive = true }
                        }
                    }
                )
            }

            composable(NavRoutes.OnboardingWelcome.route) {
                OnboardingWelcomeScreen(
                    onGetStartedClick = { navController.navigate(NavRoutes.ShopTypeSelection.route) },
                    onDemoLoaded = {
                        navController.navigate(NavRoutes.Dashboard.route) {
                            popUpTo(NavRoutes.OnboardingWelcome.route) { inclusive = true }
                        }
                    }
                )
            }

            composable(NavRoutes.ShopTypeSelection.route) {
                ShopTypeSelectionScreen(
                    onShopTypeSelected = { shopType ->
                        navController.navigate(NavRoutes.BusinessDetailsSetup.route)
                    },
                    onBackClick = { navController.popBackStack() }
                )
            }

            composable(NavRoutes.BusinessDetailsSetup.route) {
                BusinessDetailsSetupScreen(
                    shopType = "Kirana",
                    onSuccess = { navController.navigate(NavRoutes.InvoiceSettingsSetup.route) },
                    onBackClick = { navController.popBackStack() }
                )
            }

            composable(NavRoutes.InvoiceSettingsSetup.route) {
                InvoiceSettingsSetupScreen(
                    onSuccess = { navController.navigate(NavRoutes.SecuritySetup.route) },
                    onBackClick = { navController.popBackStack() }
                )
            }

            composable(NavRoutes.SecuritySetup.route) {
                SecuritySetupScreen(
                    onSuccess = { navController.navigate(NavRoutes.BackupSetup.route) },
                    onBackClick = { navController.popBackStack() }
                )
            }

            composable(NavRoutes.BackupSetup.route) {
                BackupSetupScreen(
                    onFinishSetup = {
                        navController.navigate(NavRoutes.Dashboard.route) {
                            popUpTo(NavRoutes.OnboardingWelcome.route) { inclusive = true }
                        }
                    },
                    onBackClick = { navController.popBackStack() }
                )
            }

            // Main Dashboard
            composable(NavRoutes.Dashboard.route) {
                DashboardHomeScreen(
                    onNewBillClick = { navController.navigate(NavRoutes.FastBilling.route) },
                    onVoiceBillClick = { navController.navigate(NavRoutes.FastBilling.route) },
                    onScanClick = { navController.navigate(NavRoutes.BarcodeScanner.route) },
                    onKhataClick = { navController.navigate(NavRoutes.DigitalKhata.route) },
                    onPurchaseClick = { navController.navigate(NavRoutes.NewPurchase.route) },
                    onReportsClick = { navController.navigate(NavRoutes.ReportsHub.route) },
                    onProductClick = { productId -> navController.navigate(NavRoutes.EditProduct.createRoute(productId)) },
                    onInvoiceClick = { invoiceNumber -> navController.navigate(NavRoutes.InvoiceSuccessPreview.createRoute(invoiceNumber)) },
                    onAiAssistantClick = { navController.navigate(NavRoutes.AiBusinessAssistant.route) }
                )
            }

            // POS Billing
            composable(NavRoutes.FastBilling.route) {
                FastBillingPosScreen(
                    onScanBarcodeClick = { navController.navigate(NavRoutes.BarcodeScanner.route) },
                    onCheckoutClick = { cartItems, customer ->
                        navController.navigate(NavRoutes.PaymentCheckout.route)
                    },
                    onBackClick = { navController.popBackStack() }
                )
            }

            composable(NavRoutes.BarcodeScanner.route) {
                BarcodeScannerScreen(
                    onProductFound = { navController.navigate(NavRoutes.FastBilling.route) },
                    onAddNewProduct = { barcode -> navController.navigate(NavRoutes.AddProduct.route) },
                    onBackClick = { navController.popBackStack() }
                )
            }

            composable(NavRoutes.PaymentCheckout.route) {
                PaymentCheckoutScreen(
                    cartItems = emptyList(),
                    customer = null,
                    onInvoiceCreated = { invoiceNumber ->
                        navController.navigate(NavRoutes.InvoiceSuccessPreview.createRoute(invoiceNumber)) {
                            popUpTo(NavRoutes.FastBilling.route) { inclusive = true }
                        }
                    },
                    onBackClick = { navController.popBackStack() }
                )
            }

            composable(
                route = NavRoutes.InvoiceSuccessPreview.route,
                arguments = listOf(navArgument("invoiceNumber") { type = NavType.StringType })
            ) { backStackEntry ->
                val invoiceNumber = backStackEntry.arguments?.getString("invoiceNumber") ?: "VX-2026-000001"
                InvoiceSuccessPreviewScreen(
                    invoiceNumber = invoiceNumber,
                    onNewBillClick = { navController.navigate(NavRoutes.FastBilling.route) },
                    onHomeClick = { navController.navigate(NavRoutes.Dashboard.route) }
                )
            }

            composable(NavRoutes.BillHistory.route) {
                BillHistoryScreen(
                    onInvoiceClick = { invoiceNumber -> navController.navigate(NavRoutes.InvoiceSuccessPreview.createRoute(invoiceNumber)) },
                    onBackClick = { navController.popBackStack() }
                )
            }

            // Inventory & Products
            composable(NavRoutes.InventoryDashboard.route) {
                InventoryDashboardScreen(
                    onProductListClick = { navController.navigate(NavRoutes.ProductList.route) },
                    onStockAdjustmentClick = { navController.navigate(NavRoutes.StockAdjustment.route) },
                    onLowStockClick = { navController.navigate(NavRoutes.LowStockAlerts.route) },
                    onExpiryTrackerClick = { navController.navigate(NavRoutes.ExpiryTracker.route) },
                    onSmartPoClick = { navController.navigate(NavRoutes.SmartPurchaseOrder.route) },
                    onBackClick = { navController.popBackStack() }
                )
            }

            composable(NavRoutes.ProductList.route) {
                ProductListScreen(
                    onAddProductClick = { navController.navigate(NavRoutes.AddProduct.route) },
                    onProductClick = { productId -> navController.navigate(NavRoutes.EditProduct.createRoute(productId)) },
                    onBackClick = { navController.popBackStack() }
                )
            }

            composable(NavRoutes.AddProduct.route) {
                AddProductScreen(
                    onSuccess = { navController.popBackStack() },
                    onBackClick = { navController.popBackStack() }
                )
            }

            composable(
                route = NavRoutes.EditProduct.route,
                arguments = listOf(navArgument("productId") { type = NavType.LongType })
            ) { backStackEntry ->
                val productId = backStackEntry.arguments?.getLong("productId") ?: 0L
                EditProductScreen(
                    productId = productId,
                    onSuccess = { navController.popBackStack() },
                    onBackClick = { navController.popBackStack() }
                )
            }

            composable(NavRoutes.StockAdjustment.route) {
                StockAdjustmentScreen(
                    onSuccess = { navController.popBackStack() },
                    onBackClick = { navController.popBackStack() }
                )
            }

            composable(NavRoutes.LowStockAlerts.route) {
                LowStockAlertsScreen(
                    onGeneratePoClick = { navController.navigate(NavRoutes.SmartPurchaseOrder.route) },
                    onBackClick = { navController.popBackStack() }
                )
            }

            composable(NavRoutes.ExpiryTracker.route) {
                ExpiryTrackerScreen(onBackClick = { navController.popBackStack() })
            }

            // Khata & Customers
            composable(NavRoutes.DigitalKhata.route) {
                DigitalKhataDashboardScreen(
                    onCustomerClick = { customerId -> navController.navigate(NavRoutes.CustomerProfile.createRoute(customerId)) },
                    onAddCustomerClick = { navController.navigate(NavRoutes.CustomerList.route) },
                    onLoyaltyClick = { navController.navigate(NavRoutes.CustomerLoyalty.route) },
                    onBackClick = { navController.popBackStack() }
                )
            }

            composable(NavRoutes.CustomerList.route) {
                CustomerListScreen(
                    onCustomerClick = { customerId -> navController.navigate(NavRoutes.CustomerProfile.createRoute(customerId)) },
                    onBackClick = { navController.popBackStack() }
                )
            }

            composable(
                route = NavRoutes.CustomerProfile.route,
                arguments = listOf(navArgument("customerId") { type = NavType.LongType })
            ) { backStackEntry ->
                val customerId = backStackEntry.arguments?.getLong("customerId") ?: 0L
                CustomerProfileDetailScreen(
                    customerId = customerId,
                    onAddTransactionClick = { cId -> navController.navigate(NavRoutes.AddKhataTransaction.createRoute(cId)) },
                    onBackClick = { navController.popBackStack() }
                )
            }

            composable(
                route = NavRoutes.AddKhataTransaction.route,
                arguments = listOf(navArgument("customerId") { type = NavType.LongType })
            ) { backStackEntry ->
                val customerId = backStackEntry.arguments?.getLong("customerId") ?: 0L
                AddKhataTransactionScreen(
                    customerId = customerId,
                    onSuccess = { navController.popBackStack() },
                    onBackClick = { navController.popBackStack() }
                )
            }

            composable(NavRoutes.CustomerLoyalty.route) {
                CustomerLoyaltyScreen(onBackClick = { navController.popBackStack() })
            }

            // Suppliers & Purchases
            composable(NavRoutes.SupplierList.route) {
                SupplierListScreen(
                    onSupplierClick = { supplierId -> navController.navigate(NavRoutes.SupplierProfile.createRoute(supplierId)) },
                    onBackClick = { navController.popBackStack() }
                )
            }

            composable(
                route = NavRoutes.SupplierProfile.route,
                arguments = listOf(navArgument("supplierId") { type = NavType.LongType })
            ) { backStackEntry ->
                val supplierId = backStackEntry.arguments?.getLong("supplierId") ?: 0L
                SupplierProfileDetailScreen(
                    supplierId = supplierId,
                    onBackClick = { navController.popBackStack() }
                )
            }

            composable(NavRoutes.NewPurchase.route) {
                NewPurchaseScreen(
                    onSuccess = { navController.popBackStack() },
                    onBackClick = { navController.popBackStack() }
                )
            }

            composable(NavRoutes.PurchaseHistory.route) {
                PurchaseHistoryScreen(
                    onNewPurchaseClick = { navController.navigate(NavRoutes.NewPurchase.route) },
                    onBackClick = { navController.popBackStack() }
                )
            }

            composable(NavRoutes.SmartPurchaseOrder.route) {
                SmartPurchaseOrderScreen(onBackClick = { navController.popBackStack() })
            }

            composable(NavRoutes.AiBillScanner.route) {
                AiBillScannerScreen(
                    onSuccess = { navController.navigate(NavRoutes.PurchaseHistory.route) },
                    onBackClick = { navController.popBackStack() }
                )
            }

            // Reports & Expenses
            composable(NavRoutes.ReportsHub.route) {
                ReportsHubScreen(
                    onSalesReportClick = { navController.navigate(NavRoutes.SalesReport.route) },
                    onProfitReportClick = { navController.navigate(NavRoutes.ProfitReport.route) },
                    onGstReportClick = { navController.navigate(NavRoutes.GstReport.route) },
                    onExpenseClick = { navController.navigate(NavRoutes.ExpenseManager.route) },
                    onBackClick = { navController.popBackStack() }
                )
            }

            composable(NavRoutes.SalesReport.route) {
                SalesReportScreen(onBackClick = { navController.popBackStack() })
            }

            composable(NavRoutes.ProfitReport.route) {
                ProfitReportScreen(onBackClick = { navController.popBackStack() })
            }

            composable(NavRoutes.GstReport.route) {
                GstReportScreen(onBackClick = { navController.popBackStack() })
            }

            composable(NavRoutes.ExpenseManager.route) {
                ExpenseManagerScreen(onBackClick = { navController.popBackStack() })
            }

            // AI Assistant
            composable(NavRoutes.AiBusinessAssistant.route) {
                AiBusinessAssistantScreen(onBackClick = { navController.popBackStack() })
            }

            // Settings & Hardware
            composable(NavRoutes.SettingsHub.route) {
                SettingsHubScreen(
                    onPrinterSettingsClick = { navController.navigate(NavRoutes.PrinterSettings.route) },
                    onAppLockClick = { navController.navigate(NavRoutes.AppLockSecurity.route) },
                    onBackupRestoreClick = { navController.navigate(NavRoutes.BackupRestore.route) },
                    onLanguageClick = { navController.navigate(NavRoutes.LanguageSettings.route) },
                    onBackClick = { navController.popBackStack() }
                )
            }

            composable(NavRoutes.PrinterSettings.route) {
                PrinterSettingsScreen(onBackClick = { navController.popBackStack() })
            }

            composable(NavRoutes.BackupRestore.route) {
                BackupRestoreScreen(onBackClick = { navController.popBackStack() })
            }

            composable(NavRoutes.LanguageSettings.route) {
                LanguageSettingsScreen(onBackClick = { navController.popBackStack() })
            }
        }
    }
}
