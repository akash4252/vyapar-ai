package com.vyaparai.app.data.repositories

import com.vyaparai.app.core.database.AppDatabase
import com.vyaparai.app.core.database.entities.InventoryTransactionEntity
import com.vyaparai.app.core.database.entities.ProductAliasEntity
import com.vyaparai.app.core.database.entities.ProductEntity
import com.vyaparai.app.core.database.entities.StockAdjustmentEntity
import com.vyaparai.app.domain.repositories.ProductRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

class ProductRepositoryImpl(
    private val database: AppDatabase
) : ProductRepository {

    private val productDao = database.productDao()

    override fun getAllProducts(): Flow<List<ProductEntity>> = productDao.getAllProductsFlow()

    override suspend fun getProductById(id: Long): ProductEntity? = withContext(Dispatchers.IO) {
        productDao.getProductById(id)
    }

    override suspend fun getProductByBarcode(barcode: String): ProductEntity? = withContext(Dispatchers.IO) {
        productDao.getProductByBarcode(barcode)
    }

    override fun searchProducts(query: String): Flow<List<ProductEntity>> = productDao.searchProducts(query)

    override suspend fun searchProductsList(query: String): List<ProductEntity> = withContext(Dispatchers.IO) {
        productDao.searchProductsList(query)
    }

    override fun getLowStockProducts(): Flow<List<ProductEntity>> = productDao.getLowStockProductsFlow()

    override fun getExpiringProducts(thresholdTimestamp: Long): Flow<List<ProductEntity>> =
        productDao.getExpiringProductsFlow(thresholdTimestamp)

    override fun getTotalValuation(): Flow<Double?> = productDao.getTotalStockValuationFlow()

    override fun getProductCount(): Flow<Int> = productDao.getTotalProductCountFlow()

    override suspend fun insertOrUpdateProduct(product: ProductEntity, aliases: List<String>): Long =
        withContext(Dispatchers.IO) {
            val productId = productDao.insertProduct(product)
            if (aliases.isNotEmpty()) {
                val aliasEntities = aliases.map {
                    ProductAliasEntity(productId = productId, alias = it.trim())
                }
                productDao.insertAliases(aliasEntities)
            }
            productId
        }

    override suspend fun adjustStock(
        productId: Long,
        quantityChange: Double,
        reason: String,
        notes: String?
    ) = withContext(Dispatchers.IO) {
        val current = productDao.getProductById(productId) ?: return@withContext
        val beforeStock = current.currentStock
        val afterStock = beforeStock + quantityChange

        productDao.adjustProductStock(productId, quantityChange)
        productDao.insertStockAdjustment(
            StockAdjustmentEntity(
                productId = productId,
                adjustedQuantity = quantityChange,
                reason = reason,
                notes = notes
            )
        )
        productDao.insertInventoryTransaction(
            InventoryTransactionEntity(
                productId = productId,
                transactionType = "ADJUSTMENT",
                quantity = quantityChange,
                stockBefore = beforeStock,
                stockAfter = afterStock,
                referenceType = "STOCK_ADJUSTMENT",
                notes = "Reason: $reason. $notes"
            )
        )
    }

    override suspend fun deleteProduct(id: Long) = withContext(Dispatchers.IO) {
        productDao.softDeleteProduct(id)
    }

    override suspend fun importProductsFromCsv(csvContent: String): Result<Int> = withContext(Dispatchers.IO) {
        try {
            val lines = csvContent.lines().filter { it.isNotBlank() }
            if (lines.isEmpty()) return@withContext Result.failure(IllegalArgumentException("CSV is empty"))

            var importedCount = 0
            // Header: name,barcode,sku,category,brand,unit,purchasePrice,sellingPrice,mrp,gstRate,openingStock,minimumStock
            for ((index, line) in lines.withIndex()) {
                if (index == 0 && line.lowercase().contains("name")) continue // Skip header

                val parts = line.split(",").map { it.trim() }
                if (parts.isNotEmpty() && parts[0].isNotBlank()) {
                    val name = parts[0]
                    val barcode = parts.getOrNull(1)?.takeIf { it.isNotBlank() }
                    val sku = parts.getOrNull(2)?.takeIf { it.isNotBlank() }
                    val unit = parts.getOrNull(5)?.takeIf { it.isNotBlank() } ?: "pcs"
                    val purchasePrice = parts.getOrNull(6)?.toDoubleOrNull() ?: 0.0
                    val sellingPrice = parts.getOrNull(7)?.toDoubleOrNull() ?: purchasePrice
                    val mrp = parts.getOrNull(8)?.toDoubleOrNull() ?: sellingPrice
                    val gstRate = parts.getOrNull(9)?.toDoubleOrNull() ?: 0.0
                    val openingStock = parts.getOrNull(10)?.toDoubleOrNull() ?: 0.0
                    val minimumStock = parts.getOrNull(11)?.toDoubleOrNull() ?: 5.0

                    productDao.insertProduct(
                        ProductEntity(
                            name = name,
                            barcode = barcode,
                            sku = sku,
                            unit = unit,
                            purchasePrice = purchasePrice,
                            sellingPrice = sellingPrice,
                            mrp = mrp,
                            gstRate = gstRate,
                            openingStock = openingStock,
                            currentStock = openingStock,
                            minimumStock = minimumStock
                        )
                    )
                    importedCount++
                }
            }
            Result.success(importedCount)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
