package com.vyaparai.app.data.repositories

import androidx.room.withTransaction
import com.vyaparai.app.core.database.AppDatabase
import com.vyaparai.app.core.database.daos.InvoiceWithItems
import com.vyaparai.app.core.database.daos.TopSellingProductSummary
import com.vyaparai.app.core.database.entities.InventoryTransactionEntity
import com.vyaparai.app.core.database.entities.InvoiceSettingsEntity
import com.vyaparai.app.core.database.entities.SalesReturnEntity
import com.vyaparai.app.core.database.entities.SalesReturnItemEntity
import com.vyaparai.app.core.utils.DateUtils
import com.vyaparai.app.domain.repositories.InvoiceRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

class InvoiceRepositoryImpl(
    private val database: AppDatabase
) : InvoiceRepository {

    private val invoiceDao = database.invoiceDao()
    private val settingsDao = database.settingsBusinessDao()
    private val productDao = database.productDao()

    override fun getAllInvoices(): Flow<List<InvoiceWithItems>> = invoiceDao.getAllInvoicesWithItemsFlow()

    override suspend fun getInvoiceById(id: Long): InvoiceWithItems? = withContext(Dispatchers.IO) {
        invoiceDao.getInvoiceWithItemsById(id)
    }

    override suspend fun getInvoiceByNumber(number: String): InvoiceWithItems? = withContext(Dispatchers.IO) {
        invoiceDao.getInvoiceByNumber(number)
    }

    override fun getTodaySalesSum(): Flow<Double?> {
        val startOfDay = DateUtils.getStartOfDay()
        val endOfDay = DateUtils.getEndOfDay()
        return invoiceDao.getSalesSumBetweenDatesFlow(startOfDay, endOfDay)
    }

    override fun getTodayProfitSum(): Flow<Double?> {
        val startOfDay = DateUtils.getStartOfDay()
        val endOfDay = DateUtils.getEndOfDay()
        return invoiceDao.getProfitSumBetweenDatesFlow(startOfDay, endOfDay)
    }

    override fun getSalesSumBetween(start: Long, end: Long): Flow<Double?> =
        invoiceDao.getSalesSumBetweenDatesFlow(start, end)

    override fun getProfitSumBetween(start: Long, end: Long): Flow<Double?> =
        invoiceDao.getProfitSumBetweenDatesFlow(start, end)

    override fun getTopProducts(limit: Int): Flow<List<TopSellingProductSummary>> =
        invoiceDao.getTopSellingProductsFlow(limit)

    override suspend fun generateNextInvoiceNumber(): String = withContext(Dispatchers.IO) {
        val settings = settingsDao.getInvoiceSettings() ?: InvoiceSettingsEntity()
        "%s%06d".format(settings.prefix, settings.nextInvoiceNumber)
    }

    override suspend fun recordSalesReturn(
        salesReturn: SalesReturnEntity,
        items: List<SalesReturnItemEntity>
    ) = withContext(Dispatchers.IO) {
        database.withTransaction {
            val returnId = invoiceDao.insertSalesReturn(salesReturn)
            val mappedItems = items.map { it.copy(salesReturnId = returnId) }
            invoiceDao.insertSalesReturnItems(mappedItems)

            // Restock returned items
            for (item in mappedItems) {
                if (item.restockInventory) {
                    val currentProduct = productDao.getProductById(item.productId)
                    val before = currentProduct?.currentStock ?: 0.0
                    val after = before + item.quantity

                    productDao.adjustProductStock(item.productId, item.quantity)
                    productDao.insertInventoryTransaction(
                        InventoryTransactionEntity(
                            productId = item.productId,
                            transactionType = "SALE_RETURN",
                            quantity = item.quantity,
                            stockBefore = before,
                            stockAfter = after,
                            referenceType = "SALES_RETURN",
                            referenceId = returnId,
                            notes = "Customer Return for Invoice #${salesReturn.invoiceId}"
                        )
                    )
                }
            }
        }
    }
}
