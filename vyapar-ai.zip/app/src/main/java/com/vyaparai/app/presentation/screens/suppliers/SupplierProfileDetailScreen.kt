package com.vyaparai.app.presentation.screens.suppliers

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.vyaparai.app.VyaparAiApplication
import com.vyaparai.app.core.database.entities.SupplierEntity
import com.vyaparai.app.core.theme.VyaparGreenPrimary
import com.vyaparai.app.core.utils.CurrencyFormatter
import com.vyaparai.app.core.utils.DateUtils
import com.vyaparai.app.presentation.common.VyaparTopBar

@Composable
fun SupplierProfileDetailScreen(
    supplierId: Long,
    onBackClick: () -> Unit
) {
    val context = LocalContext.current
    val app = context.applicationContext as VyaparAiApplication

    var supplier by remember { mutableStateOf<SupplierEntity?>(null) }
    val transactions by app.container.supplierPurchaseRepository.getAllPurchases().collectAsState(initial = emptyList())

    LaunchedEffect(supplierId) {
        supplier = app.container.supplierPurchaseRepository.getSupplierById(supplierId)
    }

    val supplierPurchases = transactions.filter { it.purchase.supplierId == supplierId }

    Scaffold(
        topBar = {
            VyaparTopBar(
                title = supplier?.name ?: "Supplier Profile",
                subtitle = supplier?.companyName ?: "Supplier Details",
                showBackButton = true,
                onBackClick = onBackClick
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
        ) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(text = "OUTSTANDING PAYABLE", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                    Text(
                        text = CurrencyFormatter.format(supplier?.currentOutstanding ?: 0.0),
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.ExtraBold,
                        color = MaterialTheme.colorScheme.error
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(text = "Phone: ${supplier?.mobile ?: "None"} | GSTIN: ${supplier?.gstin ?: "N/A"}", style = MaterialTheme.typography.bodySmall)
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(text = "Purchase Invoices (${supplierPurchases.size})", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(8.dp))

            if (supplierPurchases.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("No purchases recorded from this supplier.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(supplierPurchases) { pWithItems ->
                        val p = pWithItems.purchase
                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .padding(14.dp)
                                    .fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text(text = "Invoice #${p.invoiceNumber ?: p.purchaseNumber}", fontWeight = FontWeight.Bold)
                                    Text(
                                        text = "${DateUtils.formatDate(p.createdAt)} | ${pWithItems.items.size} items",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    Text(
                                        text = CurrencyFormatter.format(p.grandTotal),
                                        fontWeight = FontWeight.ExtraBold,
                                        color = VyaparGreenPrimary
                                    )
                                    Text(text = "Paid: ${CurrencyFormatter.format(p.amountPaid)}", style = MaterialTheme.typography.bodySmall)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
