package com.vyaparai.app.presentation.screens.settings

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.vyaparai.app.VyaparAiApplication
import com.vyaparai.app.core.theme.VyaparGreenPrimary
import com.vyaparai.app.presentation.common.VyaparTopBar
import kotlinx.coroutines.launch

data class LanguageItem(
    val code: String,
    val name: String,
    val nativeName: String
)

@Composable
fun LanguageSettingsScreen(
    onBackClick: () -> Unit
) {
    val context = LocalContext.current
    val app = context.applicationContext as VyaparAiApplication
    val scope = rememberCoroutineScope()

    val languages = listOf(
        LanguageItem("EN", "English", "English (India)"),
        LanguageItem("HI", "Hindi", "हिन्दी"),
        LanguageItem("MR", "Marathi", "मराठी"),
        LanguageItem("GU", "Gujarati", "ગુજરાતી (Coming soon)"),
        LanguageItem("TA", "Tamil", "தமிழ் (Coming soon)"),
        LanguageItem("TE", "Telugu", "తెలుగు (Coming soon)"),
        LanguageItem("KN", "Kannada", "ಕನ್ನಡ (Coming soon)"),
        LanguageItem("BN", "Bengali", "বাংলা (Coming soon)")
    )

    var currentLang by remember { mutableStateOf("EN") }

    LaunchedEffect(Unit) {
        val settings = app.container.database.settingsBusinessDao().getAppSettings()
        currentLang = settings?.language ?: "EN"
    }

    Scaffold(
        topBar = {
            VyaparTopBar(
                title = "Language Settings",
                subtitle = "App & Voice Recognition Language",
                showBackButton = true,
                onBackClick = onBackClick
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
        ) {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(languages) { lang ->
                    val isSelected = lang.code == currentLang
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                if (lang.code in listOf("EN", "HI", "MR")) {
                                    currentLang = lang.code
                                    scope.launch {
                                        val existing = app.container.database.settingsBusinessDao().getAppSettings()
                                        if (existing != null) {
                                            app.container.settingsRepository.saveAppSettings(existing.copy(language = lang.code))
                                        }
                                    }
                                }
                            },
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (isSelected) VyaparGreenPrimary.copy(alpha = 0.12f) else MaterialTheme.colorScheme.surface
                        ),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .padding(16.dp)
                                .fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(text = lang.nativeName, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                                Text(text = lang.name, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            if (isSelected) {
                                Icon(Icons.Default.Check, contentDescription = "Selected", tint = VyaparGreenPrimary)
                            }
                        }
                    }
                }
            }
        }
    }
}
