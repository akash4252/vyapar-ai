package com.vyaparai.app.presentation.screens.purchases

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vyaparai.app.VyaparAiApplication
import com.vyaparai.app.core.database.entities.ProductEntity
import com.vyaparai.app.core.database.entities.PurchaseEntity
import com.vyaparai.app.core.database.entities.PurchaseItemEntity
import com.vyaparai.app.core.database.entities.SupplierEntity
import com.vyaparai.app.core.ocr.ExtractedInvoiceItem
import com.vyaparai.app.core.ocr.ExtractedSupplierInvoice
import com.vyaparai.app.core.ocr.SupplierInvoiceParser
import com.vyaparai.app.core.theme.VyaparGreenPrimary
import com.vyaparai.app.core.theme.VyaparSecondaryAmber
import com.vyaparai.app.core.utils.CurrencyFormatter
import com.vyaparai.app.presentation.common.VyaparPrimaryButton
import com.vyaparai.app.presentation.common.VyaparTopBar
import kotlinx.coroutines.launch

@Composable
fun AiBillScannerScreen(
    onSuccess: () -> Unit,
    onBackClick: () -> Unit
) {
    val context = LocalContext.current
    val app = context.applicationContext as VyaparAiApplication
    val scope = rememberCoroutineScope()

    var isScanning by remember { mutableStateOf(false) }
    var extractedInvoice by remember { mutableStateOf<ExtractedSupplierInvoice?>(null) }
    var rawOcrText by remember { mutableStateOf("") }

    fun processSampleOcr() {
        isScanning = true
        // Simulated ML Kit Text Recognition output from camera photo
        val sampleInvoiceText = """
            ABC Distributors Pvt Ltd
            Invoice No: INV-2026-9812
            Date: 27/08/2026
            
            Maggi 2-Minute Noodles 70g  20 pcs @ 8.00 = 160.00
            Madhur Pure Sugar 1kg       10 kg  @ 38.00 = 380.00
            Amul Taaza Milk 500ml       15 pkt @ 25.00 = 375.00
            
            Grand Total: ₹915.00
        """.trimIndent()

        rawOcrText = sampleInvoiceText
        val parsed = SupplierInvoiceParser.parseOcrText(sampleInvoiceText)
        extractedInvoice = parsed
        isScanning = false
    }

    Scaffold(
        topBar = {
            VyaparTopBar(
                title = "AI Bill Scanner",
                subtitle = "Scan Paper Supplier Invoice",
                showBackButton = true,
                onBackClick = onBackClick
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            if (extractedInvoice == null) {
                // Camera Viewfinder Box
                Column(
                    modifier = Modifier.weight(1f).fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Box(
                        modifier = Modifier
                            .size(280.dp, 360.dp)
                            .border(2.dp, VyaparGreenPrimary, RoundedCornerShape(16.dp))
                            .background(Color.Black.copy(alpha = 0.05f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                imageVector = Icons.Default.DocumentScanner,
                                contentDescription = null,
                                tint = VyaparGreenPrimary,
                                modifier = Modifier.size(54.dp)
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = "Point camera at supplier invoice",
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "Auto-extracts items, price & quantity",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                VyaparPrimaryButton(
                    text = "CAPTURE & EXTRACT INVOICE",
                    onClick = { processSampleOcr() },
                    icon = Icons.Default.CameraAlt
                )
            } else {
                // OCR Extracted Editable Preview
                Column(modifier = Modifier.weight(1f)) {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text(
                                text = "Supplier: ${extractedInvoice!!.supplierName ?: "Unknown Supplier"}",
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.titleMedium
                            )
                            Text(
                                text = "Invoice No: ${extractedInvoice!!.invoiceNumber ?: "Auto"} | Date: ${extractedInvoice!!.invoiceDate ?: "Today"}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "Extracted Items (${extractedInvoice!!.items.size})",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Review extracted stock before confirming. Never automatically applied.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    LazyColumn(
                        modifier = Modifier.fillMaxWidth().weight(1f),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(extractedInvoice!!.items) { item ->
                            Card(
                                shape = RoundedCornerShape(10.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp).fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(text = item.productName, fontWeight = FontWeight.Bold)
                                        Text(
                                            text = "Qty: ${item.quantity.toInt()} ${item.unit} @ ₹${item.purchasePrice}",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    Text(
                                        text = CurrencyFormatter.format(item.quantity * item.purchasePrice),
                                        fontWeight = FontWeight.Bold,
                                        color = VyaparGreenPrimary
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedButton(
                        onClick = { extractedInvoice = null },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.weight(1f).height(50.dp)
                    ) {
                        Text("Retake Photo")
                    }

                    Button(
                        onClick = {
                            scope.launch {
                                val invoice = extractedInvoice!!
                                val suppliers = app.container.supplierPurchaseRepository.getAllSuppliers()
                                val defaultSupplierId = 1L // fallback supplier
                                val total = invoice.items.sumOf { it.quantity * it.purchasePrice }

                                val purchase = PurchaseEntity(
                                    purchaseNumber = "AI-PO-${System.currentTimeMillis() % 100000}",
                                    supplierId = defaultSupplierId,
                                    supplierName = invoice.supplierName ?: "AI Scanned Supplier",
                                    invoiceNumber = invoice.invoiceNumber,
                                    subtotal = total,
                                    grandTotal = total,
                                    amountPaid = total
                                )

                                val pItems = invoice.items.map { item ->
                                    val match = app.container.productRepository.searchProductsList(item.productName)
                                    val prodId = match.firstOrNull()?.id ?: app.container.productRepository.insertOrUpdateProduct(
                                        ProductEntity(
                                            name = item.productName,
                                            purchasePrice = item.purchasePrice,
                                            sellingPrice = item.purchasePrice * 1.25,
                                            unit = item.unit,
                                            currentStock = 0.0
                                        )
                                    )

                                    PurchaseItemEntity(
                                        purchaseId = 0,
                                        productId = prodId,
                                        productName = item.productName,
                                        quantity = item.quantity,
                                        unit = item.unit,
                                        purchasePrice = item.purchasePrice,
                                        totalAmount = item.quantity * item.purchasePrice
                                    )
                                }

                                app.container.supplierPurchaseRepository.createPurchase(purchase, pItems)
                                onSuccess()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = VyaparGreenPrimary),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.weight(1f).height(50.dp)
                    ) {
                        Text("CONFIRM STOCK IN", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
