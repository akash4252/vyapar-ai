package com.vyaparai.app.presentation.screens.products

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.vyaparai.app.VyaparAiApplication
import com.vyaparai.app.core.theme.VyaparGreenPrimary
import com.vyaparai.app.presentation.common.ProductItemRow
import com.vyaparai.app.presentation.common.VyaparTopBar
import kotlinx.coroutines.launch

@Composable
fun ProductListScreen(
    onAddProductClick: () -> Unit,
    onProductClick: (Long) -> Unit,
    onBackClick: () -> Unit
) {
    val context = LocalContext.current
    val app = context.applicationContext as VyaparAiApplication
    val scope = rememberCoroutineScope()

    var searchQuery by remember { mutableStateOf("") }
    val products by app.container.productRepository.searchProducts(searchQuery).collectAsState(initial = emptyList())
    val totalCount by app.container.productRepository.getProductCount().collectAsState(initial = 0)

    var showCsvImportDialog by remember { mutableStateOf(false) }
    var csvInputText by remember { mutableStateOf("") }
    var importStatusMessage by remember { mutableStateOf<String?>(null) }

    Scaffold(
        topBar = {
            VyaparTopBar(
                title = "Products & Inventory",
                subtitle = "$totalCount items in catalog",
                showBackButton = true,
                onBackClick = onBackClick,
                actions = {
                    IconButton(onClick = { showCsvImportDialog = true }) {
                        Icon(Icons.Default.FileUpload, contentDescription = "Import CSV")
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = onAddProductClick,
                containerColor = VyaparGreenPrimary,
                shape = RoundedCornerShape(16.dp)
            ) {
                Icon(Icons.Default.Add, contentDescription = "Add Product", tint = MaterialTheme.colorScheme.onPrimary)
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
        ) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Search by name, barcode, SKU...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                singleLine = true
            )

            Spacer(modifier = Modifier.height(16.dp))

            if (products.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.Inventory2, contentDescription = null, tint = MaterialTheme.colorScheme.outline, modifier = Modifier.size(64.dp))
                        Spacer(modifier = Modifier.height(12.dp))
                        Text("No products found", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text("Tap '+' button to add your first product", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(products) { product ->
                        ProductItemRow(
                            product = product,
                            onProductClick = { onProductClick(product.id) }
                        )
                    }
                }
            }
        }

        // CSV Import Dialog
        if (showCsvImportDialog) {
            AlertDialog(
                onDismissRequest = { showCsvImportDialog = false },
                title = { Text("Import Products via CSV", fontWeight = FontWeight.Bold) },
                text = {
                    Column {
                        Text(
                            text = "Format: name,barcode,sku,category,brand,unit,purchasePrice,sellingPrice,mrp,gstRate,openingStock,minimumStock",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = csvInputText,
                            onValueChange = { csvInputText = it },
                            placeholder = { Text("Paste CSV data here...") },
                            modifier = Modifier.fillMaxWidth().height(150.dp),
                            shape = RoundedCornerShape(8.dp)
                        )
                        if (importStatusMessage != null) {
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(importStatusMessage!!, color = VyaparGreenPrimary, fontWeight = FontWeight.Bold)
                        }
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            scope.launch {
                                val res = app.container.productRepository.importProductsFromCsv(csvInputText)
                                res.onSuccess { count ->
                                    importStatusMessage = "Successfully imported $count products!"
                                    csvInputText = ""
                                }.onFailure { err ->
                                    importStatusMessage = "Error: ${err.message}"
                                }
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = VyaparGreenPrimary)
                    ) {
                        Text("Import")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showCsvImportDialog = false }) {
                        Text("Close")
                    }
                }
            )
        }
    }
}
