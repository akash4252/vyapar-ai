package com.vyaparai.app.data.repositories

import androidx.room.withTransaction
import com.vyaparai.app.core.database.AppDatabase
import com.vyaparai.app.core.database.daos.PurchaseOrderWithItems
import com.vyaparai.app.core.database.daos.PurchaseWithItems
import com.vyaparai.app.core.database.entities.*
import com.vyaparai.app.core.utils.DateUtils
import com.vyaparai.app.domain.repositories.SupplierPurchaseRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

class SupplierPurchaseRepositoryImpl(
    private val database: AppDatabase
) : SupplierPurchaseRepository {

    private val supplierDao = database.supplierPurchaseDao()
    private val productDao = database.productDao()

    override fun getAllSuppliers(): Flow<List<SupplierEntity>> = supplierDao.getAllSuppliersFlow()

    override suspend fun getSupplierById(id: Long): SupplierEntity? = withContext(Dispatchers.IO) {
        supplierDao.getSupplierById(id)
    }

    override suspend fun insertOrUpdateSupplier(supplier: SupplierEntity): Long = withContext(Dispatchers.IO) {
        supplierDao.insertSupplier(supplier)
    }

    override fun getAllPurchases(): Flow<List<PurchaseWithItems>> = supplierDao.getAllPurchasesWithItemsFlow()

    override suspend fun getPurchaseById(id: Long): PurchaseWithItems? = withContext(Dispatchers.IO) {
        supplierDao.getPurchaseWithItemsById(id)
    }

    override suspend fun createPurchase(
        purchase: PurchaseEntity,
        items: List<PurchaseItemEntity>
    ): Long = withContext(Dispatchers.IO) {
        database.withTransaction {
            val purchaseId = supplierDao.insertPurchase(purchase)
            val mappedItems = items.map { it.copy(purchaseId = purchaseId) }
            supplierDao.insertPurchaseItems(mappedItems)

            // Increment Stock for each purchase item
            for (item in mappedItems) {
                val currentProduct = productDao.getProductById(item.productId)
                val before = currentProduct?.currentStock ?: 0.0
                val after = before + item.quantity

                productDao.adjustProductStock(item.productId, item.quantity)
                productDao.insertInventoryTransaction(
                    InventoryTransactionEntity(
                        productId = item.productId,
                        transactionType = "PURCHASE",
                        quantity = item.quantity,
                        stockBefore = before,
                        stockAfter = after,
                        referenceType = "PURCHASE",
                        referenceId = purchaseId,
                        notes = "Stock in from ${purchase.supplierName}"
                    )
                )
            }

            // Record Outstanding if credit purchase
            val creditAmount = purchase.grandTotal - purchase.amountPaid
            if (creditAmount > 0) {
                val supplier = supplierDao.getSupplierById(purchase.supplierId)
                val newOutstanding = (supplier?.currentOutstanding ?: 0.0) + creditAmount
                supplierDao.updateSupplierOutstanding(purchase.supplierId, creditAmount)
                supplierDao.insertSupplierTransaction(
                    SupplierTransactionEntity(
                        supplierId = purchase.supplierId,
                        purchaseId = purchaseId,
                        transactionType = "PURCHASE_CREDIT",
                        amount = creditAmount,
                        balanceAfter = newOutstanding,
                        notes = "Purchase #${purchase.purchaseNumber}"
                    )
                )
            }

            purchaseId
        }
    }

    override fun getAllPurchaseOrders(): Flow<List<PurchaseOrderWithItems>> =
        supplierDao.getAllPurchaseOrdersWithItemsFlow()

    override suspend fun createPurchaseOrder(
        po: PurchaseOrderEntity,
        items: List<PurchaseOrderItemEntity>
    ): Long = withContext(Dispatchers.IO) {
        database.withTransaction {
            val poId = supplierDao.insertPurchaseOrder(po)
            val mapped = items.map { it.copy(purchaseOrderId = poId) }
            supplierDao.insertPurchaseOrderItems(mapped)
            poId
        }
    }

    override suspend fun updatePurchaseOrderStatus(poId: Long, newStatus: String) = withContext(Dispatchers.IO) {
        val po = supplierDao.getPurchaseOrderWithItemsById(poId) ?: return@withContext
        supplierDao.updatePurchaseOrder(po.order.copy(status = newStatus))
    }

    override fun getAllExpenses(): Flow<List<ExpenseEntity>> = supplierDao.getAllExpensesFlow()

    override fun getTodayExpensesSum(): Flow<Double?> {
        val start = DateUtils.getStartOfDay()
        val end = DateUtils.getEndOfDay()
        return supplierDao.getExpensesSumBetweenDatesFlow(start, end)
    }

    override suspend fun addExpense(expense: ExpenseEntity): Long = withContext(Dispatchers.IO) {
        supplierDao.insertExpense(expense)
    }
}
