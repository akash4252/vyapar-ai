package com.vyaparai.app.domain.usecases

import com.vyaparai.app.core.database.entities.ProductEntity

data class SmartPurchaseSuggestion(
    val product: ProductEntity,
    val currentStock: Double,
    val suggestedQuantity: Double,
    val reason: String,
    val estimatedCost: Double
)

object SmartPoUseCase {

    fun generateSuggestions(
        lowStockProducts: List<ProductEntity>
    ): List<SmartPurchaseSuggestion> {
        return lowStockProducts.map { product ->
            val deficit = (product.maximumStock - product.currentStock).coerceAtLeast(1.0)
            val suggestedQty = kotlin.math.ceil(deficit)
            val reason = when {
                product.currentStock <= 0 -> "Out of stock! Urgent reorder needed."
                product.currentStock <= product.minimumStock / 2 -> "Critically low stock."
                else -> "Stock below minimum threshold (${product.minimumStock} ${product.unit})."
            }

            SmartPurchaseSuggestion(
                product = product,
                currentStock = product.currentStock,
                suggestedQuantity = suggestedQty,
                reason = reason,
                estimatedCost = suggestedQty * product.purchasePrice
            )
        }
    }
}
