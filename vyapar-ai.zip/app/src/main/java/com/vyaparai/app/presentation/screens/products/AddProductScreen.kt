package com.vyaparai.app.presentation.screens.products

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.vyaparai.app.VyaparAiApplication
import com.vyaparai.app.core.database.entities.ProductEntity
import com.vyaparai.app.presentation.common.VyaparPrimaryButton
import com.vyaparai.app.presentation.common.VyaparTopBar
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddProductScreen(
    initialBarcode: String? = null,
    onSuccess: () -> Unit,
    onBackClick: () -> Unit
) {
    val context = LocalContext.current
    val app = context.applicationContext as VyaparAiApplication
    val scope = rememberCoroutineScope()

    var name by remember { mutableStateOf("") }
    var aliasesText by remember { mutableStateOf("") }
    var barcode by remember { mutableStateOf(initialBarcode ?: "") }
    var sku by remember { mutableStateOf("") }
    var unit by remember { mutableStateOf("pcs") }
    var purchasePrice by remember { mutableStateOf("") }
    var sellingPrice by remember { mutableStateOf("") }
    var mrp by remember { mutableStateOf("") }
    var gstRate by remember { mutableStateOf("0") }
    var isTaxInclusive by remember { mutableStateOf(true) }
    var openingStock by remember { mutableStateOf("10") }
    var minimumStock by remember { mutableStateOf("5") }

    val units = listOf("pcs", "kg", "g", "litre", "ml", "box", "packet", "dozen")
    val gstRates = listOf("0", "5", "12", "18", "28")

    var errorMessage by remember { mutableStateOf<String?>(null) }
    var unitDropdownExpanded by remember { mutableStateOf(false) }
    var gstDropdownExpanded by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            VyaparTopBar(
                title = "Add New Product",
                showBackButton = true,
                onBackClick = onBackClick
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(20.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Product Name *") },
                    leadingIcon = { Icon(Icons.Default.ShoppingBag, contentDescription = null) },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    singleLine = true
                )
                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = aliasesText,
                    onValueChange = { aliasesText = it },
                    label = { Text("Voice Aliases (Comma separated, e.g. Maggi, मॅगी, मैगी)") },
                    leadingIcon = { Icon(Icons.Default.Mic, contentDescription = null) },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    singleLine = true
                )
                Spacer(modifier = Modifier.height(12.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedTextField(
                        value = barcode,
                        onValueChange = { barcode = it },
                        label = { Text("Barcode") },
                        leadingIcon = { Icon(Icons.Default.QrCode, contentDescription = null) },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true
                    )

                    // Unit Dropdown
                    ExposedDropdownMenuBox(
                        expanded = unitDropdownExpanded,
                        onExpandedChange = { unitDropdownExpanded = it },
                        modifier = Modifier.weight(1f)
                    ) {
                        OutlinedTextField(
                            value = unit,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Unit") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = unitDropdownExpanded) },
                            modifier = Modifier.menuAnchor(),
                            shape = RoundedCornerShape(12.dp)
                        )
                        ExposedDropdownMenu(
                            expanded = unitDropdownExpanded,
                            onDismissRequest = { unitDropdownExpanded = false }
                        ) {
                            units.forEach { u ->
                                DropdownMenuItem(
                                    text = { Text(u) },
                                    onClick = {
                                        unit = u
                                        unitDropdownExpanded = false
                                    }
                                )
                            }
                        }
                    }
                }
                Spacer(modifier = Modifier.height(12.dp))

                // Pricing Row
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedTextField(
                        value = sellingPrice,
                        onValueChange = { sellingPrice = it },
                        label = { Text("Selling Price (₹) *") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = purchasePrice,
                        onValueChange = { purchasePrice = it },
                        label = { Text("Purchase Price (₹)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true
                    )
                }
                Spacer(modifier = Modifier.height(12.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedTextField(
                        value = mrp,
                        onValueChange = { mrp = it },
                        label = { Text("MRP (₹)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true
                    )

                    // GST Dropdown
                    ExposedDropdownMenuBox(
                        expanded = gstDropdownExpanded,
                        onExpandedChange = { gstDropdownExpanded = it },
                        modifier = Modifier.weight(1f)
                    ) {
                        OutlinedTextField(
                            value = "$gstRate%",
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("GST Rate") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = gstDropdownExpanded) },
                            modifier = Modifier.menuAnchor(),
                            shape = RoundedCornerShape(12.dp)
                        )
                        ExposedDropdownMenu(
                            expanded = gstDropdownExpanded,
                            onDismissRequest = { gstDropdownExpanded = false }
                        ) {
                            gstRates.forEach { rate ->
                                DropdownMenuItem(
                                    text = { Text("$rate%") },
                                    onClick = {
                                        gstRate = rate
                                        gstDropdownExpanded = false
                                    }
                                )
                            }
                        }
                    }
                }
                Spacer(modifier = Modifier.height(12.dp))

                // Stock Row
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedTextField(
                        value = openingStock,
                        onValueChange = { openingStock = it },
                        label = { Text("Opening Stock") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = minimumStock,
                        onValueChange = { minimumStock = it },
                        label = { Text("Minimum Stock") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true
                    )
                }

                if (errorMessage != null) {
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = errorMessage!!,
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            VyaparPrimaryButton(
                text = "SAVE PRODUCT",
                onClick = {
                    val sPrice = sellingPrice.toDoubleOrNull()
                    if (name.isBlank() || sPrice == null) {
                        errorMessage = "Please enter Product Name and valid Selling Price"
                    } else {
                        scope.launch {
                            val pPrice = purchasePrice.toDoubleOrNull() ?: (sPrice * 0.8)
                            val mrpVal = mrp.toDoubleOrNull() ?: sPrice
                            val oStock = openingStock.toDoubleOrNull() ?: 0.0
                            val minStock = minimumStock.toDoubleOrNull() ?: 5.0
                            val gRate = gstRate.toDoubleOrNull() ?: 0.0

                            val parsedAliases = aliasesText.split(",").map { it.trim() }.filter { it.isNotBlank() }

                            app.container.productRepository.insertOrUpdateProduct(
                                product = ProductEntity(
                                    name = name.trim(),
                                    barcode = barcode.trim().takeIf { it.isNotBlank() },
                                    sku = sku.trim().takeIf { it.isNotBlank() },
                                    unit = unit,
                                    purchasePrice = pPrice,
                                    sellingPrice = sPrice,
                                    mrp = mrpVal,
                                    gstRate = gRate,
                                    isTaxInclusive = isTaxInclusive,
                                    openingStock = oStock,
                                    currentStock = oStock,
                                    minimumStock = minStock
                                ),
                                aliases = parsedAliases
                            )
                            onSuccess()
                        }
                    }
                },
                icon = Icons.Default.Save
            )
        }
    }
}
