package com.vyaparai.app.data.repositories

import androidx.room.withTransaction
import com.vyaparai.app.core.database.AppDatabase
import com.vyaparai.app.core.database.entities.CustomerEntity
import com.vyaparai.app.core.database.entities.CustomerTransactionEntity
import com.vyaparai.app.core.utils.CurrencyFormatter
import com.vyaparai.app.domain.repositories.CustomerKhataRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

class CustomerKhataRepositoryImpl(
    private val database: AppDatabase
) : CustomerKhataRepository {

    private val customerDao = database.customerKhataDao()

    override fun getAllCustomers(): Flow<List<CustomerEntity>> = customerDao.getAllCustomersFlow()

    override suspend fun getCustomerById(id: Long): CustomerEntity? = withContext(Dispatchers.IO) {
        customerDao.getCustomerById(id)
    }

    override fun searchCustomers(query: String): Flow<List<CustomerEntity>> = customerDao.searchCustomers(query)

    override suspend fun findCustomerByName(name: String): CustomerEntity? = withContext(Dispatchers.IO) {
        customerDao.findCustomerByName(name)
    }

    override fun getKhataDebtors(): Flow<List<CustomerEntity>> = customerDao.getKhataDebtorsFlow()

    override fun getTotalPendingKhata(): Flow<Double?> = customerDao.getTotalPendingKhataFlow()

    override suspend fun insertOrUpdateCustomer(customer: CustomerEntity): Long = withContext(Dispatchers.IO) {
        customerDao.insertCustomer(customer)
    }

    override suspend fun recordKhataTransaction(
        customerId: Long,
        amount: Double,
        type: String,
        paymentMethod: String?,
        invoiceId: Long?,
        notes: String?
    ) = withContext(Dispatchers.IO) {
        database.withTransaction {
            val customer = customerDao.getCustomerById(customerId) ?: return@withTransaction
            val balanceDelta = if (type == "PAYMENT_RECEIVED" || type == "REFUND") -amount else amount
            val newBalance = customer.currentCreditBalance + balanceDelta

            customerDao.updateCustomerBalance(customerId, balanceDelta)
            customerDao.insertCustomerTransaction(
                CustomerTransactionEntity(
                    customerId = customerId,
                    invoiceId = invoiceId,
                    transactionType = type,
                    amount = amount,
                    balanceAfter = newBalance,
                    paymentMethod = paymentMethod ?: "CASH",
                    notes = notes
                )
            )
        }
    }

    override fun getCustomerTransactions(customerId: Long): Flow<List<CustomerTransactionEntity>> =
        customerDao.getCustomerTransactionsFlow(customerId)

    override fun generateWhatsAppReminderMessage(
        customerName: String,
        businessName: String,
        balance: Double
    ): String {
        val formattedAmount = CurrencyFormatter.format(balance)
        return """
            Hello $customerName,

            Your pending balance at $businessName is $formattedAmount.

            Please make the payment at your earliest convenience.

            Thank you for your valued support!
        """.trimIndent()
    }
}
