package com.vyaparai.app.presentation.screens.billing

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.vyaparai.app.VyaparAiApplication
import com.vyaparai.app.core.database.daos.InvoiceWithItems
import com.vyaparai.app.core.printer.InvoicePdfGenerator
import com.vyaparai.app.core.printer.PdfInvoiceData
import com.vyaparai.app.core.printer.PdfInvoiceItem
import com.vyaparai.app.core.theme.VyaparGreenPrimary
import com.vyaparai.app.core.theme.VyaparSuccess
import com.vyaparai.app.core.utils.CurrencyFormatter
import com.vyaparai.app.core.utils.DateUtils
import com.vyaparai.app.presentation.common.VyaparPrimaryButton
import com.vyaparai.app.presentation.common.VyaparSecondaryButton
import com.vyaparai.app.presentation.common.VyaparTopBar
import kotlinx.coroutines.launch

@Composable
fun InvoiceSuccessPreviewScreen(
    invoiceNumber: String,
    onNewBillClick: () -> Unit,
    onHomeClick: () -> Unit
) {
    val context = LocalContext.current
    val app = context.applicationContext as VyaparAiApplication
    val scope = rememberCoroutineScope()

    var invoiceDetails by remember { mutableStateOf<InvoiceWithItems?>(null) }
    val business by app.container.settingsRepository.getBusiness().collectAsState(initial = null)

    LaunchedEffect(invoiceNumber) {
        invoiceDetails = app.container.invoiceRepository.getInvoiceByNumber(invoiceNumber)
    }

    fun shareInvoicePdf() {
        val inv = invoiceDetails ?: return
        val biz = business ?: return

        scope.launch {
            val pdfData = PdfInvoiceData(
                businessName = biz.name,
                businessAddress = biz.address,
                businessMobile = biz.mobile,
                businessGstin = biz.gstin,
                businessUpiId = biz.upiId,
                invoiceNumber = inv.invoice.invoiceNumber,
                invoiceDate = inv.invoice.createdAt,
                customerName = inv.invoice.customerName,
                customerMobile = inv.invoice.customerMobile,
                customerGstin = null,
                items = inv.items.map {
                    PdfInvoiceItem(
                        name = it.productName,
                        hsn = it.hsnCode,
                        quantity = it.quantity,
                        unit = it.unit,
                        rate = it.unitPrice,
                        discount = it.discountAmount,
                        gstRate = it.gstRate,
                        total = it.totalAmount
                    )
                },
                subtotal = inv.invoice.subtotal,
                discount = inv.invoice.totalDiscount,
                cgst = inv.invoice.cgst,
                sgst = inv.invoice.sgst,
                igst = inv.invoice.igst,
                grandTotal = inv.invoice.grandTotal,
                paymentMethod = inv.invoice.paymentMethod
            )

            val file = InvoicePdfGenerator.generateA4Invoice(context, pdfData)
            val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)

            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "application/pdf"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, "Invoice ${inv.invoice.invoiceNumber}")
                putExtra(Intent.EXTRA_TEXT, "Here is your invoice for ${CurrencyFormatter.format(inv.invoice.grandTotal)} from ${biz.name}.")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(intent, "Share Invoice PDF"))
        }
    }

    fun shareWhatsApp() {
        val inv = invoiceDetails ?: return
        val biz = business ?: return

        val text = """
            *${biz.name}*
            Invoice No: ${inv.invoice.invoiceNumber}
            Date: ${DateUtils.formatInvoiceDate(inv.invoice.createdAt)}
            Total Amount: ${CurrencyFormatter.format(inv.invoice.grandTotal)}
            Payment: ${inv.invoice.paymentMethod}
            
            Thank you for shopping with us!
        """.trimIndent()

        val intent = Intent(Intent.ACTION_VIEW).apply {
            data = Uri.parse("https://api.whatsapp.com/send?text=" + Uri.encode(text))
        }
        try {
            context.startActivity(intent)
        } catch (e: Exception) {
            shareInvoicePdf()
        }
    }

    Scaffold(
        topBar = {
            VyaparTopBar(
                title = "Invoice Created",
                showBackButton = true,
                onBackClick = onHomeClick
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(20.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Spacer(modifier = Modifier.height(16.dp))

                Box(
                    modifier = Modifier
                        .size(80.dp)
                        .clip(CircleShape)
                        .background(VyaparSuccess.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = null,
                        tint = VyaparSuccess,
                        modifier = Modifier.size(48.dp)
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = "Bill Generated Successfully!",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )

                Text(
                    text = invoiceNumber,
                    style = MaterialTheme.typography.titleMedium,
                    color = VyaparGreenPrimary,
                    fontWeight = FontWeight.ExtraBold
                )

                if (invoiceDetails != null) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = CurrencyFormatter.format(invoiceDetails!!.invoice.grandTotal),
                        style = MaterialTheme.typography.headlineLarge,
                        fontWeight = FontWeight.ExtraBold
                    )
                }

                Spacer(modifier = Modifier.height(24.dp))

                // Action Buttons Grid
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedButton(
                        onClick = { shareWhatsApp() },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.weight(1f).height(50.dp)
                    ) {
                        Icon(Icons.Default.Share, contentDescription = null, tint = Color(0xFF25D366))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("WhatsApp", fontWeight = FontWeight.Bold)
                    }

                    OutlinedButton(
                        onClick = { shareInvoicePdf() },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.weight(1f).height(50.dp)
                    ) {
                        Icon(Icons.Default.PictureAsPdf, contentDescription = null, tint = Color(0xFFDC2626))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("PDF Invoice", fontWeight = FontWeight.Bold)
                    }
                }
            }

            Column(modifier = Modifier.fillMaxWidth()) {
                VyaparPrimaryButton(
                    text = "NEW BILL (+)",
                    onClick = onNewBillClick,
                    icon = Icons.Default.AddShoppingCart
                )
                Spacer(modifier = Modifier.height(10.dp))
                VyaparSecondaryButton(
                    text = "GO TO DASHBOARD",
                    onClick = onHomeClick,
                    icon = Icons.Default.Home
                )
            }
        }
    }
}
