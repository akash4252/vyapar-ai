package com.vyaparai.app.core.database.daos

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import com.vyaparai.app.core.database.entities.CategoryEntity
import com.vyaparai.app.core.database.entities.InventoryTransactionEntity
import com.vyaparai.app.core.database.entities.ProductAliasEntity
import com.vyaparai.app.core.database.entities.ProductEntity
import com.vyaparai.app.core.database.entities.StockAdjustmentEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ProductDao {
    @Query("SELECT * FROM products WHERE isActive = 1 ORDER BY name ASC")
    fun getAllProductsFlow(): Flow<List<ProductEntity>>

    @Query("SELECT * FROM products WHERE isActive = 1 ORDER BY name ASC")
    suspend fun getAllProducts(): List<ProductEntity>

    @Query("SELECT * FROM products WHERE id = :id")
    suspend fun getProductById(id: Long): ProductEntity?

    @Query("SELECT * FROM products WHERE barcode = :barcode AND isActive = 1 LIMIT 1")
    suspend fun getProductByBarcode(barcode: String): ProductEntity?

    @Query("""
        SELECT p.* FROM products p 
        WHERE p.isActive = 1 AND (
            p.name LIKE '%' || :query || '%' 
            OR p.barcode LIKE '%' || :query || '%' 
            OR p.sku LIKE '%' || :query || '%'
            OR EXISTS (SELECT 1 FROM product_aliases a WHERE a.productId = p.id AND a.alias LIKE '%' || :query || '%')
        )
        ORDER BY p.name ASC
    """)
    fun searchProducts(query: String): Flow<List<ProductEntity>>

    @Query("""
        SELECT p.* FROM products p 
        WHERE p.isActive = 1 AND (
            p.name LIKE '%' || :query || '%' 
            OR p.barcode LIKE '%' || :query || '%' 
            OR p.sku LIKE '%' || :query || '%'
            OR EXISTS (SELECT 1 FROM product_aliases a WHERE a.productId = p.id AND a.alias LIKE '%' || :query || '%')
        )
        ORDER BY p.name ASC
    """)
    suspend fun searchProductsList(query: String): List<ProductEntity>

    @Query("SELECT * FROM products WHERE isActive = 1 AND currentStock <= minimumStock")
    fun getLowStockProductsFlow(): Flow<List<ProductEntity>>

    @Query("SELECT * FROM products WHERE isActive = 1 AND currentStock <= minimumStock")
    suspend fun getLowStockProducts(): List<ProductEntity>

    @Query("SELECT * FROM products WHERE isActive = 1 AND expiryDate IS NOT NULL AND expiryDate <= :thresholdTimestamp")
    fun getExpiringProductsFlow(thresholdTimestamp: Long): Flow<List<ProductEntity>>

    @Query("SELECT SUM(currentStock * purchasePrice) FROM products WHERE isActive = 1")
    fun getTotalStockValuationFlow(): Flow<Double?>

    @Query("SELECT COUNT(*) FROM products WHERE isActive = 1")
    fun getTotalProductCountFlow(): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProduct(product: ProductEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProducts(products: List<ProductEntity>): List<Long>

    @Update
    suspend fun updateProduct(product: ProductEntity)

    @Query("UPDATE products SET currentStock = currentStock + :delta, updatedAt = :timestamp WHERE id = :productId")
    suspend fun adjustProductStock(productId: Long, delta: Double, timestamp: Long = System.currentTimeMillis())

    @Query("UPDATE products SET isActive = 0 WHERE id = :id")
    suspend fun softDeleteProduct(id: Long)

    // Aliases
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAlias(alias: ProductAliasEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAliases(aliases: List<ProductAliasEntity>)

    @Query("SELECT * FROM product_aliases WHERE productId = :productId")
    suspend fun getAliasesForProduct(productId: Long): List<ProductAliasEntity>

    // Categories
    @Query("SELECT * FROM categories ORDER BY name ASC")
    fun getAllCategoriesFlow(): Flow<List<CategoryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCategory(category: CategoryEntity): Long

    // Inventory Transactions
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertInventoryTransaction(tx: InventoryTransactionEntity): Long

    @Query("SELECT * FROM inventory_transactions WHERE productId = :productId ORDER BY timestamp DESC")
    fun getProductInventoryHistory(productId: Long): Flow<List<InventoryTransactionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStockAdjustment(adjustment: StockAdjustmentEntity): Long
}
