package com.vyaparai.app.core.printer

import java.io.ByteArrayOutputStream
import java.nio.charset.Charset

enum class ThermalPaperWidth(val columnWidth: Int) {
    MM_58(32),
    MM_80(48)
}

object EscPosThermalDriver {
    // ESC/POS Command Constants
    private val ESC: Byte = 0x1B
    private val GS: Byte = 0x1D
    private val LF: Byte = 0x0A

    val CMD_INIT = byteArrayOf(ESC, '@'.code.toByte())
    val CMD_ALIGN_LEFT = byteArrayOf(ESC, 'a'.code.toByte(), 0x00)
    val CMD_ALIGN_CENTER = byteArrayOf(ESC, 'a'.code.toByte(), 0x01)
    val CMD_ALIGN_RIGHT = byteArrayOf(ESC, 'a'.code.toByte(), 0x02)
    val CMD_BOLD_ON = byteArrayOf(ESC, 'E'.code.toByte(), 0x01)
    val CMD_BOLD_OFF = byteArrayOf(ESC, 'E'.code.toByte(), 0x00)
    val CMD_DOUBLE_HEIGHT_ON = byteArrayOf(GS, '!'.code.toByte(), 0x10)
    val CMD_DOUBLE_WIDTH_ON = byteArrayOf(GS, '!'.code.toByte(), 0x20)
    val CMD_NORMAL_SIZE = byteArrayOf(GS, '!'.code.toByte(), 0x00)
    val CMD_CUT_PAPER = byteArrayOf(GS, 'V'.code.toByte(), 0x41, 0x00)

    fun formatThermalReceipt(
        businessName: String,
        address: String?,
        mobile: String?,
        gstin: String?,
        invoiceNumber: String,
        date: String,
        customerName: String?,
        items: List<ThermalPrintItem>,
        subtotal: Double,
        discount: Double,
        gst: Double,
        grandTotal: Double,
        paymentMethod: String,
        paperWidth: ThermalPaperWidth = ThermalPaperWidth.MM_58
    ): ByteArray {
        val stream = ByteArrayOutputStream()
        val cols = paperWidth.columnWidth
        val charset = Charset.forName("CP437")

        stream.write(CMD_INIT)

        // Header
        stream.write(CMD_ALIGN_CENTER)
        stream.write(CMD_BOLD_ON)
        stream.write(CMD_DOUBLE_HEIGHT_ON)
        stream.write("$businessName\n".toByteArray(charset))
        stream.write(CMD_NORMAL_SIZE)
        stream.write(CMD_BOLD_OFF)

        if (!address.isNullOrBlank()) stream.write("$address\n".toByteArray(charset))
        if (!mobile.isNullOrBlank()) stream.write("Tel: $mobile\n".toByteArray(charset))
        if (!gstin.isNullOrBlank()) stream.write("GSTIN: $gstin\n".toByteArray(charset))

        // Divider
        stream.write(createDivider(cols).toByteArray(charset))

        // Invoice Meta
        stream.write(CMD_ALIGN_LEFT)
        stream.write("Invoice: $invoiceNumber\n".toByteArray(charset))
        stream.write("Date: $date\n".toByteArray(charset))
        if (!customerName.isNullOrBlank()) {
            stream.write("Customer: $customerName\n".toByteArray(charset))
        }

        stream.write(createDivider(cols).toByteArray(charset))

        // Table Header
        stream.write(CMD_BOLD_ON)
        stream.write(formatColumns("Item", "Qty", "Price", "Amt", cols).toByteArray(charset))
        stream.write(CMD_BOLD_OFF)
        stream.write(createDivider(cols, '-').toByteArray(charset))

        // Items
        for (item in items) {
            val nameLine = if (item.name.length > cols - 16) item.name.take(cols - 16) else item.name
            val qtyStr = "${item.quantity}"
            val priceStr = "₹${item.rate.toInt()}"
            val amtStr = "₹${item.amount.toInt()}"
            stream.write(formatColumns(nameLine, qtyStr, priceStr, amtStr, cols).toByteArray(charset))
        }

        stream.write(createDivider(cols, '-').toByteArray(charset))

        // Totals
        stream.write(formatTwoCol("Subtotal:", "₹%.2f".format(subtotal), cols).toByteArray(charset))
        if (discount > 0) {
            stream.write(formatTwoCol("Discount:", "-₹%.2f".format(discount), cols).toByteArray(charset))
        }
        if (gst > 0) {
            stream.write(formatTwoCol("GST:", "₹%.2f".format(gst), cols).toByteArray(charset))
        }

        stream.write(createDivider(cols).toByteArray(charset))
        stream.write(CMD_BOLD_ON)
        stream.write(formatTwoCol("TOTAL:", "₹%.2f".format(grandTotal), cols).toByteArray(charset))
        stream.write(CMD_BOLD_OFF)
        stream.write(createDivider(cols).toByteArray(charset))

        // Payment Mode & Footer
        stream.write(CMD_ALIGN_LEFT)
        stream.write("Paid via: $paymentMethod\n".toByteArray(charset))
        stream.write(CMD_ALIGN_CENTER)
        stream.write("\nThank You! Visit Again\n".toByteArray(charset))
        stream.write("Powered by VYAPAR AI\n\n\n".toByteArray(charset))

        // Feed & Cut
        stream.write(byteArrayOf(LF, LF, LF))
        stream.write(CMD_CUT_PAPER)

        return stream.toByteArray()
    }

    private fun createDivider(width: Int, char: Char = '='): String {
        return char.toString().repeat(width) + "\n"
    }

    private fun formatTwoCol(left: String, right: String, width: Int): String {
        val spaces = (width - left.length - right.length).coerceAtLeast(1)
        return left + " ".repeat(spaces) + right + "\n"
    }

    private fun formatColumns(c1: String, c2: String, c3: String, c4: String, width: Int): String {
        // Distribute columns: e.g. 58mm (32 chars): c1(12), c2(5), c3(7), c4(8)
        val w1 = if (width == 48) 20 else 12
        val w2 = if (width == 48) 8 else 5
        val w3 = if (width == 48) 10 else 7
        val w4 = width - w1 - w2 - w3

        val col1 = c1.padEnd(w1).take(w1)
        val col2 = c2.padStart(w2).take(w2)
        val col3 = c3.padStart(w3).take(w3)
        val col4 = c4.padStart(w4).take(w4)

        return "$col1$col2$col3$col4\n"
    }
}

data class ThermalPrintItem(
    val name: String,
    val quantity: Double,
    val rate: Double,
    val amount: Double
)
