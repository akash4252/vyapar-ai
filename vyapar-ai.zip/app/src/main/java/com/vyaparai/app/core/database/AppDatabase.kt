package com.vyaparai.app.core.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.vyaparai.app.core.database.daos.CustomerKhataDao
import com.vyaparai.app.core.database.daos.InvoiceDao
import com.vyaparai.app.core.database.daos.ProductDao
import com.vyaparai.app.core.database.daos.SettingsBusinessDao
import com.vyaparai.app.core.database.daos.SupplierPurchaseDao
import com.vyaparai.app.core.database.entities.AppSettingsEntity
import com.vyaparai.app.core.database.entities.AuditLogEntity
import com.vyaparai.app.core.database.entities.BrandEntity
import com.vyaparai.app.core.database.entities.BusinessEntity
import com.vyaparai.app.core.database.entities.CategoryEntity
import com.vyaparai.app.core.database.entities.CustomerEntity
import com.vyaparai.app.core.database.entities.CustomerTransactionEntity
import com.vyaparai.app.core.database.entities.ExpenseEntity
import com.vyaparai.app.core.database.entities.InventoryTransactionEntity
import com.vyaparai.app.core.database.entities.InvoiceEntity
import com.vyaparai.app.core.database.entities.InvoiceItemEntity
import com.vyaparai.app.core.database.entities.InvoiceSettingsEntity
import com.vyaparai.app.core.database.entities.LoyaltyAccountEntity
import com.vyaparai.app.core.database.entities.LoyaltyTransactionEntity
import com.vyaparai.app.core.database.entities.PaymentEntity
import com.vyaparai.app.core.database.entities.ProductAliasEntity
import com.vyaparai.app.core.database.entities.ProductEntity
import com.vyaparai.app.core.database.entities.PurchaseEntity
import com.vyaparai.app.core.database.entities.PurchaseItemEntity
import com.vyaparai.app.core.database.entities.PurchaseOrderEntity
import com.vyaparai.app.core.database.entities.PurchaseOrderItemEntity
import com.vyaparai.app.core.database.entities.PurchaseReturnEntity
import com.vyaparai.app.core.database.entities.PurchaseReturnItemEntity
import com.vyaparai.app.core.database.entities.SalesReturnEntity
import com.vyaparai.app.core.database.entities.SalesReturnItemEntity
import com.vyaparai.app.core.database.entities.StockAdjustmentEntity
import com.vyaparai.app.core.database.entities.SupplierEntity
import com.vyaparai.app.core.database.entities.SupplierTransactionEntity
import com.vyaparai.app.core.database.entities.SyncQueueEntity
import com.vyaparai.app.core.database.entities.TaxRateEntity

@Database(
    entities = [
        BusinessEntity::class,
        ProductEntity::class,
        ProductAliasEntity::class,
        CategoryEntity::class,
        BrandEntity::class,
        CustomerEntity::class,
        CustomerTransactionEntity::class,
        SupplierEntity::class,
        SupplierTransactionEntity::class,
        InvoiceEntity::class,
        InvoiceItemEntity::class,
        PaymentEntity::class,
        PurchaseEntity::class,
        PurchaseItemEntity::class,
        PurchaseOrderEntity::class,
        PurchaseOrderItemEntity::class,
        InventoryTransactionEntity::class,
        StockAdjustmentEntity::class,
        SalesReturnEntity::class,
        SalesReturnItemEntity::class,
        PurchaseReturnEntity::class,
        PurchaseReturnItemEntity::class,
        LoyaltyAccountEntity::class,
        LoyaltyTransactionEntity::class,
        ExpenseEntity::class,
        TaxRateEntity::class,
        InvoiceSettingsEntity::class,
        AppSettingsEntity::class,
        SyncQueueEntity::class,
        AuditLogEntity::class
    ],
    version = 1,
    exportSchema = true
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {

    abstract fun productDao(): ProductDao
    abstract fun invoiceDao(): InvoiceDao
    abstract fun customerKhataDao(): CustomerKhataDao
    abstract fun supplierPurchaseDao(): SupplierPurchaseDao
    abstract fun settingsBusinessDao(): SettingsBusinessDao

    companion object {
        private const val DB_NAME = "vyapar_ai.db"

        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    DB_NAME
                )
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
