package com.vyaparai.app.presentation.navigation

sealed class NavRoutes(val route: String) {
    // Phase 1: Launch & Onboarding
    data object Splash : NavRoutes("splash")
    data object OnboardingWelcome : NavRoutes("onboarding_welcome")
    data object ShopTypeSelection : NavRoutes("shop_type_selection")
    data object BusinessDetailsSetup : NavRoutes("business_details_setup")
    data object InvoiceSettingsSetup : NavRoutes("invoice_settings_setup")
    data object SecuritySetup : NavRoutes("security_setup")
    data object BackupSetup : NavRoutes("backup_setup")

    // Main Tabs
    data object Dashboard : NavRoutes("dashboard")
    data object FastBilling : NavRoutes("fast_billing")
    data object InventoryDashboard : NavRoutes("inventory_dashboard")
    data object DigitalKhata : NavRoutes("digital_khata")
    data object MoreHub : NavRoutes("more_hub")

    // POS & Invoicing
    data object BarcodeScanner : NavRoutes("barcode_scanner")
    data object PaymentCheckout : NavRoutes("payment_checkout")
    data object InvoiceSuccessPreview : NavRoutes("invoice_success/{invoiceNumber}") {
        fun createRoute(invoiceNumber: String) = "invoice_success/$invoiceNumber"
    }
    data object BillHistory : NavRoutes("bill_history")
    data object SalesReturn : NavRoutes("sales_return")

    // Products & Inventory
    data object ProductList : NavRoutes("product_list")
    data object AddProduct : NavRoutes("add_product")
    data object EditProduct : NavRoutes("edit_product/{productId}") {
        fun createRoute(productId: Long) = "edit_product/$productId"
    }
    data object StockAdjustment : NavRoutes("stock_adjustment")
    data object LowStockAlerts : NavRoutes("low_stock_alerts")
    data object ExpiryTracker : NavRoutes("expiry_tracker")

    // Customers & Khata
    data object CustomerList : NavRoutes("customer_list")
    data object CustomerProfile : NavRoutes("customer_profile/{customerId}") {
        fun createRoute(customerId: Long) = "customer_profile/$customerId"
    }
    data object AddKhataTransaction : NavRoutes("add_khata_tx/{customerId}") {
        fun createRoute(customerId: Long) = "add_khata_tx/$customerId"
    }
    data object CustomerLoyalty : NavRoutes("customer_loyalty")

    // Suppliers & Purchases
    data object SupplierList : NavRoutes("supplier_list")
    data object SupplierProfile : NavRoutes("supplier_profile/{supplierId}") {
        fun createRoute(supplierId: Long) = "supplier_profile/$supplierId"
    }
    data object NewPurchase : NavRoutes("new_purchase")
    data object PurchaseHistory : NavRoutes("purchase_history")
    data object SmartPurchaseOrder : NavRoutes("smart_purchase_order")
    data object PurchaseReturn : NavRoutes("purchase_return")
    data object AiBillScanner : NavRoutes("ai_bill_scanner")

    // Reports & Expenses
    data object ReportsHub : NavRoutes("reports_hub")
    data object SalesReport : NavRoutes("sales_report")
    data object ProfitReport : NavRoutes("profit_report")
    data object GstReport : NavRoutes("gst_report")
    data object ExpenseManager : NavRoutes("expense_manager")

    // AI & Intelligence
    data object AiBusinessAssistant : NavRoutes("ai_business_assistant")

    // Settings & Security
    data object SettingsHub : NavRoutes("settings_hub")
    data object BusinessSettings : NavRoutes("business_settings")
    data object InvoiceSettings : NavRoutes("invoice_settings")
    data object GstSettings : NavRoutes("gst_settings")
    data object PrinterSettings : NavRoutes("printer_settings")
    data object AppLockSecurity : NavRoutes("app_lock_security")
    data object BackupRestore : NavRoutes("backup_restore")
    data object LanguageSettings : NavRoutes("language_settings")
    data object AboutApp : NavRoutes("about_app")
}
