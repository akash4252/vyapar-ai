package com.vyaparai.app.presentation.screens.inventory

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vyaparai.app.VyaparAiApplication
import com.vyaparai.app.core.theme.VyaparGreenPrimary
import com.vyaparai.app.core.theme.VyaparSecondaryAmber
import com.vyaparai.app.core.utils.CurrencyFormatter
import com.vyaparai.app.presentation.common.VyaparPrimaryButton
import com.vyaparai.app.presentation.common.VyaparTopBar

@Composable
fun LowStockAlertsScreen(
    onGeneratePoClick: () -> Unit,
    onBackClick: () -> Unit
) {
    val context = LocalContext.current
    val app = context.applicationContext as VyaparAiApplication

    val lowStockList by app.container.productRepository.getLowStockProducts().collectAsState(initial = emptyList())

    Scaffold(
        topBar = {
            VyaparTopBar(
                title = "Low Stock Alerts",
                subtitle = "${lowStockList.size} items need reordering",
                showBackButton = true,
                onBackClick = onBackClick
            )
        },
        bottomBar = {
            if (lowStockList.isNotEmpty()) {
                Surface(color = MaterialTheme.colorScheme.surface, shadowElevation = 6.dp) {
                    Box(modifier = Modifier.fillMaxWidth().padding(16.dp)) {
                        VyaparPrimaryButton(
                            text = "CREATE SMART PURCHASE ORDER",
                            onClick = onGeneratePoClick,
                            icon = Icons.Default.AutoAwesome
                        )
                    }
                }
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
        ) {
            if (lowStockList.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = null,
                            tint = Color(0xFF16A34A),
                            modifier = Modifier.size(64.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "All Stock Levels Healthy!",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "No products currently below their minimum stock threshold.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(lowStockList) { product ->
                        val deficit = (product.maximumStock - product.currentStock).coerceAtLeast(1.0)
                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .padding(14.dp)
                                    .fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = product.name,
                                        fontWeight = FontWeight.Bold,
                                        style = MaterialTheme.typography.titleMedium
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Box(
                                            modifier = Modifier
                                                .background(Color(0xFFFEE2E2), shape = RoundedCornerShape(4.dp))
                                                .padding(horizontal = 6.dp, vertical = 2.dp)
                                        ) {
                                            Text(
                                                text = "Current: ${product.currentStock.toInt()} ${product.unit}",
                                                color = Color(0xFFDC2626),
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 11.sp
                                            )
                                        }
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            text = "Min: ${product.minimumStock.toInt()} | Max: ${product.maximumStock.toInt()}",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    Text(
                                        text = "Suggested PO",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = VyaparSecondaryAmber,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "+${deficit.toInt()} ${product.unit}",
                                        fontWeight = FontWeight.ExtraBold,
                                        fontSize = 16.sp,
                                        color = VyaparGreenPrimary
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
