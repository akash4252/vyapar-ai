package com.vyaparai.app.presentation.screens.khata

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vyaparai.app.VyaparAiApplication
import com.vyaparai.app.core.database.entities.CustomerEntity
import com.vyaparai.app.core.theme.VyaparGreenPrimary
import com.vyaparai.app.core.theme.VyaparKhataCredit
import com.vyaparai.app.core.utils.CurrencyFormatter
import com.vyaparai.app.presentation.common.StatCard
import com.vyaparai.app.presentation.common.VyaparTopBar

@Composable
fun DigitalKhataDashboardScreen(
    onCustomerClick: (Long) -> Unit,
    onAddCustomerClick: () -> Unit,
    onLoyaltyClick: () -> Unit,
    onBackClick: () -> Unit
) {
    val context = LocalContext.current
    val app = context.applicationContext as VyaparAiApplication

    val totalPendingKhata by app.container.customerKhataRepository.getTotalPendingKhata().collectAsState(initial = 0.0)
    val debtors by app.container.customerKhataRepository.getKhataDebtors().collectAsState(initial = emptyList())
    val business by app.container.settingsRepository.getBusiness().collectAsState(initial = null)

    var searchQuery by remember { mutableStateOf("") }
    val filteredDebtors = debtors.filter {
        it.name.contains(searchQuery, true) || (it.mobile?.contains(searchQuery, true) == true)
    }

    fun sendWhatsAppReminder(customer: CustomerEntity) {
        val bizName = business?.name ?: "Our Store"
        val message = app.container.customerKhataRepository.generateWhatsAppReminderMessage(
            customerName = customer.name,
            businessName = bizName,
            balance = customer.currentCreditBalance
        )
        val phone = customer.mobile?.replace(Regex("[^0-9]"), "") ?: ""
        val url = if (phone.isNotBlank()) "https://api.whatsapp.com/send?phone=$phone&text=" + Uri.encode(message)
        else "https://api.whatsapp.com/send?text=" + Uri.encode(message)

        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
        try {
            context.startActivity(intent)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    Scaffold(
        topBar = {
            VyaparTopBar(
                title = "Digital Khata & Udhaar",
                subtitle = "Customer Credit Ledger",
                showBackButton = true,
                onBackClick = onBackClick,
                actions = {
                    IconButton(onClick = onLoyaltyClick) {
                        Icon(Icons.Default.CardGiftcard, contentDescription = "Loyalty", tint = Color.White)
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = onAddCustomerClick,
                containerColor = VyaparGreenPrimary,
                shape = RoundedCornerShape(16.dp)
            ) {
                Icon(Icons.Default.PersonAdd, contentDescription = "Add Customer", tint = Color.White)
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
        ) {
            // Total Pending Khata Header Card
            StatCard(
                title = "Total Pending Udhaar (To Collect)",
                value = CurrencyFormatter.format(totalPendingKhata ?: 0.0),
                subtitle = "${debtors.size} customers have pending balance",
                icon = Icons.Default.AccountBalanceWallet,
                iconTint = VyaparKhataCredit,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(16.dp))

            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Search customer name or mobile...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                singleLine = true
            )

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "Customers with Balance (${filteredDebtors.size})",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(8.dp))

            if (filteredDebtors.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF16A34A), modifier = Modifier.size(56.dp))
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("No Pending Khata Balances!", fontWeight = FontWeight.Bold)
                        Text("All customer accounts are settled.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(filteredDebtors) { customer ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onCustomerClick(customer.id) },
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            elevation = CardDefaults.cardElevation(defaultElevation = 1.5.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .padding(14.dp)
                                    .fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(text = customer.name, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                                    Text(
                                        text = customer.mobile ?: "No phone",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    Text(
                                        text = CurrencyFormatter.format(customer.currentCreditBalance),
                                        fontWeight = FontWeight.ExtraBold,
                                        color = VyaparKhataCredit,
                                        fontSize = 16.sp
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    FilledTonalButton(
                                        onClick = { sendWhatsAppReminder(customer) },
                                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(14.dp), tint = Color(0xFF25D366))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Remind", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
