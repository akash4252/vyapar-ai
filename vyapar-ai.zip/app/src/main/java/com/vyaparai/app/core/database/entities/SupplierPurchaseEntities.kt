package com.vyaparai.app.core.database.entities

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "suppliers",
    indices = [
        Index("name"),
        Index("mobile")
    ]
)
data class SupplierEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val companyName: String? = null,
    val mobile: String? = null,
    val email: String? = null,
    val gstin: String? = null,
    val address: String? = null,
    val openingBalance: Double = 0.0,
    val currentOutstanding: Double = 0.0,
    val paymentTerms: String? = "15 Days",
    val notes: String? = null,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "supplier_transactions",
    indices = [
        Index("supplierId"),
        Index("date")
    ],
    foreignKeys = [
        ForeignKey(
            entity = SupplierEntity::class,
            parentColumns = ["id"],
            childColumns = ["supplierId"],
            onDelete = ForeignKey.CASCADE
        )
    ]
)
data class SupplierTransactionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val supplierId: Long,
    val purchaseId: Long? = null,
    val transactionType: String, // PURCHASE_CREDIT, PAYMENT_MADE, PURCHASE_RETURN, ADJUSTMENT
    val amount: Double,
    val balanceAfter: Double,
    val paymentMethod: String? = null,
    val date: Long = System.currentTimeMillis(),
    val notes: String? = null,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "purchases", indices = [Index("supplierId"), Index("createdAt")])
data class PurchaseEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val purchaseNumber: String,
    val supplierId: Long,
    val supplierName: String,
    val invoiceNumber: String? = null,
    val invoiceDate: Long = System.currentTimeMillis(),
    val subtotal: Double,
    val totalGst: Double = 0.0,
    val grandTotal: Double,
    val amountPaid: Double,
    val paymentStatus: String = "PAID", // PAID, PARTIAL, UNPAID
    val paymentMethod: String = "CASH",
    val notes: String? = null,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "purchase_items",
    indices = [Index("purchaseId"), Index("productId")],
    foreignKeys = [
        ForeignKey(
            entity = PurchaseEntity::class,
            parentColumns = ["id"],
            childColumns = ["purchaseId"],
            onDelete = ForeignKey.CASCADE
        )
    ]
)
data class PurchaseItemEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val purchaseId: Long,
    val productId: Long,
    val productName: String,
    val barcode: String? = null,
    val hsnCode: String? = null,
    val quantity: Double,
    val unit: String = "pcs",
    val purchasePrice: Double,
    val gstRate: Double = 0.0,
    val totalAmount: Double,
    val batchNumber: String? = null,
    val expiryDate: Long? = null
)

@Entity(tableName = "purchase_orders", indices = [Index("supplierId")])
data class PurchaseOrderEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val poNumber: String,
    val supplierId: Long,
    val supplierName: String,
    val status: String = "DRAFT", // DRAFT, SENT, PARTIAL, RECEIVED, CANCELLED
    val orderDate: Long = System.currentTimeMillis(),
    val expectedDeliveryDate: Long? = null,
    val totalAmount: Double = 0.0,
    val notes: String? = null
)

@Entity(
    tableName = "purchase_order_items",
    indices = [Index("purchaseOrderId")],
    foreignKeys = [
        ForeignKey(
            entity = PurchaseOrderEntity::class,
            parentColumns = ["id"],
            childColumns = ["purchaseOrderId"],
            onDelete = ForeignKey.CASCADE
        )
    ]
)
data class PurchaseOrderItemEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val purchaseOrderId: Long,
    val productId: Long,
    val productName: String,
    val quantity: Double,
    val expectedPrice: Double = 0.0,
    val receivedQuantity: Double = 0.0
)

@Entity(tableName = "purchase_returns", indices = [Index("purchaseId")])
data class PurchaseReturnEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val returnNumber: String,
    val purchaseId: Long? = null,
    val supplierId: Long,
    val totalAmount: Double,
    val reason: String = "Defective goods",
    val date: Long = System.currentTimeMillis(),
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "purchase_return_items",
    indices = [Index("purchaseReturnId")],
    foreignKeys = [
        ForeignKey(
            entity = PurchaseReturnEntity::class,
            parentColumns = ["id"],
            childColumns = ["purchaseReturnId"],
            onDelete = ForeignKey.CASCADE
        )
    ]
)
data class PurchaseReturnItemEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val purchaseReturnId: Long,
    val productId: Long,
    val quantity: Double,
    val unitPrice: Double,
    val totalAmount: Double
)

@Entity(tableName = "expenses", indices = [Index("date"), Index("category")])
data class ExpenseEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val category: String, // RENT, ELECTRICITY, SALARY, TRANSPORT, INTERNET, PACKAGING, OTHER
    val amount: Double,
    val date: Long = System.currentTimeMillis(),
    val description: String? = null,
    val paymentMethod: String = "CASH"
)
