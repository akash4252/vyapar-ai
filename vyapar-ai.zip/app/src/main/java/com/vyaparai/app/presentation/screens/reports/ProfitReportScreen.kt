package com.vyaparai.app.presentation.screens.reports

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Savings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vyaparai.app.VyaparAiApplication
import com.vyaparai.app.core.theme.VyaparGreenPrimary
import com.vyaparai.app.core.theme.VyaparSuccess
import com.vyaparai.app.core.utils.CurrencyFormatter
import com.vyaparai.app.core.utils.DateUtils
import com.vyaparai.app.presentation.common.StatCard
import com.vyaparai.app.presentation.common.VyaparTopBar

@Composable
fun ProfitReportScreen(
    onBackClick: () -> Unit
) {
    val context = LocalContext.current
    val app = context.applicationContext as VyaparAiApplication

    val startOfDay = DateUtils.getStartOfDay()
    val endOfDay = DateUtils.getEndOfDay()

    val todaySales by app.container.invoiceRepository.getSalesSumBetween(startOfDay, endOfDay).collectAsState(initial = 0.0)
    val todayGrossProfit by app.container.invoiceRepository.getProfitSumBetween(startOfDay, endOfDay).collectAsState(initial = 0.0)
    val todayExpenses by app.container.supplierPurchaseRepository.getTodayExpensesSum().collectAsState(initial = 0.0)

    val gross = todayGrossProfit ?: 0.0
    val expenses = todayExpenses ?: 0.0
    val netProfit = gross - expenses

    Scaffold(
        topBar = {
            VyaparTopBar(
                title = "Profit & Loss",
                subtitle = "Today's Profit Statement",
                showBackButton = true,
                onBackClick = onBackClick
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Net Profit Hero Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = if (netProfit >= 0) VyaparGreenPrimary else MaterialTheme.colorScheme.error)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "TODAY'S NET REALIZED PROFIT",
                        color = Color.White.copy(alpha = 0.85f),
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = CurrencyFormatter.format(netProfit),
                        fontSize = 34.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Gross Profit minus Operating Expenses",
                        color = Color.White.copy(alpha = 0.8f),
                        fontSize = 12.sp
                    )
                }
            }

            // P&L Breakdown Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Statement Breakdown", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                    HorizontalDivider()

                    ProfitRow("Total Sales Revenue (+)", CurrencyFormatter.format(todaySales ?: 0.0), Color.Black)
                    ProfitRow("Gross Margin Profit", CurrencyFormatter.format(gross), VyaparSuccess)
                    ProfitRow("Store Operating Expenses (-)", "-${CurrencyFormatter.format(expenses)}", MaterialTheme.colorScheme.error)

                    HorizontalDivider()
                    ProfitRow("Final Net Profit", CurrencyFormatter.format(netProfit), if (netProfit >= 0) VyaparGreenPrimary else MaterialTheme.colorScheme.error, isBold = true)
                }
            }
        }
    }
}

@Composable
private fun ProfitRow(
    label: String,
    value: String,
    valueColor: Color,
    isBold: Boolean = false
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            fontWeight = if (isBold) FontWeight.Bold else FontWeight.Medium,
            style = if (isBold) MaterialTheme.typography.titleMedium else MaterialTheme.typography.bodyMedium
        )
        Text(
            text = value,
            fontWeight = if (isBold) FontWeight.ExtraBold else FontWeight.Bold,
            color = valueColor,
            style = if (isBold) MaterialTheme.typography.titleMedium else MaterialTheme.typography.bodyMedium
        )
    }
}
