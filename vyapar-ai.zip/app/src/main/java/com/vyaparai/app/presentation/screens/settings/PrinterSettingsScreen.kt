package com.vyaparai.app.presentation.screens.settings

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Print
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vyaparai.app.VyaparAiApplication
import com.vyaparai.app.core.printer.BluetoothPrinterManager
import com.vyaparai.app.core.printer.EscPosThermalDriver
import com.vyaparai.app.core.printer.PairedPrinterDevice
import com.vyaparai.app.core.printer.ThermalPaperWidth
import com.vyaparai.app.core.theme.VyaparGreenPrimary
import com.vyaparai.app.presentation.common.VyaparPrimaryButton
import com.vyaparai.app.presentation.common.VyaparTopBar
import kotlinx.coroutines.launch

@Composable
fun PrinterSettingsScreen(
    onBackClick: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var pairedPrinters by remember { mutableStateOf<List<PairedPrinterDevice>>(emptyList()) }
    var selectedPrinterAddress by remember { mutableStateOf<String?>(null) }
    var selectedWidth by remember { mutableStateOf(ThermalPaperWidth.MM_58) }
    var statusMessage by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) {
        pairedPrinters = BluetoothPrinterManager.getPairedPrinters(context)
        if (pairedPrinters.isNotEmpty()) {
            selectedPrinterAddress = pairedPrinters.first().address
        }
    }

    fun executeTestPrint() {
        val address = selectedPrinterAddress
        if (address == null) {
            statusMessage = "Please select a paired printer first."
            return
        }

        scope.launch {
            statusMessage = "Sending test print to $address..."
            val testBytes = EscPosThermalDriver.formatThermalReceipt(
                businessName = "VYAPAR AI TEST PRINT",
                address = "Thermal Printer Configuration",
                mobile = "9876543210",
                gstin = null,
                invoiceNumber = "TEST-0001",
                date = "27/08/2026",
                customerName = "Self Test",
                items = emptyList(),
                subtotal = 0.0,
                discount = 0.0,
                gst = 0.0,
                grandTotal = 0.0,
                paymentMethod = "TEST",
                paperWidth = selectedWidth
            )

            val res = BluetoothPrinterManager.printData(address, testBytes)
            res.onSuccess {
                statusMessage = "Test print completed successfully!"
            }.onFailure { err ->
                statusMessage = "Print error: ${err.message ?: "Printer unavailable"}"
            }
        }
    }

    Scaffold(
        topBar = {
            VyaparTopBar(
                title = "Thermal Printer Settings",
                subtitle = "ESC/POS Bluetooth Configuration",
                showBackButton = true,
                onBackClick = onBackClick
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text(text = "Paper Width", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(8.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    FilterChip(
                        selected = selectedWidth == ThermalPaperWidth.MM_58,
                        onClick = { selectedWidth = ThermalPaperWidth.MM_58 },
                        label = { Text("58mm (2-inch Thermal)") },
                        modifier = Modifier.weight(1f)
                    )
                    FilterChip(
                        selected = selectedWidth == ThermalPaperWidth.MM_80,
                        onClick = { selectedWidth = ThermalPaperWidth.MM_80 },
                        label = { Text("80mm (3-inch Thermal)") },
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(20.dp))
                Text(text = "Paired Bluetooth Printers", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(8.dp))

                if (pairedPrinters.isEmpty()) {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text("No paired Bluetooth printers detected.", fontWeight = FontWeight.SemiBold)
                            Text(
                                "Pair your thermal printer in Android Bluetooth settings, then return here.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                } else {
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(pairedPrinters) { printer ->
                            val isSelected = printer.address == selectedPrinterAddress
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { selectedPrinterAddress = printer.address },
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(
                                    containerColor = if (isSelected) VyaparGreenPrimary.copy(alpha = 0.12f) else MaterialTheme.colorScheme.surface
                                ),
                                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(14.dp).fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.Bluetooth, contentDescription = null, tint = if (isSelected) VyaparGreenPrimary else MaterialTheme.colorScheme.onSurfaceVariant)
                                        Spacer(modifier = Modifier.width(12.dp))
                                        Column {
                                            Text(text = printer.name, fontWeight = FontWeight.Bold)
                                            Text(text = printer.address, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        }
                                    }
                                    if (isSelected) {
                                        Icon(Icons.Default.CheckCircle, contentDescription = "Selected", tint = VyaparGreenPrimary)
                                    }
                                }
                            }
                        }
                    }
                }

                if (statusMessage != null) {
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = statusMessage!!,
                        color = VyaparGreenPrimary,
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }

            VyaparPrimaryButton(
                text = "TEST PRINT RECEIPT",
                onClick = { executeTestPrint() },
                icon = Icons.Default.Print
            )
        }
    }
}
