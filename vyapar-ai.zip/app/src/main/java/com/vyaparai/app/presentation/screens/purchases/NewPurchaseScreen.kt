package com.vyaparai.app.presentation.screens.purchases

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.vyaparai.app.VyaparAiApplication
import com.vyaparai.app.core.database.entities.ProductEntity
import com.vyaparai.app.core.database.entities.PurchaseEntity
import com.vyaparai.app.core.database.entities.PurchaseItemEntity
import com.vyaparai.app.core.database.entities.SupplierEntity
import com.vyaparai.app.core.theme.VyaparGreenPrimary
import com.vyaparai.app.core.utils.CurrencyFormatter
import com.vyaparai.app.presentation.common.VyaparPrimaryButton
import com.vyaparai.app.presentation.common.VyaparTopBar
import kotlinx.coroutines.launch

data class PurchaseDraftItem(
    val product: ProductEntity,
    val quantity: Double,
    val purchasePrice: Double,
    val gstRate: Double = 0.0,
    val batchNumber: String? = null
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NewPurchaseScreen(
    onSuccess: () -> Unit,
    onBackClick: () -> Unit
) {
    val context = LocalContext.current
    val app = context.applicationContext as VyaparAiApplication
    val scope = rememberCoroutineScope()

    val suppliers by app.container.supplierPurchaseRepository.getAllSuppliers().collectAsState(initial = emptyList())
    val products by app.container.productRepository.getAllProducts().collectAsState(initial = emptyList())

    var selectedSupplier by remember { mutableStateOf<SupplierEntity?>(null) }
    var supplierInvoiceNo by remember { mutableStateOf("") }
    val draftItems = remember { mutableStateListOf<PurchaseDraftItem>() }

    var selectedProductToAdd by remember { mutableStateOf<ProductEntity?>(null) }
    var qtyInput by remember { mutableStateOf("10") }
    var priceInput by remember { mutableStateOf("") }
    var batchInput by remember { mutableStateOf("") }

    var supplierDropdownExpanded by remember { mutableStateOf(false) }
    var productDropdownExpanded by remember { mutableStateOf(false) }

    val totalAmount = draftItems.sumOf { it.quantity * it.purchasePrice }

    Scaffold(
        topBar = {
            VyaparTopBar(
                title = "New Stock Purchase",
                subtitle = "Stock Inward",
                showBackButton = true,
                onBackClick = onBackClick
            )
        },
        bottomBar = {
            if (draftItems.isNotEmpty() && selectedSupplier != null) {
                Surface(color = MaterialTheme.colorScheme.surface, shadowElevation = 6.dp) {
                    Box(modifier = Modifier.fillMaxWidth().padding(16.dp)) {
                        VyaparPrimaryButton(
                            text = "CONFIRM PURCHASE & ADD TO STOCK (${CurrencyFormatter.format(totalAmount)})",
                            onClick = {
                                scope.launch {
                                    val supplier = selectedSupplier!!
                                    val purchase = PurchaseEntity(
                                        purchaseNumber = "PO-${System.currentTimeMillis() % 100000}",
                                        supplierId = supplier.id,
                                        supplierName = supplier.name,
                                        invoiceNumber = supplierInvoiceNo.trim().takeIf { it.isNotBlank() },
                                        subtotal = totalAmount,
                                        grandTotal = totalAmount,
                                        amountPaid = totalAmount
                                    )
                                    val purchaseItems = draftItems.map { item ->
                                        PurchaseItemEntity(
                                            purchaseId = 0,
                                            productId = item.product.id,
                                            productName = item.product.name,
                                            barcode = item.product.barcode,
                                            quantity = item.quantity,
                                            unit = item.product.unit,
                                            purchasePrice = item.purchasePrice,
                                            gstRate = item.gstRate,
                                            totalAmount = item.quantity * item.purchasePrice,
                                            batchNumber = item.batchNumber
                                        )
                                    }
                                    app.container.supplierPurchaseRepository.createPurchase(purchase, purchaseItems)
                                    onSuccess()
                                }
                            },
                            icon = Icons.Default.Save
                        )
                    }
                }
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState())
        ) {
            // Supplier Selection
            ExposedDropdownMenuBox(
                expanded = supplierDropdownExpanded,
                onExpandedChange = { supplierDropdownExpanded = it },
                modifier = Modifier.fillMaxWidth()
            ) {
                OutlinedTextField(
                    value = selectedSupplier?.name ?: "Select Supplier *",
                    onValueChange = {},
                    readOnly = true,
                    label = { Text("Supplier") },
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = supplierDropdownExpanded) },
                    modifier = Modifier.menuAnchor().fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                )
                ExposedDropdownMenu(
                    expanded = supplierDropdownExpanded,
                    onDismissRequest = { supplierDropdownExpanded = false }
                ) {
                    suppliers.forEach { s ->
                        DropdownMenuItem(
                            text = { Text(s.name) },
                            onClick = {
                                selectedSupplier = s
                                supplierDropdownExpanded = false
                            }
                        )
                    }
                }
            }
            Spacer(modifier = Modifier.height(10.dp))

            OutlinedTextField(
                value = supplierInvoiceNo,
                onValueChange = { supplierInvoiceNo = it },
                label = { Text("Supplier Bill / Invoice Number") },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            )

            Spacer(modifier = Modifier.height(20.dp))
            Text(text = "Add Stock Items", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(8.dp))

            // Add Item Box
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    ExposedDropdownMenuBox(
                        expanded = productDropdownExpanded,
                        onExpandedChange = { productDropdownExpanded = it },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        OutlinedTextField(
                            value = selectedProductToAdd?.name ?: "Select Product to Inward",
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Product") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = productDropdownExpanded) },
                            modifier = Modifier.menuAnchor().fillMaxWidth(),
                            shape = RoundedCornerShape(8.dp)
                        )
                        ExposedDropdownMenu(
                            expanded = productDropdownExpanded,
                            onDismissRequest = { productDropdownExpanded = false }
                        ) {
                            products.forEach { p ->
                                DropdownMenuItem(
                                    text = { Text(p.name) },
                                    onClick = {
                                        selectedProductToAdd = p
                                        priceInput = p.purchasePrice.toString()
                                        productDropdownExpanded = false
                                    }
                                )
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = qtyInput,
                            onValueChange = { qtyInput = it },
                            label = { Text("Quantity") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(8.dp)
                        )
                        OutlinedTextField(
                            value = priceInput,
                            onValueChange = { priceInput = it },
                            label = { Text("Purchase Price") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(8.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(10.dp))

                    Button(
                        onClick = {
                            val p = selectedProductToAdd
                            val qty = qtyInput.toDoubleOrNull()
                            val price = priceInput.toDoubleOrNull()
                            if (p != null && qty != null && price != null) {
                                draftItems.add(
                                    PurchaseDraftItem(
                                        product = p,
                                        quantity = qty,
                                        purchasePrice = price,
                                        batchNumber = batchInput.takeIf { it.isNotBlank() }
                                    )
                                )
                                selectedProductToAdd = null
                                qtyInput = "10"
                                priceInput = ""
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = VyaparGreenPrimary),
                        modifier = Modifier.align(Alignment.End),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Add Item")
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Draft Items
            Text(text = "Inward Items (${draftItems.size})", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(8.dp))

            draftItems.forEachIndexed { index, item ->
                Card(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp).fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(item.product.name, fontWeight = FontWeight.Bold)
                            Text("${item.quantity} ${item.product.unit} @ ₹${item.purchasePrice} = ₹${item.quantity * item.purchasePrice}", style = MaterialTheme.typography.bodySmall)
                        }
                        IconButton(onClick = { draftItems.removeAt(index) }) {
                            Icon(Icons.Default.Delete, contentDescription = "Remove", tint = MaterialTheme.colorScheme.error)
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(80.dp))
        }
    }
}
