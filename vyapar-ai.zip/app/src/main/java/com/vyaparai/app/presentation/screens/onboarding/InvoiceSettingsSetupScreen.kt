package com.vyaparai.app.presentation.screens.onboarding

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.vyaparai.app.VyaparAiApplication
import com.vyaparai.app.core.database.entities.InvoiceSettingsEntity
import com.vyaparai.app.presentation.common.VyaparPrimaryButton
import com.vyaparai.app.presentation.common.VyaparTopBar
import kotlinx.coroutines.launch

@Composable
fun InvoiceSettingsSetupScreen(
    onSuccess: () -> Unit,
    onBackClick: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val app = context.applicationContext as VyaparAiApplication

    var prefix by remember { mutableStateOf("VX-2026-") }
    var startingNumber by remember { mutableStateOf("1") }
    var isGstEnabled by remember { mutableStateOf(true) }
    var isTaxInclusive by remember { mutableStateOf(true) }
    var defaultPaymentMethod by remember { mutableStateOf("CASH") }

    Scaffold(
        topBar = {
            VyaparTopBar(
                title = "Invoice Settings",
                subtitle = "Step 3 of 5",
                showBackButton = true,
                onBackClick = onBackClick
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(20.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text(
                    text = "Configure your bills & invoices",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(16.dp))

                OutlinedTextField(
                    value = prefix,
                    onValueChange = { prefix = it },
                    label = { Text("Invoice Prefix (e.g. VX-2026-)") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    singleLine = true
                )
                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = startingNumber,
                    onValueChange = { startingNumber = it },
                    label = { Text("Starting Invoice Number") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    singleLine = true
                )
                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text("Enable GST Invoicing", fontWeight = FontWeight.SemiBold)
                        Text("Include CGST/SGST/IGST breakdown", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Switch(checked = isGstEnabled, onCheckedChange = { isGstEnabled = it })
                }
                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text("Tax-Inclusive Pricing (Default)", fontWeight = FontWeight.SemiBold)
                        Text("Selling price already includes GST", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Switch(checked = isTaxInclusive, onCheckedChange = { isTaxInclusive = it })
                }
            }

            VyaparPrimaryButton(
                text = "CONTINUE",
                onClick = {
                    scope.launch {
                        val startNum = startingNumber.toLongOrNull() ?: 1L
                        app.container.settingsRepository.saveInvoiceSettings(
                            InvoiceSettingsEntity(
                                prefix = prefix.trim(),
                                startingNumber = startNum,
                                nextInvoiceNumber = startNum,
                                isGstEnabled = isGstEnabled,
                                isTaxInclusiveDefault = isTaxInclusive,
                                defaultPaymentMethod = defaultPaymentMethod
                            )
                        )
                        onSuccess()
                    }
                },
                icon = Icons.Default.ArrowForward
            )
        }
    }
}
