package com.vyaparai.app.core.database.entities

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "invoices",
    indices = [
        Index("invoiceNumber", unique = true),
        Index("customerId"),
        Index("createdAt")
    ]
)
data class InvoiceEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val invoiceNumber: String, // VX-2026-000001
    val customerId: Long? = null,
    val customerName: String? = null,
    val customerMobile: String? = null,
    val subtotal: Double,
    val totalDiscount: Double = 0.0,
    val totalGst: Double = 0.0,
    val cgst: Double = 0.0,
    val sgst: Double = 0.0,
    val igst: Double = 0.0,
    val cess: Double = 0.0,
    val grandTotal: Double,
    val amountPaid: Double,
    val creditAmount: Double = 0.0, // Remaining added to Khata
    val paymentStatus: String = "PAID", // PAID, PARTIAL, UNPAID
    val paymentMethod: String = "CASH", // CASH, UPI, CARD, CREDIT, SPLIT
    val splitDetailsJson: String? = null,
    val qrCodeRef: String? = null,
    val notes: String? = null,
    val isCancelled: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "invoice_items",
    indices = [
        Index("invoiceId"),
        Index("productId")
    ],
    foreignKeys = [
        ForeignKey(
            entity = InvoiceEntity::class,
            parentColumns = ["id"],
            childColumns = ["invoiceId"],
            onDelete = ForeignKey.CASCADE
        )
    ]
)
data class InvoiceItemEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val invoiceId: Long,
    val productId: Long,
    val productName: String,
    val barcode: String? = null,
    val hsnCode: String? = null,
    val quantity: Double,
    val unit: String = "pcs",
    val unitPrice: Double,
    val purchasePrice: Double = 0.0,
    val discountAmount: Double = 0.0,
    val gstRate: Double = 0.0,
    val isTaxInclusive: Boolean = true,
    val taxableAmount: Double = 0.0,
    val cgstAmount: Double = 0.0,
    val sgstAmount: Double = 0.0,
    val igstAmount: Double = 0.0,
    val cessAmount: Double = 0.0,
    val totalAmount: Double
)

@Entity(tableName = "payments", indices = [Index("referenceId"), Index("date")])
data class PaymentEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val referenceType: String, // INVOICE, KHATA, PURCHASE
    val referenceId: Long,
    val amount: Double,
    val paymentMethod: String, // CASH, UPI, CARD, BANK
    val transactionRef: String? = null,
    val date: Long = System.currentTimeMillis(),
    val notes: String? = null
)

@Entity(tableName = "sales_returns", indices = [Index("invoiceId")])
data class SalesReturnEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val returnNumber: String,
    val invoiceId: Long,
    val customerId: Long? = null,
    val totalRefundAmount: Double,
    val refundMethod: String = "CASH",
    val reason: String = "Customer Return",
    val date: Long = System.currentTimeMillis(),
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "sales_return_items",
    indices = [Index("salesReturnId")],
    foreignKeys = [
        ForeignKey(
            entity = SalesReturnEntity::class,
            parentColumns = ["id"],
            childColumns = ["salesReturnId"],
            onDelete = ForeignKey.CASCADE
        )
    ]
)
data class SalesReturnItemEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val salesReturnId: Long,
    val productId: Long,
    val productName: String,
    val quantity: Double,
    val refundUnitPrice: Double,
    val totalRefundAmount: Double,
    val restockInventory: Boolean = true
)
