package com.vyaparai.app.presentation.screens.khata

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vyaparai.app.VyaparAiApplication
import com.vyaparai.app.core.database.entities.CustomerEntity
import com.vyaparai.app.core.theme.VyaparGreenPrimary
import com.vyaparai.app.core.theme.VyaparKhataCredit
import com.vyaparai.app.core.utils.CurrencyFormatter
import com.vyaparai.app.core.utils.DateUtils
import com.vyaparai.app.presentation.common.StatCard
import com.vyaparai.app.presentation.common.VyaparPrimaryButton
import com.vyaparai.app.presentation.common.VyaparTopBar

@Composable
fun CustomerProfileDetailScreen(
    customerId: Long,
    onAddTransactionClick: (Long) -> Unit,
    onBackClick: () -> Unit
) {
    val context = LocalContext.current
    val app = context.applicationContext as VyaparAiApplication

    var customer by remember { mutableStateOf<CustomerEntity?>(null) }
    val transactions by app.container.customerKhataRepository.getCustomerTransactions(customerId).collectAsState(initial = emptyList())
    val business by app.container.settingsRepository.getBusiness().collectAsState(initial = null)

    LaunchedEffect(customerId) {
        customer = app.container.customerKhataRepository.getCustomerById(customerId)
    }

    fun sendWhatsAppReminder() {
        val c = customer ?: return
        val bizName = business?.name ?: "Our Store"
        val message = app.container.customerKhataRepository.generateWhatsAppReminderMessage(
            customerName = c.name,
            businessName = bizName,
            balance = c.currentCreditBalance
        )
        val phone = c.mobile?.replace(Regex("[^0-9]"), "") ?: ""
        val url = if (phone.isNotBlank()) "https://api.whatsapp.com/send?phone=$phone&text=" + Uri.encode(message)
        else "https://api.whatsapp.com/send?text=" + Uri.encode(message)

        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
        try {
            context.startActivity(intent)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    Scaffold(
        topBar = {
            VyaparTopBar(
                title = customer?.name ?: "Customer Profile",
                subtitle = customer?.mobile ?: "Khata Ledger",
                showBackButton = true,
                onBackClick = onBackClick,
                actions = {
                    IconButton(onClick = { sendWhatsAppReminder() }) {
                        Icon(Icons.Default.Share, contentDescription = "WhatsApp", tint = Color(0xFF25D366))
                    }
                }
            )
        },
        bottomBar = {
            Surface(color = MaterialTheme.colorScheme.surface, shadowElevation = 6.dp) {
                Box(modifier = Modifier.fillMaxWidth().padding(16.dp)) {
                    VyaparPrimaryButton(
                        text = "+ RECORD KHATA ENTRY",
                        onClick = { onAddTransactionClick(customerId) },
                        icon = Icons.Default.Add
                    )
                }
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
        ) {
            // Profile Card & Balances
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(text = "CURRENT BALANCE DUE", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                            Text(
                                text = CurrencyFormatter.format(customer?.currentCreditBalance ?: 0.0),
                                style = MaterialTheme.typography.headlineMedium,
                                fontWeight = FontWeight.ExtraBold,
                                color = if ((customer?.currentCreditBalance ?: 0.0) > 0) VyaparKhataCredit else Color(0xFF16A34A)
                            )
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(text = "Total Spent: ${CurrencyFormatter.format(customer?.totalSpent ?: 0.0)}", style = MaterialTheme.typography.bodySmall)
                            Text(text = "Loyalty Points: ${customer?.loyaltyPoints ?: 0} pts", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = VyaparGreenPrimary)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(text = "Transaction History", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(8.dp))

            if (transactions.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("No transactions recorded yet.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(transactions) { tx ->
                        val isCredit = tx.transactionType == "SALE_CREDIT"
                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .padding(14.dp)
                                    .fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text(
                                        text = if (isCredit) "Udhaar (Sale Credit)" else "Payment Received (${tx.paymentMethod ?: "Cash"})",
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "${DateUtils.formatDateTime(tx.date)} ${tx.notes?.let { "• $it" } ?: ""}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    Text(
                                        text = if (isCredit) "+${CurrencyFormatter.format(tx.amount)}" else "-${CurrencyFormatter.format(tx.amount)}",
                                        fontWeight = FontWeight.ExtraBold,
                                        color = if (isCredit) VyaparKhataCredit else Color(0xFF16A34A),
                                        fontSize = 16.sp
                                    )
                                    Text(
                                        text = "Bal: ${CurrencyFormatter.format(tx.balanceAfter)}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
