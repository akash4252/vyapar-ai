package com.vyaparai.app.presentation.screens.onboarding

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.vyaparai.app.core.theme.VyaparGreenPrimary
import com.vyaparai.app.presentation.common.VyaparPrimaryButton
import com.vyaparai.app.presentation.common.VyaparTopBar

data class ShopTypeOption(
    val name: String,
    val icon: ImageVector
)

@Composable
fun ShopTypeSelectionScreen(
    onShopTypeSelected: (String) -> Unit,
    onBackClick: () -> Unit
) {
    val shopTypes = listOf(
        ShopTypeOption("Kirana", Icons.Default.LocalGroceryStore),
        ShopTypeOption("Grocery", Icons.Default.ShoppingCart),
        ShopTypeOption("Stationery", Icons.Default.MenuBook),
        ShopTypeOption("General Store", Icons.Default.Storefront),
        ShopTypeOption("Supermarket", Icons.Default.Store),
        ShopTypeOption("Mobile Store", Icons.Default.Smartphone),
        ShopTypeOption("Electronics", Icons.Default.Devices),
        ShopTypeOption("Medical", Icons.Default.LocalHospital),
        ShopTypeOption("Wholesale", Icons.Default.Inventory),
        ShopTypeOption("Other", Icons.Default.Business)
    )

    var selectedType by remember { mutableStateOf("Kirana") }

    Scaffold(
        topBar = {
            VyaparTopBar(
                title = "Shop Category",
                subtitle = "Step 1 of 5",
                showBackButton = true,
                onBackClick = onBackClick
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(20.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text(
                    text = "What type of shop do you run?",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "We will tailor product units and categories for your business.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(20.dp))

                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(shopTypes) { option ->
                        val isSelected = option.name == selectedType
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(95.dp)
                                .clickable { selectedType = option.name }
                                .then(
                                    if (isSelected) Modifier.border(2.dp, VyaparGreenPrimary, RoundedCornerShape(14.dp))
                                    else Modifier
                                ),
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = if (isSelected) VyaparGreenPrimary.copy(alpha = 0.1f) else MaterialTheme.colorScheme.surface
                            ),
                            elevation = CardDefaults.cardElevation(defaultElevation = if (isSelected) 3.dp else 1.dp)
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(12.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center
                            ) {
                                Icon(
                                    imageVector = option.icon,
                                    contentDescription = null,
                                    tint = if (isSelected) VyaparGreenPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(28.dp)
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = option.name,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                    color = if (isSelected) VyaparGreenPrimary else MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }
                }
            }

            VyaparPrimaryButton(
                text = "CONTINUE",
                onClick = { onShopTypeSelected(selectedType) },
                icon = Icons.Default.ArrowForward
            )
        }
    }
}
