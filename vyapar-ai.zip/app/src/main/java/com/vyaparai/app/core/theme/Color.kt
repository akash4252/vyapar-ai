package com.vyaparai.app.core.theme

import androidx.compose.ui.graphics.Color

// Primary Brand Colors - Deep Indian Forest Green & Amber Gold
val VyaparGreenPrimary = Color(0xFF0F763E)
val VyaparGreenOnPrimary = Color(0xFFFFFFFF)
val VyaparGreenContainer = Color(0xFFD1E7DD)
val VyaparGreenOnContainer = Color(0xFF063B1D)

val VyaparSecondaryAmber = Color(0xFFD97706)
val VyaparOnSecondary = Color(0xFFFFFFFF)
val VyaparSecondaryContainer = Color(0xFFFEF3C7)
val VyaparOnSecondaryContainer = Color(0xFF78350F)

val VyaparTertiaryBlue = Color(0xFF2563EB)
val VyaparOnTertiary = Color(0xFFFFFFFF)
val VyaparTertiaryContainer = Color(0xFFDBEAFE)
val VyaparOnTertiaryContainer = Color(0xFF1E3A8A)

// Neutral & Backgrounds
val VyaparLightBackground = Color(0xFFF8FAFC)
val VyaparLightSurface = Color(0xFFFFFFFF)
val VyaparLightSurfaceVariant = Color(0xFFF1F5F9)
val VyaparLightOnSurface = Color(0xFF0F172A)
val VyaparLightOnSurfaceVariant = Color(0xFF64748B)
val VyaparLightOutline = Color(0xFFCBD5E1)

// Dark Palette
val VyaparDarkPrimary = Color(0xFF34D399)
val VyaparDarkBackground = Color(0xFF0F172A)
val VyaparDarkSurface = Color(0xFF1E293B)
val VyaparDarkSurfaceVariant = Color(0xFF334155)
val VyaparDarkOnSurface = Color(0xFFF8FAFC)
val VyaparDarkOnSurfaceVariant = Color(0xFF94A3B8)
val VyaparDarkOutline = Color(0xFF475569)

// Semantic Colors
val VyaparSuccess = Color(0xFF16A34A)
val VyaparWarning = Color(0xFFEAB308)
val VyaparError = Color(0xFFDC2626)
val VyaparKhataCredit = Color(0xFFDC2626) // Red for Udhaar / Pending
val VyaparKhataPayment = Color(0xFF16A34A) // Green for Received
val VyaparCash = Color(0xFF059669)
val VyaparUpi = Color(0xFF7C3AED)
