package com.vyaparai.app.core.database.entities

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "businesses")
data class BusinessEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val ownerName: String,
    val mobile: String,
    val email: String? = null,
    val address: String? = null,
    val city: String? = null,
    val state: String? = null,
    val pinCode: String? = null,
    val gstin: String? = null,
    val upiId: String? = null,
    val logoUri: String? = null,
    val shopType: String = "Kirana",
    val currencySymbol: String = "₹",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "categories")
data class CategoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val icon: String? = null,
    val colorHex: String? = null
)

@Entity(tableName = "brands")
data class BrandEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String
)

@Entity(tableName = "tax_rates")
data class TaxRateEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val rate: Double,
    val isDefault: Boolean = false
)

@Entity(tableName = "invoice_settings")
data class InvoiceSettingsEntity(
    @PrimaryKey val id: Long = 1,
    val prefix: String = "VX-2026-",
    val startingNumber: Long = 1,
    val nextInvoiceNumber: Long = 1,
    val isGstEnabled: Boolean = true,
    val isTaxInclusiveDefault: Boolean = true,
    val defaultPaymentMethod: String = "CASH",
    val termsAndConditions: String = "Thank you for your business! Goods once sold will not be taken back.",
    val showLogo: Boolean = true,
    val showQr: Boolean = true
)

@Entity(tableName = "app_settings")
data class AppSettingsEntity(
    @PrimaryKey val id: Long = 1,
    val language: String = "EN", // EN, HI, MR
    val isBiometricEnabled: Boolean = false,
    val pinHash: String? = null,
    val autoLockDelayMinutes: Int = 5, // 0 = Immediate, 1, 5, 15, -1 = Never
    val isAutoBackupEnabled: Boolean = true,
    val backupFrequencyDays: Int = 1,
    val lastBackupDate: Long = 0,
    val themeMode: String = "SYSTEM" // LIGHT, DARK, SYSTEM
)

@Entity(tableName = "sync_queue", indices = [Index("status")])
data class SyncQueueEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val entityType: String,
    val entityId: Long,
    val operation: String, // CREATE, UPDATE, DELETE
    val payloadJson: String,
    val status: String = "PENDING", // PENDING, SYNCED, FAILED
    val retryCount: Int = 0,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "audit_logs", indices = [Index("timestamp")])
data class AuditLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val action: String,
    val entityType: String,
    val entityId: Long,
    val details: String,
    val timestamp: Long = System.currentTimeMillis()
)
