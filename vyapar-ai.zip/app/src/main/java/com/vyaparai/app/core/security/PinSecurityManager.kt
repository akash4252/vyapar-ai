package com.vyaparai.app.core.security

import java.security.MessageDigest

object PinSecurityManager {
    private const val SALT = "VyaparAi_Salt_2026_Retail"
    private const val MAX_FAILED_ATTEMPTS = 5
    private const val LOCKOUT_DURATION_MS = 30_000L // 30 seconds lockout

    private var failedAttempts = 0
    private var lockoutTimestamp = 0L

    fun hashPin(pin: String): String {
        val md = MessageDigest.getInstance("SHA-256")
        val combined = "$pin:$SALT".toByteArray(Charsets.UTF_8)
        val digest = md.digest(combined)
        return digest.joinToString("") { "%02x".format(it) }
    }

    fun verifyPin(inputPin: String, storedHash: String): Boolean {
        if (isLockedOut()) return false

        val inputHash = hashPin(inputPin)
        val isMatch = (inputHash == storedHash)

        if (isMatch) {
            resetAttempts()
        } else {
            recordFailedAttempt()
        }
        return isMatch
    }

    fun isLockedOut(): Boolean {
        if (failedAttempts >= MAX_FAILED_ATTEMPTS) {
            val elapsed = System.currentTimeMillis() - lockoutTimestamp
            if (elapsed < LOCKOUT_DURATION_MS) {
                return true
            } else {
                resetAttempts()
            }
        }
        return false
    }

    fun getRemainingLockoutSeconds(): Int {
        if (!isLockedOut()) return 0
        val elapsed = System.currentTimeMillis() - lockoutTimestamp
        return ((LOCKOUT_DURATION_MS - elapsed) / 1000).toInt().coerceAtLeast(0)
    }

    private fun recordFailedAttempt() {
        failedAttempts++
        if (failedAttempts >= MAX_FAILED_ATTEMPTS) {
            lockoutTimestamp = System.currentTimeMillis()
        }
    }

    private fun resetAttempts() {
        failedAttempts = 0
        lockoutTimestamp = 0L
    }
}
