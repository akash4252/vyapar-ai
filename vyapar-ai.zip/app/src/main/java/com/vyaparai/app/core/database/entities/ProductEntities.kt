package com.vyaparai.app.core.database.entities

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "products",
    indices = [
        Index("barcode", unique = false),
        Index("name"),
        Index("sku"),
        Index("categoryId")
    ]
)
data class ProductEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val barcode: String? = null,
    val sku: String? = null,
    val categoryId: Long? = null,
    val brandId: Long? = null,
    val unit: String = "pcs", // pcs, kg, g, litre, ml, box, packet, dozen, meter, set
    val purchasePrice: Double = 0.0,
    val sellingPrice: Double = 0.0,
    val mrp: Double = 0.0,
    val wholesalePrice: Double? = null,
    val gstRate: Double = 0.0, // 0%, 5%, 12%, 18%, 28%
    val cessRate: Double = 0.0,
    val isTaxInclusive: Boolean = true,
    val openingStock: Double = 0.0,
    val currentStock: Double = 0.0,
    val minimumStock: Double = 5.0,
    val maximumStock: Double = 50.0,
    val supplierId: Long? = null,
    val batchNumber: String? = null,
    val expiryDate: Long? = null,
    val imageUri: String? = null,
    val description: String? = null,
    val isActive: Boolean = true,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "product_aliases",
    indices = [
        Index("productId"),
        Index("alias")
    ],
    foreignKeys = [
        ForeignKey(
            entity = ProductEntity::class,
            parentColumns = ["id"],
            childColumns = ["productId"],
            onDelete = ForeignKey.CASCADE
        )
    ]
)
data class ProductAliasEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val productId: Long,
    val alias: String,
    val language: String = "ALL" // EN, HI, MR, ALL
)

@Entity(
    tableName = "inventory_transactions",
    indices = [
        Index("productId"),
        Index("timestamp")
    ]
)
data class InventoryTransactionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val productId: Long,
    val transactionType: String, // OPENING, PURCHASE, SALE, SALE_RETURN, PURCHASE_RETURN, DAMAGE, ADJUSTMENT
    val quantity: Double, // positive or negative
    val stockBefore: Double,
    val stockAfter: Double,
    val referenceType: String? = null, // INVOICE, PURCHASE, ADJUSTMENT
    val referenceId: Long? = null,
    val notes: String? = null,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "stock_adjustments", indices = [Index("productId")])
data class StockAdjustmentEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val productId: Long,
    val adjustedQuantity: Double,
    val reason: String, // DAMAGED, EXPIRED, AUDIT_CORRECTION, THEFT, OTHER
    val notes: String? = null,
    val date: Long = System.currentTimeMillis()
)
