package com.vyaparai.app.core.database.daos

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.vyaparai.app.core.database.entities.AppSettingsEntity
import com.vyaparai.app.core.database.entities.AuditLogEntity
import com.vyaparai.app.core.database.entities.BusinessEntity
import com.vyaparai.app.core.database.entities.InvoiceSettingsEntity
import com.vyaparai.app.core.database.entities.SyncQueueEntity
import com.vyaparai.app.core.database.entities.TaxRateEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface SettingsBusinessDao {
    @Query("SELECT * FROM businesses LIMIT 1")
    fun getBusinessFlow(): Flow<BusinessEntity?>

    @Query("SELECT * FROM businesses LIMIT 1")
    suspend fun getBusiness(): BusinessEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateBusiness(business: BusinessEntity): Long

    @Query("SELECT * FROM invoice_settings WHERE id = 1 LIMIT 1")
    fun getInvoiceSettingsFlow(): Flow<InvoiceSettingsEntity?>

    @Query("SELECT * FROM invoice_settings WHERE id = 1 LIMIT 1")
    suspend fun getInvoiceSettings(): InvoiceSettingsEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateInvoiceSettings(settings: InvoiceSettingsEntity): Long

    @Query("UPDATE invoice_settings SET nextInvoiceNumber = nextInvoiceNumber + 1 WHERE id = 1")
    suspend fun incrementInvoiceSequence()

    @Query("SELECT * FROM app_settings WHERE id = 1 LIMIT 1")
    fun getAppSettingsFlow(): Flow<AppSettingsEntity?>

    @Query("SELECT * FROM app_settings WHERE id = 1 LIMIT 1")
    suspend fun getAppSettings(): AppSettingsEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateAppSettings(settings: AppSettingsEntity): Long

    @Query("SELECT * FROM tax_rates ORDER BY rate ASC")
    fun getAllTaxRatesFlow(): Flow<List<TaxRateEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTaxRate(rate: TaxRateEntity): Long

    // Sync Queue
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun enqueueSync(item: SyncQueueEntity): Long

    @Query("SELECT * FROM sync_queue WHERE status = 'PENDING' ORDER BY createdAt ASC")
    suspend fun getPendingSyncItems(): List<SyncQueueEntity>

    @Query("UPDATE sync_queue SET status = :status WHERE id = :id")
    suspend fun updateSyncStatus(id: Long, status: String)

    // Audit Logs
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAuditLog(log: AuditLogEntity): Long

    @Query("SELECT * FROM audit_logs ORDER BY timestamp DESC LIMIT :limit")
    fun getRecentAuditLogs(limit: Int = 50): Flow<List<AuditLogEntity>>

    @Query("DELETE FROM businesses")
    suspend fun clearAllBusinessData()
}
