package com.vyaparai.app.presentation.screens.khata

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.vyaparai.app.VyaparAiApplication
import com.vyaparai.app.core.database.entities.CustomerEntity
import com.vyaparai.app.presentation.common.VyaparPrimaryButton
import com.vyaparai.app.presentation.common.VyaparTopBar
import kotlinx.coroutines.launch

@Composable
fun AddKhataTransactionScreen(
    customerId: Long,
    onSuccess: () -> Unit,
    onBackClick: () -> Unit
) {
    val context = LocalContext.current
    val app = context.applicationContext as VyaparAiApplication
    val scope = rememberCoroutineScope()

    var customer by remember { mutableStateOf<CustomerEntity?>(null) }
    var transactionType by remember { mutableStateOf("PAYMENT_RECEIVED") } // PAYMENT_RECEIVED or SALE_CREDIT
    var amountInput by remember { mutableStateOf("") }
    var paymentMethod by remember { mutableStateOf("CASH") }
    var notes by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(customerId) {
        customer = app.container.customerKhataRepository.getCustomerById(customerId)
    }

    Scaffold(
        topBar = {
            VyaparTopBar(
                title = "Record Khata Entry",
                subtitle = customer?.name ?: "Customer",
                showBackButton = true,
                onBackClick = onBackClick
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(20.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text(text = "Transaction Type", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    FilterChip(
                        selected = transactionType == "PAYMENT_RECEIVED",
                        onClick = { transactionType = "PAYMENT_RECEIVED" },
                        label = { Text("Payment Received (जमा)") },
                        modifier = Modifier.weight(1f)
                    )
                    FilterChip(
                        selected = transactionType == "SALE_CREDIT",
                        onClick = { transactionType = "SALE_CREDIT" },
                        label = { Text("Add Udhaar (उधार)") },
                        modifier = Modifier.weight(1f)
                    )
                }
                Spacer(modifier = Modifier.height(16.dp))

                OutlinedTextField(
                    value = amountInput,
                    onValueChange = { amountInput = it },
                    label = { Text("Amount (₹) *") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    singleLine = true
                )
                Spacer(modifier = Modifier.height(12.dp))

                if (transactionType == "PAYMENT_RECEIVED") {
                    Text(text = "Payment Mode", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf("CASH", "UPI", "BANK").forEach { mode ->
                            FilterChip(
                                selected = paymentMethod == mode,
                                onClick = { paymentMethod = mode },
                                label = { Text(mode) }
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                }

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Notes / Bill Ref (Optional)") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    maxLines = 2
                )

                if (errorMessage != null) {
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(errorMessage!!, color = MaterialTheme.colorScheme.error)
                }
            }

            VyaparPrimaryButton(
                text = "SAVE ENTRY",
                onClick = {
                    val amt = amountInput.toDoubleOrNull()
                    if (amt == null || amt <= 0) {
                        errorMessage = "Please enter a valid amount"
                    } else {
                        scope.launch {
                            app.container.customerKhataRepository.recordKhataTransaction(
                                customerId = customerId,
                                amount = amt,
                                type = transactionType,
                                paymentMethod = paymentMethod,
                                notes = notes.takeIf { it.isNotBlank() }
                            )
                            onSuccess()
                        }
                    }
                },
                icon = Icons.Default.Save
            )
        }
    }
}
