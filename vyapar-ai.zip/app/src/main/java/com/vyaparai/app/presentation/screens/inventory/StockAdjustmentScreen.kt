package com.vyaparai.app.presentation.screens.inventory

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.vyaparai.app.VyaparAiApplication
import com.vyaparai.app.core.database.entities.ProductEntity
import com.vyaparai.app.presentation.common.VyaparPrimaryButton
import com.vyaparai.app.presentation.common.VyaparTopBar
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StockAdjustmentScreen(
    onSuccess: () -> Unit,
    onBackClick: () -> Unit
) {
    val context = LocalContext.current
    val app = context.applicationContext as VyaparAiApplication
    val scope = rememberCoroutineScope()

    val products by app.container.productRepository.getAllProducts().collectAsState(initial = emptyList())

    var selectedProduct by remember { mutableStateOf<ProductEntity?>(null) }
    var adjustmentType by remember { mutableStateOf("SUBTRACT") } // ADD or SUBTRACT
    var quantityInput by remember { mutableStateOf("") }
    var reason by remember { mutableStateOf("DAMAGED") }
    var notes by remember { mutableStateOf("") }

    val reasons = listOf("DAMAGED", "EXPIRED", "AUDIT_CORRECTION", "THEFT", "OTHER")
    var productDropdownExpanded by remember { mutableStateOf(false) }
    var reasonDropdownExpanded by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            VyaparTopBar(
                title = "Stock Adjustment",
                showBackButton = true,
                onBackClick = onBackClick
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(20.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text(
                    text = "Record Physical Stock Adjustment",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(16.dp))

                // Product Dropdown
                ExposedDropdownMenuBox(
                    expanded = productDropdownExpanded,
                    onExpandedChange = { productDropdownExpanded = it },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    OutlinedTextField(
                        value = selectedProduct?.name ?: "Select Product",
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Product *") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = productDropdownExpanded) },
                        modifier = Modifier.menuAnchor().fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    )
                    ExposedDropdownMenu(
                        expanded = productDropdownExpanded,
                        onDismissRequest = { productDropdownExpanded = false }
                    ) {
                        products.forEach { p ->
                            DropdownMenuItem(
                                text = { Text("${p.name} (Current: ${p.currentStock.toInt()} ${p.unit})") },
                                onClick = {
                                    selectedProduct = p
                                    productDropdownExpanded = false
                                }
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(12.dp))

                // Type: Increase vs Reduce
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    FilterChip(
                        selected = adjustmentType == "SUBTRACT",
                        onClick = { adjustmentType = "SUBTRACT" },
                        label = { Text("Reduce Stock (-)") },
                        modifier = Modifier.weight(1f)
                    )
                    FilterChip(
                        selected = adjustmentType == "ADD",
                        onClick = { adjustmentType = "ADD" },
                        label = { Text("Add Stock (+)") },
                        modifier = Modifier.weight(1f)
                    )
                }
                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = quantityInput,
                    onValueChange = { quantityInput = it },
                    label = { Text("Adjustment Quantity") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    singleLine = true
                )
                Spacer(modifier = Modifier.height(12.dp))

                // Reason Dropdown
                ExposedDropdownMenuBox(
                    expanded = reasonDropdownExpanded,
                    onExpandedChange = { reasonDropdownExpanded = it },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    OutlinedTextField(
                        value = reason.replace("_", " "),
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Reason") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = reasonDropdownExpanded) },
                        modifier = Modifier.menuAnchor().fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    )
                    ExposedDropdownMenu(
                        expanded = reasonDropdownExpanded,
                        onDismissRequest = { reasonDropdownExpanded = false }
                    ) {
                        reasons.forEach { r ->
                            DropdownMenuItem(
                                text = { Text(r.replace("_", " ")) },
                                onClick = {
                                    reason = r
                                    reasonDropdownExpanded = false
                                }
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Notes / Remarks (Optional)") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    maxLines = 2
                )
            }

            VyaparPrimaryButton(
                text = "SAVE ADJUSTMENT",
                onClick = {
                    val p = selectedProduct ?: return@VyaparPrimaryButton
                    val qty = quantityInput.toDoubleOrNull() ?: return@VyaparPrimaryButton
                    val delta = if (adjustmentType == "SUBTRACT") -qty else qty

                    scope.launch {
                        app.container.productRepository.adjustStock(
                            productId = p.id,
                            quantityChange = delta,
                            reason = reason,
                            notes = notes.takeIf { it.isNotBlank() }
                        )
                        onSuccess()
                    }
                },
                icon = Icons.Default.Save
            )
        }
    }
}
