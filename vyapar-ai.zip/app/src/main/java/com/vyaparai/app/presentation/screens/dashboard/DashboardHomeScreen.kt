package com.vyaparai.app.presentation.screens.dashboard

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vyaparai.app.VyaparAiApplication
import com.vyaparai.app.core.database.entities.BusinessEntity
import com.vyaparai.app.core.theme.*
import com.vyaparai.app.core.utils.CurrencyFormatter
import com.vyaparai.app.core.utils.DateUtils
import com.vyaparai.app.core.voice.VoiceCommandResult
import com.vyaparai.app.core.voice.VoiceParserEngine
import com.vyaparai.app.presentation.common.StatCard
import com.vyaparai.app.presentation.common.VoiceConfirmationModal
import com.vyaparai.app.presentation.common.VoiceMicFloatingButton
import com.vyaparai.app.presentation.common.VyaparTopBar
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardHomeScreen(
    onNewBillClick: () -> Unit,
    onVoiceBillClick: () -> Unit,
    onScanClick: () -> Unit,
    onKhataClick: () -> Unit,
    onPurchaseClick: () -> Unit,
    onReportsClick: () -> Unit,
    onProductClick: (Long) -> Unit,
    onInvoiceClick: (String) -> Unit,
    onAiAssistantClick: () -> Unit
) {
    val context = LocalContext.current
    val app = context.applicationContext as VyaparAiApplication
    val scope = rememberCoroutineScope()

    val business by app.container.settingsRepository.getBusiness().collectAsState(initial = null)
    val todaySales by app.container.invoiceRepository.getTodaySalesSum().collectAsState(initial = 0.0)
    val todayProfit by app.container.invoiceRepository.getTodayProfitSum().collectAsState(initial = 0.0)
    val pendingKhata by app.container.customerKhataRepository.getTotalPendingKhata().collectAsState(initial = 0.0)
    val lowStockItems by app.container.productRepository.getLowStockProducts().collectAsState(initial = emptyList())
    val recentInvoices by app.container.invoiceRepository.getAllInvoices().collectAsState(initial = emptyList())
    val topProducts by app.container.invoiceRepository.getTopProducts(5).collectAsState(initial = emptyList())

    var isVoiceActive by remember { mutableStateOf(false) }
    var voiceResultModal by remember { mutableStateOf<VoiceCommandResult?>(null) }

    Scaffold(
        topBar = {
            VyaparTopBar(
                title = business?.name ?: "Vyapar AI",
                subtitle = DateUtils.formatDate(System.currentTimeMillis()),
                showOnlineStatus = true,
                actions = {
                    IconButton(onClick = onAiAssistantClick) {
                        Icon(Icons.Default.AutoAwesome, contentDescription = "AI Assistant", tint = VyaparSecondaryAmber)
                    }
                }
            )
        },
        floatingActionButton = {
            VoiceMicFloatingButton(
                isListening = isVoiceActive,
                onClick = {
                    isVoiceActive = true
                    // Simulate speech capture callback in voice parser
                    val recognized = "Sugar 2kg 80 rupees"
                    val parsed = VoiceParserEngine.parse(recognized)
                    voiceResultModal = parsed
                    isVoiceActive = false
                }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item { Spacer(modifier = Modifier.height(4.dp)) }

            // Large Hero Card: Today's Sales
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = VyaparGreenPrimary),
                    elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .padding(20.dp)
                            .fillMaxWidth()
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "TODAY'S SALES",
                                color = Color.White.copy(alpha = 0.85f),
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                letterSpacing = 1.sp
                            )
                            Icon(Icons.Default.TrendingUp, contentDescription = null, tint = Color.White)
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = CurrencyFormatter.format(todaySales ?: 0.0),
                            fontSize = 34.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color.White
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color.White, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "100% Offline Real-time",
                                color = Color.White.copy(alpha = 0.9f),
                                fontSize = 12.sp
                            )
                        }
                    }
                }
            }

            // Metric Grid Cards
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    StatCard(
                        title = "Today's Profit",
                        value = CurrencyFormatter.format(todayProfit ?: 0.0),
                        icon = Icons.Default.Savings,
                        iconTint = VyaparSuccess,
                        modifier = Modifier.weight(1f)
                    )
                    StatCard(
                        title = "Pending Khata",
                        value = CurrencyFormatter.format(pendingKhata ?: 0.0),
                        icon = Icons.Default.AccountBalanceWallet,
                        iconTint = VyaparKhataCredit,
                        modifier = Modifier.weight(1f),
                        onClick = onKhataClick
                    )
                }
            }

            // Quick Actions Horizontal Bar
            item {
                Text(text = "Quick Actions", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    DashboardQuickActionButton(
                        icon = Icons.Default.AddShoppingCart,
                        label = "New Bill",
                        color = VyaparGreenPrimary,
                        onClick = onNewBillClick
                    )
                    DashboardQuickActionButton(
                        icon = Icons.Default.Mic,
                        label = "Voice Bill",
                        color = VyaparSecondaryAmber,
                        onClick = onVoiceBillClick
                    )
                    DashboardQuickActionButton(
                        icon = Icons.Default.QrCodeScanner,
                        label = "Scan",
                        color = VyaparTertiaryBlue,
                        onClick = onScanClick
                    )
                    DashboardQuickActionButton(
                        icon = Icons.Default.Book,
                        label = "Khata",
                        color = Color(0xFF9333EA),
                        onClick = onKhataClick
                    )
                    DashboardQuickActionButton(
                        icon = Icons.Default.BarChart,
                        label = "Reports",
                        color = Color(0xFF0D9488),
                        onClick = onReportsClick
                    )
                }
            }

            // Low Stock Warning Alert (if any)
            if (lowStockItems.isNotEmpty()) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFFEF2F2))
                    ) {
                        Row(
                            modifier = Modifier
                                .padding(16.dp)
                                .fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Warning, contentDescription = null, tint = Color(0xFFDC2626))
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = "${lowStockItems.size} Low Stock Products",
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFFDC2626)
                                    )
                                    Text(
                                        text = "Tap to view items & reorder",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = Color(0xFF991B1B)
                                    )
                                }
                            }
                            Icon(Icons.Default.ChevronRight, contentDescription = null, tint = Color(0xFFDC2626))
                        }
                    }
                }
            }

            // Recent Bills
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = "Recent Bills", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    TextButton(onClick = onNewBillClick) {
                        Text("View All", color = VyaparGreenPrimary, fontWeight = FontWeight.SemiBold)
                    }
                }
            }

            if (recentInvoices.isEmpty()) {
                item {
                    Text(
                        text = "No bills created today. Tap New Bill or Voice Bill to start!",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                items(recentInvoices.take(5)) { itemWithItems ->
                    val inv = itemWithItems.invoice
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onInvoiceClick(inv.invoiceNumber) },
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .padding(14.dp)
                                .fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(text = inv.invoiceNumber, fontWeight = FontWeight.Bold)
                                Text(
                                    text = inv.customerName ?: "Cash Customer",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = CurrencyFormatter.format(inv.grandTotal),
                                    fontWeight = FontWeight.Bold,
                                    color = VyaparGreenPrimary
                                )
                                Text(
                                    text = DateUtils.formatTime(inv.createdAt),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }

            item { Spacer(modifier = Modifier.height(72.dp)) }
        }

        // Voice Order Confirmation BottomSheet
        if (voiceResultModal != null) {
            VoiceConfirmationModal(
                commandResult = voiceResultModal!!,
                onConfirm = {
                    voiceResultModal = null
                    onNewBillClick()
                },
                onDismiss = { voiceResultModal = null }
            )
        }
    }
}

@Composable
private fun DashboardQuickActionButton(
    icon: ImageVector,
    label: String,
    color: Color,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.clickable { onClick() }
    ) {
        Box(
            modifier = Modifier
                .size(54.dp)
                .background(color.copy(alpha = 0.12f), shape = RoundedCornerShape(16.dp)),
            contentAlignment = Alignment.Center
        ) {
            Icon(imageVector = icon, contentDescription = label, tint = color, modifier = Modifier.size(26.dp))
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(text = label, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.SemiBold)
    }
}
