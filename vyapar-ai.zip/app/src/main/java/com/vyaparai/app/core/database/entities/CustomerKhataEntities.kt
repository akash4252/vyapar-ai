package com.vyaparai.app.core.database.entities

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "customers",
    indices = [
        Index("mobile"),
        Index("name")
    ]
)
data class CustomerEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val mobile: String? = null,
    val email: String? = null,
    val address: String? = null,
    val gstin: String? = null,
    val openingBalance: Double = 0.0,
    val currentCreditBalance: Double = 0.0, // Amount owed by customer to shop
    val totalSpent: Double = 0.0,
    val loyaltyPoints: Int = 0,
    val notes: String? = null,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "customer_transactions",
    indices = [
        Index("customerId"),
        Index("invoiceId"),
        Index("date")
    ],
    foreignKeys = [
        ForeignKey(
            entity = CustomerEntity::class,
            parentColumns = ["id"],
            childColumns = ["customerId"],
            onDelete = ForeignKey.CASCADE
        )
    ]
)
data class CustomerTransactionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val customerId: Long,
    val invoiceId: Long? = null,
    val transactionType: String, // SALE_CREDIT, PAYMENT_RECEIVED, OPENING_BALANCE, REFUND, ADJUSTMENT
    val amount: Double,
    val balanceAfter: Double,
    val paymentMethod: String? = null, // CASH, UPI, CARD, BANK
    val notes: String? = null,
    val date: Long = System.currentTimeMillis(),
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "loyalty_accounts", indices = [Index("customerId", unique = true)])
data class LoyaltyAccountEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val customerId: Long,
    val totalPointsEarned: Int = 0,
    val totalPointsRedeemed: Int = 0,
    val currentBalancePoints: Int = 0,
    val lastUpdated: Long = System.currentTimeMillis()
)

@Entity(tableName = "loyalty_transactions", indices = [Index("customerId")])
data class LoyaltyTransactionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val customerId: Long,
    val invoiceId: Long? = null,
    val type: String, // EARN, REDEEM, EXPIRE, ADJUSTMENT
    val points: Int,
    val equivalentValue: Double = 0.0,
    val date: Long = System.currentTimeMillis()
)
