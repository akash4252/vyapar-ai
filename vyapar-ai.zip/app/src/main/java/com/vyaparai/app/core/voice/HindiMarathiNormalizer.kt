package com.vyaparai.app.core.voice

object HindiMarathiNormalizer {

    private val devanagariDigits = mapOf(
        '०' to '0', '१' to '1', '२' to '2', '३' to '3', '४' to '4',
        '५' to '5', '६' to '6', '७' to '7', '८' to '8', '९' to '9'
    )

    private val spokenNumbers = mapOf(
        // Hindi / Marathi number words
        "aadha" to 0.5, "adha" to 0.5, "आधा" to 0.5, "निमूट" to 0.5, "अर्धा" to 0.5,
        "pav" to 0.25, "paav" to 0.25, "पाव" to 0.25,
        "dedh" to 1.5, "दीड" to 1.5, "डेढ़" to 1.5,
        "dhai" to 2.5, "अडीच" to 2.5, "ढाई" to 2.5,
        "ek" to 1.0, "एक" to 1.0, "one" to 1.0,
        "do" to 2.0, "don" to 2.0, "दोन" to 2.0, "दो" to 2.0, "two" to 2.0,
        "teen" to 3.0, "तीन" to 3.0, "three" to 3.0,
        "char" to 4.0, "chaar" to 4.0, "चार" to 4.0, "four" to 4.0,
        "paanch" to 5.0, "panch" to 5.0, "पांच" to 5.0, "पाच" to 5.0, "five" to 5.0,
        "chhe" to 6.0, "saha" to 6.0, "छह" to 6.0, "सहा" to 6.0, "six" to 6.0,
        "saat" to 7.0, "सात" to 7.0, "seven" to 7.0,
        "aath" to 8.0, "आठ" to 8.0, "eight" to 8.0,
        "nau" to 9.0, "nav" to 9.0, "नौ" to 9.0, "नऊ" to 9.0, "nine" to 9.0,
        "das" to 10.0, "daha" to 10.0, "दस" to 10.0, "दहा" to 10.0, "ten" to 10.0,
        "gyarah" to 11.0, "akara" to 11.0, "ग्यारह" to 11.0, "अकरा" to 11.0,
        "barah" to 12.0, "bara" to 12.0, "बारह" to 12.0, "बारा" to 12.0,
        "bees" to 20.0, "vis" to 20.0, "बीस" to 20.0, "वीस" to 20.0, "twenty" to 20.0,
        "pachas" to 50.0, "pannas" to 50.0, "पचास" to 50.0, "पन्नास" to 50.0, "fifty" to 50.0,
        "sau" to 100.0, "she" to 100.0, "शंभर" to 100.0, "सौ" to 100.0, "hundred" to 100.0,
        "hazar" to 1000.0, "hazaar" to 1000.0, "हजार" to 1000.0, "thousand" to 1000.0
    )

    private val unitAliases = mapOf(
        "kg" to "kg", "kilo" to "kg", "kilos" to "kg", "किलो" to "kg", "केजी" to "kg",
        "g" to "g", "gm" to "g", "gram" to "g", "grams" to "g", "ग्राम" to "g",
        "l" to "litre", "lt" to "litre", "litre" to "litre", "litres" to "litre", "लिटर" to "litre", "लीटर" to "litre",
        "ml" to "ml", "मिली" to "ml",
        "packet" to "packet", "packets" to "packet", "pkt" to "packet", "पुडी" to "packet", "पॅकेट" to "packet", "पैकेट" to "packet",
        "piece" to "pcs", "pieces" to "pcs", "pcs" to "pcs", "pc" to "pcs", "नग" to "pcs", "पीस" to "pcs",
        "dozen" to "dozen", "डझन" to "dozen", "दर्जन" to "dozen",
        "box" to "box", "boxes" to "box", "खोके" to "box", "बॉक्स" to "box"
    )

    fun normalizeDevanagariDigits(input: String): String {
        val sb = StringBuilder()
        for (ch in input) {
            sb.append(devanagariDigits[ch] ?: ch)
        }
        return sb.toString()
    }

    fun parseNumber(token: String): Double? {
        val cleanToken = token.trim().lowercase()
        cleanToken.toDoubleOrNull()?.let { return it }
        return spokenNumbers[cleanToken]
    }

    fun normalizeUnit(token: String): String? {
        val clean = token.trim().lowercase()
        return unitAliases[clean]
    }
}
