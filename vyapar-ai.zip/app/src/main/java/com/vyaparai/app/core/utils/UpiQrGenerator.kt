package com.vyaparai.app.core.utils

import android.graphics.Bitmap
import android.graphics.Color
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.qrcode.QRCodeWriter
import java.net.URLEncoder
import java.nio.charset.StandardCharsets

object UpiQrGenerator {

    /**
     * Builds standard NPCI UPI payment URI
     * e.g. upi://pay?pa=shop@upi&pn=Shree%20Ganesh%20Store&am=500.00&cu=INR&tn=Invoice_VX-2026-0001
     */
    fun createUpiUri(
        upiId: String,
        payeeName: String,
        amount: Double,
        invoiceNumber: String? = null
    ): String {
        val encodedName = URLEncoder.encode(payeeName, StandardCharsets.UTF_8.name())
        val formattedAmount = String.format(java.util.Locale.ENGLISH, "%.2f", amount)
        val note = if (invoiceNumber != null) {
            "&tn=" + URLEncoder.encode("Bill $invoiceNumber", StandardCharsets.UTF_8.name())
        } else ""

        return "upi://pay?pa=$upiId&pn=$encodedName&am=$formattedAmount&cu=INR$note"
    }

    /**
     * Renders a QR code bitmap for any payload string (UPI, Invoice QR, etc.)
     */
    fun generateQrBitmap(content: String, size: Int = 512): Bitmap? {
        if (content.isBlank()) return null
        return try {
            val hints = mapOf(EncodeHintType.MARGIN to 1)
            val bitMatrix = QRCodeWriter().encode(content, BarcodeFormat.QR_CODE, size, size, hints)
            val width = bitMatrix.width
            val height = bitMatrix.height
            val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)

            for (x in 0 until width) {
                for (y in 0 until height) {
                    bitmap.setPixel(x, y, if (bitMatrix[x, y]) Color.BLACK else Color.WHITE)
                }
            }
            bitmap
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }
}
