package com.vyaparai.app.presentation.screens.inventory

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.vyaparai.app.VyaparAiApplication
import com.vyaparai.app.core.theme.VyaparGreenPrimary
import com.vyaparai.app.core.theme.VyaparSecondaryAmber
import com.vyaparai.app.core.utils.CurrencyFormatter
import com.vyaparai.app.presentation.common.StatCard
import com.vyaparai.app.presentation.common.VyaparTopBar

@Composable
fun InventoryDashboardScreen(
    onProductListClick: () -> Unit,
    onStockAdjustmentClick: () -> Unit,
    onLowStockClick: () -> Unit,
    onExpiryTrackerClick: () -> Unit,
    onSmartPoClick: () -> Unit,
    onBackClick: () -> Unit
) {
    val context = LocalContext.current
    val app = context.applicationContext as VyaparAiApplication

    val totalCount by app.container.productRepository.getProductCount().collectAsState(initial = 0)
    val totalValuation by app.container.productRepository.getTotalValuation().collectAsState(initial = 0.0)
    val lowStockList by app.container.productRepository.getLowStockProducts().collectAsState(initial = emptyList())

    Scaffold(
        topBar = {
            VyaparTopBar(
                title = "Inventory & Stock",
                subtitle = "Real-time stock valuation",
                showBackButton = true,
                onBackClick = onBackClick
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Metrics Row
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    StatCard(
                        title = "Total Valuation",
                        value = CurrencyFormatter.format(totalValuation ?: 0.0),
                        icon = Icons.Default.AccountBalance,
                        modifier = Modifier.weight(1f)
                    )
                    StatCard(
                        title = "Total Products",
                        value = "$totalCount",
                        icon = Icons.Default.Category,
                        modifier = Modifier.weight(1f),
                        onClick = onProductListClick
                    )
                }
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    StatCard(
                        title = "Low Stock Alerts",
                        value = "${lowStockList.size}",
                        icon = Icons.Default.Warning,
                        iconTint = MaterialTheme.colorScheme.error,
                        modifier = Modifier.weight(1f),
                        onClick = onLowStockClick
                    )
                    StatCard(
                        title = "Smart PO",
                        value = "Reorder",
                        icon = Icons.Default.AutoAwesome,
                        iconTint = VyaparSecondaryAmber,
                        modifier = Modifier.weight(1f),
                        onClick = onSmartPoClick
                    )
                }
            }

            item {
                Text(text = "Inventory Actions", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            }

            item {
                InventoryActionTile(
                    title = "Product Catalog",
                    description = "View, search, edit and add items to your catalog",
                    icon = Icons.Default.Inventory2,
                    onClick = onProductListClick
                )
            }

            item {
                InventoryActionTile(
                    title = "Stock Adjustment",
                    description = "Record damages, audit corrections, or wastage",
                    icon = Icons.Default.Tune,
                    onClick = onStockAdjustmentClick
                )
            }

            item {
                InventoryActionTile(
                    title = "Low Stock Replenishment",
                    description = "View items below minimum threshold & reorder",
                    icon = Icons.Default.TrendingDown,
                    onClick = onLowStockClick
                )
            }

            item {
                InventoryActionTile(
                    title = "Expiry Date Tracker",
                    description = "Track upcoming batch expiries in 7, 30, and 60 days",
                    icon = Icons.Default.EventBusy,
                    onClick = onExpiryTrackerClick
                )
            }
        }
    }
}

@Composable
private fun InventoryActionTile(
    title: String,
    description: String,
    icon: ImageVector,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.5.dp)
    ) {
        Row(
            modifier = Modifier
                .padding(16.dp)
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .background(VyaparGreenPrimary.copy(alpha = 0.12f), shape = RoundedCornerShape(10.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(imageVector = icon, contentDescription = null, tint = VyaparGreenPrimary)
            }
            Spacer(modifier = Modifier.width(16.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(text = title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                Text(text = description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Icon(Icons.Default.ChevronRight, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
