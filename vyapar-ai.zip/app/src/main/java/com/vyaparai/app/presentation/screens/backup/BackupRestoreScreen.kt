package com.vyaparai.app.presentation.screens.backup

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Backup
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.vyaparai.app.VyaparAiApplication
import com.vyaparai.app.core.theme.VyaparGreenContainer
import com.vyaparai.app.core.theme.VyaparGreenOnContainer
import com.vyaparai.app.core.theme.VyaparGreenPrimary
import com.vyaparai.app.presentation.common.ConfirmActionDialog
import com.vyaparai.app.presentation.common.VyaparPrimaryButton
import com.vyaparai.app.presentation.common.VyaparSecondaryButton
import com.vyaparai.app.presentation.common.VyaparTopBar
import kotlinx.coroutines.launch
import java.io.File

@Composable
fun BackupRestoreScreen(
    onBackClick: () -> Unit
) {
    val context = LocalContext.current
    val app = context.applicationContext as VyaparAiApplication
    val scope = rememberCoroutineScope()

    var statusMessage by remember { mutableStateOf<String?>(null) }
    var detectedBackupFile by remember { mutableStateOf<File?>(null) }
    var showRestoreConfirmDialog by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        detectedBackupFile = app.container.backupRepository.detectExistingBackup(context)
    }

    Scaffold(
        topBar = {
            VyaparTopBar(
                title = "Backup & Restore",
                subtitle = "Hardware-Encrypted Offline Storage",
                showBackButton = true,
                onBackClick = onBackClick
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(20.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(VyaparGreenContainer, shape = RoundedCornerShape(16.dp))
                        .padding(16.dp)
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Security, contentDescription = null, tint = VyaparGreenOnContainer)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("AES-256 Encrypted Backups", fontWeight = FontWeight.Bold, color = VyaparGreenOnContainer)
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Backups encrypt your entire database (products, invoices, Khata ledgers, customers) using hardware Keystore keys.",
                            style = MaterialTheme.typography.bodySmall,
                            color = VyaparGreenOnContainer.copy(alpha = 0.9f)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                Text(text = "Manual Backup Actions", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(12.dp))

                VyaparPrimaryButton(
                    text = "CREATE ENCRYPTED BACKUP NOW",
                    onClick = {
                        scope.launch {
                            val res = app.container.backupRepository.createEncryptedBackup(context)
                            res.onSuccess { file ->
                                detectedBackupFile = file
                                statusMessage = "Backup created successfully: ${file.name}"
                            }.onFailure { err ->
                                statusMessage = "Backup failed: ${err.message}"
                            }
                        }
                    },
                    icon = Icons.Default.Backup
                )

                Spacer(modifier = Modifier.height(16.dp))

                if (detectedBackupFile != null) {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(text = "Latest Backup Detected", fontWeight = FontWeight.Bold)
                            Text(text = detectedBackupFile!!.name, style = MaterialTheme.typography.bodySmall)
                            Spacer(modifier = Modifier.height(12.dp))

                            VyaparSecondaryButton(
                                text = "RESTORE DATABASE FROM BACKUP",
                                onClick = { showRestoreConfirmDialog = true },
                                icon = Icons.Default.Restore
                            )
                        }
                    }
                }

                if (statusMessage != null) {
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = statusMessage!!,
                        color = VyaparGreenPrimary,
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }
        }

        if (showRestoreConfirmDialog && detectedBackupFile != null) {
            ConfirmActionDialog(
                title = "Restore Backup",
                message = "This will restore products, customers, and invoices from the backup snapshot.",
                confirmText = "Restore Now",
                onConfirm = {
                    scope.launch {
                        val res = app.container.backupRepository.restoreEncryptedBackup(detectedBackupFile!!)
                        res.onSuccess {
                            statusMessage = "Database restored successfully!"
                        }.onFailure { err ->
                            statusMessage = "Restore failed: ${err.message}"
                        }
                        showRestoreConfirmDialog = false
                    }
                },
                onDismiss = { showRestoreConfirmDialog = false }
            )
        }
    }
}
