package com.vyaparai.app.presentation.screens.reports

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.vyaparai.app.core.theme.VyaparGreenPrimary
import com.vyaparai.app.presentation.common.VyaparTopBar

@Composable
fun ReportsHubScreen(
    onSalesReportClick: () -> Unit,
    onProfitReportClick: () -> Unit,
    onGstReportClick: () -> Unit,
    onExpenseClick: () -> Unit,
    onBackClick: () -> Unit
) {
    Scaffold(
        topBar = {
            VyaparTopBar(
                title = "Business Reports",
                subtitle = "Sales, Profit & Tax Analytics",
                showBackButton = true,
                onBackClick = onBackClick
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                ReportNavTile(
                    title = "Sales Analytics",
                    subtitle = "Daily, weekly, and monthly sales graphs & trends",
                    icon = Icons.Default.TrendingUp,
                    color = VyaparGreenPrimary,
                    onClick = onSalesReportClick
                )
            }

            item {
                ReportNavTile(
                    title = "Profit & Loss Statement",
                    subtitle = "Gross profit, expense deduction & net margins",
                    icon = Icons.Default.Savings,
                    color = Color(0xFF059669),
                    onClick = onProfitReportClick
                )
            }

            item {
                ReportNavTile(
                    title = "GST Tax Report (GSTR-1)",
                    subtitle = "Taxable sales, CGST, SGST, IGST breakdown",
                    icon = Icons.Default.Receipt,
                    color = Color(0xFF2563EB),
                    onClick = onGstReportClick
                )
            }

            item {
                ReportNavTile(
                    title = "Expense Management",
                    subtitle = "Track store rent, electricity, salaries & transport",
                    icon = Icons.Default.Paid,
                    color = Color(0xFFD97706),
                    onClick = onExpenseClick
                )
            }
        }
    }
}

@Composable
private fun ReportNavTile(
    title: String,
    subtitle: String,
    icon: ImageVector,
    color: Color,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.5.dp)
    ) {
        Row(
            modifier = Modifier
                .padding(16.dp)
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .background(color.copy(alpha = 0.12f), shape = RoundedCornerShape(12.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(imageVector = icon, contentDescription = null, tint = color, modifier = Modifier.size(26.dp))
            }
            Spacer(modifier = Modifier.width(16.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(text = title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                Text(text = subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Icon(Icons.Default.ChevronRight, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
