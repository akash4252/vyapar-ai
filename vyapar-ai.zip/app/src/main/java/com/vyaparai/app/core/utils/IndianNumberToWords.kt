package com.vyaparai.app.core.utils

import kotlin.math.roundToLong

object IndianNumberToWords {
    private val units = arrayOf(
        "", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten",
        "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eighteen", "Nineteen"
    )

    private val tens = arrayOf(
        "", "", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety"
    )

    fun convert(amount: Double): String {
        val wholePart = amount.toLong()
        val paisePart = ((amount - wholePart) * 100).roundToLong()

        val rupeesWords = if (wholePart == 0L) "Zero" else convertNumber(wholePart)
        val paiseWords = if (paisePart > 0) " and " + convertNumber(paisePart) + " Paise" else ""

        return "Rupees $rupeesWords$paiseWords Only"
    }

    private fun convertNumber(n: Long): String {
        if (n < 0) return "Minus " + convertNumber(-n)
        if (n < 20) return units[n.toInt()]
        if (n < 100) return tens[(n / 10).toInt()] + (if (n % 10 != 0L) " " + units[(n % 10).toInt()] else "")
        if (n < 1000) return units[(n / 100).toInt()] + " Hundred" + (if (n % 100 != 0L) " and " + convertNumber(n % 100) else "")
        if (n < 100000) return convertNumber(n / 1000) + " Thousand" + (if (n % 1000 != 0L) " " + convertNumber(n % 1000) else "")
        if (n < 10000000) return convertNumber(n / 100000) + " Lakh" + (if (n % 100000 != 0L) " " + convertNumber(n % 100000) else "")
        return convertNumber(n / 10000000) + " Crore" + (if (n % 10000000 != 0L) " " + convertNumber(n % 10000000) else "")
    }
}
