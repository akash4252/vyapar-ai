package com.vyaparai.app.core.printer

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.OutputStream
import java.util.UUID

data class PairedPrinterDevice(
    val name: String,
    val address: String,
    val isConnected: Boolean = false
)

object BluetoothPrinterManager {
    // Standard SPP UUID for Bluetooth Serial Printers
    private val SPP_UUID: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")

    private var activeSocket: BluetoothSocket? = null
    private var outputStream: OutputStream? = null

    @SuppressLint("MissingPermission")
    fun getPairedPrinters(context: Context): List<PairedPrinterDevice> {
        return try {
            val adapter = BluetoothAdapter.getDefaultAdapter() ?: return emptyList()
            val bondedDevices = adapter.bondedDevices ?: return emptyList()
            bondedDevices.map { device ->
                PairedPrinterDevice(
                    name = device.name ?: "Unknown Printer",
                    address = device.address
                )
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    @SuppressLint("MissingPermission")
    suspend fun printData(
        deviceAddress: String,
        data: ByteArray
    ): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val adapter = BluetoothAdapter.getDefaultAdapter()
                ?: return@withContext Result.failure(IllegalStateException("Bluetooth adapter not found"))

            val device: BluetoothDevice = adapter.getRemoteDevice(deviceAddress)
            adapter.cancelDiscovery()

            val socket = device.createRfcommSocketToServiceRecord(SPP_UUID)
            socket.connect()
            val stream = socket.outputStream

            stream.write(data)
            stream.flush()

            // Graceful pause and close
            Thread.sleep(500)
            stream.close()
            socket.close()

            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
