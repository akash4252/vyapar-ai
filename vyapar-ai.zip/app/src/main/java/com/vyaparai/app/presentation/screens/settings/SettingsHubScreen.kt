package com.vyaparai.app.presentation.screens.settings

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.vyaparai.app.VyaparAiApplication
import com.vyaparai.app.core.theme.VyaparGreenPrimary
import com.vyaparai.app.presentation.common.ConfirmActionDialog
import com.vyaparai.app.presentation.common.VyaparTopBar
import kotlinx.coroutines.launch

@Composable
fun SettingsHubScreen(
    onPrinterSettingsClick: () -> Unit,
    onAppLockClick: () -> Unit,
    onBackupRestoreClick: () -> Unit,
    onLanguageClick: () -> Unit,
    onBackClick: () -> Unit
) {
    val context = LocalContext.current
    val app = context.applicationContext as VyaparAiApplication
    val scope = rememberCoroutineScope()

    val business by app.container.settingsRepository.getBusiness().collectAsState(initial = null)
    var showDemoResetDialog by remember { mutableStateOf(false) }
    var demoStatusMessage by remember { mutableStateOf<String?>(null) }

    Scaffold(
        topBar = {
            VyaparTopBar(
                title = "Settings & Store",
                subtitle = business?.name ?: "Vyapar AI",
                showBackButton = true,
                onBackClick = onBackClick
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                Text(text = "Hardware & Printers", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            }

            item {
                SettingTile(
                    title = "Thermal Receipt Printer",
                    subtitle = "Configure 58mm / 80mm Bluetooth printer",
                    icon = Icons.Default.Print,
                    onClick = onPrinterSettingsClick
                )
            }

            item {
                Text(text = "Security & Backups", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            }

            item {
                SettingTile(
                    title = "App Lock & PIN",
                    subtitle = "Configure 4-digit PIN and Biometric unlock",
                    icon = Icons.Default.Lock,
                    onClick = onAppLockClick
                )
            }

            item {
                SettingTile(
                    title = "Encrypted Backup & Restore",
                    subtitle = "Hardware-encrypted AES-256 backup",
                    icon = Icons.Default.Backup,
                    onClick = onBackupRestoreClick
                )
            }

            item {
                Text(text = "App & Languages", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            }

            item {
                SettingTile(
                    title = "App Language",
                    subtitle = "English, हिन्दी (Hindi), मराठी (Marathi)",
                    icon = Icons.Default.Language,
                    onClick = onLanguageClick
                )
            }

            item {
                SettingTile(
                    title = "Reset / Reload Demo Data",
                    subtitle = "Load 'Shree Ganesh General Store' demo catalog",
                    icon = Icons.Default.Storefront,
                    onClick = { showDemoResetDialog = true }
                )
            }

            if (demoStatusMessage != null) {
                item {
                    Text(demoStatusMessage!!, color = VyaparGreenPrimary, fontWeight = FontWeight.Bold)
                }
            }
        }

        if (showDemoResetDialog) {
            ConfirmActionDialog(
                title = "Reload Demo Store",
                message = "This will pre-populate sample products (Maggi, Sugar, Milk, etc.) and customers for Shree Ganesh General Store.",
                confirmText = "Load Demo Data",
                onConfirm = {
                    scope.launch {
                        app.container.settingsRepository.loadDemoData()
                        demoStatusMessage = "Demo store loaded successfully!"
                        showDemoResetDialog = false
                    }
                },
                onDismiss = { showDemoResetDialog = false }
            )
        }
    }
}

@Composable
private fun SettingTile(
    title: String,
    subtitle: String,
    icon: ImageVector,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier
                .padding(14.dp)
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .background(VyaparGreenPrimary.copy(alpha = 0.12f), shape = RoundedCornerShape(10.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(imageVector = icon, contentDescription = null, tint = VyaparGreenPrimary, modifier = Modifier.size(22.dp))
            }
            Spacer(modifier = Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(text = title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                Text(text = subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Icon(Icons.Default.ChevronRight, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
