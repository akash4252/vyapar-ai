package com.vyaparai.app.presentation.screens.onboarding

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vyaparai.app.VyaparAiApplication
import com.vyaparai.app.core.theme.VyaparGreenPrimary
import com.vyaparai.app.core.theme.VyaparSecondaryAmber
import com.vyaparai.app.presentation.common.VyaparPrimaryButton
import com.vyaparai.app.presentation.common.VyaparSecondaryButton
import kotlinx.coroutines.launch

@Composable
fun OnboardingWelcomeScreen(
    onGetStartedClick: () -> Unit,
    onDemoLoaded: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val app = context.applicationContext as VyaparAiApplication

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Spacer(modifier = Modifier.height(32.dp))

            Text(
                text = "VYAPAR AI",
                style = MaterialTheme.typography.headlineLarge,
                fontWeight = FontWeight.ExtraBold,
                color = VyaparGreenPrimary
            )

            Text(
                text = "Bola. Scan Kiya. Bill Taiyar.",
                style = MaterialTheme.typography.titleMedium,
                color = VyaparSecondaryAmber,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(32.dp))

            FeatureBullet(
                icon = Icons.Default.Mic,
                title = "Voice Billing",
                description = "Speak products in Hindi, Marathi, or English. Instant bill generation."
            )
            Spacer(modifier = Modifier.height(16.dp))

            FeatureBullet(
                icon = Icons.Default.QrCodeScanner,
                title = "Fast Barcode Scanning",
                description = "Scan any product barcode with Camera. Zero typing needed."
            )
            Spacer(modifier = Modifier.height(16.dp))

            FeatureBullet(
                icon = Icons.Default.Book,
                title = "Digital Khata & WhatsApp Reminders",
                description = "Track customer credits and send one-tap WhatsApp payment reminders."
            )
            Spacer(modifier = Modifier.height(16.dp))

            FeatureBullet(
                icon = Icons.Default.WifiOff,
                title = "100% Offline-First",
                description = "Create bills anytime without internet. Complete local security."
            )
        }

        Column(modifier = Modifier.fillMaxWidth()) {
            VyaparPrimaryButton(
                text = "GET STARTED",
                onClick = onGetStartedClick,
                icon = Icons.Default.ArrowForward
            )

            Spacer(modifier = Modifier.height(12.dp))

            VyaparSecondaryButton(
                text = "TRY DEMO STORE",
                onClick = {
                    scope.launch {
                        app.container.settingsRepository.loadDemoData()
                        onDemoLoaded()
                    }
                },
                icon = Icons.Default.Storefront
            )

            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

@Composable
private fun FeatureBullet(
    icon: ImageVector,
    title: String,
    description: String
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surface, shape = RoundedCornerShape(14.dp))
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(44.dp)
                .background(VyaparGreenPrimary.copy(alpha = 0.12f), shape = RoundedCornerShape(10.dp)),
            contentAlignment = Alignment.Center
        ) {
            Icon(imageVector = icon, contentDescription = null, tint = VyaparGreenPrimary, modifier = Modifier.size(24.dp))
        }
        Spacer(modifier = Modifier.width(16.dp))
        Column {
            Text(text = title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
            Text(text = description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
