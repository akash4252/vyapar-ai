package com.vyaparai.app.core.printer

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import com.vyaparai.app.core.utils.CurrencyFormatter
import com.vyaparai.app.core.utils.DateUtils
import com.vyaparai.app.core.utils.IndianNumberToWords
import com.vyaparai.app.core.utils.UpiQrGenerator
import java.io.File
import java.io.FileOutputStream

data class PdfInvoiceData(
    val businessName: String,
    val businessAddress: String?,
    val businessMobile: String?,
    val businessGstin: String?,
    val businessUpiId: String?,
    val invoiceNumber: String,
    val invoiceDate: Long,
    val customerName: String?,
    val customerMobile: String?,
    val customerGstin: String?,
    val items: List<PdfInvoiceItem>,
    val subtotal: Double,
    val discount: Double,
    val cgst: Double,
    val sgst: Double,
    val igst: Double,
    val grandTotal: Double,
    val paymentMethod: String
)

data class PdfInvoiceItem(
    val name: String,
    val hsn: String?,
    val quantity: Double,
    val unit: String,
    val rate: Double,
    val discount: Double,
    val gstRate: Double,
    val total: Double
)

object InvoicePdfGenerator {

    fun generateA4Invoice(context: Context, data: PdfInvoiceData): File {
        val pageNumber = 1
        val pageWidth = 595 // A4 standard width in points (72 dpi)
        val pageHeight = 842 // A4 standard height

        val pdfDocument = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create()
        val page = pdfDocument.startPage(pageInfo)
        val canvas: Canvas = page.canvas

        val paint = Paint().apply { isAntiAlias = true }
        val margin = 36f

        // Border
        paint.color = Color.parseColor("#0F763E")
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 2f
        canvas.drawRect(margin, margin, pageWidth - margin, pageHeight - margin, paint)
        paint.style = Paint.Style.FILL

        // Header Background
        paint.color = Color.parseColor("#E8F5E9")
        canvas.drawRect(margin + 2, margin + 2, pageWidth - margin - 2, margin + 80, paint)

        // Store Title
        paint.color = Color.parseColor("#063B1D")
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        paint.textSize = 18f
        canvas.drawText(data.businessName, margin + 16, margin + 30, paint)

        paint.typeface = Typeface.DEFAULT
        paint.textSize = 9f
        paint.color = Color.parseColor("#334155")
        var headerY = margin + 45
        data.businessAddress?.let {
            canvas.drawText(it, margin + 16, headerY, paint)
            headerY += 12
        }
        val contactLine = listOfNotNull(
            data.businessMobile?.let { "Phone: $it" },
            data.businessGstin?.let { "GSTIN: $it" }
        ).joinToString(" | ")
        if (contactLine.isNotBlank()) {
            canvas.drawText(contactLine, margin + 16, headerY, paint)
        }

        // Invoice Badge
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        paint.textSize = 14f
        paint.color = Color.parseColor("#0F763E")
        val badgeText = "TAX INVOICE"
        val badgeWidth = paint.measureText(badgeText)
        canvas.drawText(badgeText, pageWidth - margin - 16 - badgeWidth, margin + 30, paint)

        paint.typeface = Typeface.DEFAULT
        paint.textSize = 9f
        paint.color = Color.parseColor("#1E293B")
        canvas.drawText("Invoice No: ${data.invoiceNumber}", pageWidth - margin - 140, margin + 48, paint)
        canvas.drawText("Date: ${DateUtils.formatInvoiceDate(data.invoiceDate)}", pageWidth - margin - 140, margin + 62, paint)

        // Divider
        var currentY = margin + 95
        paint.color = Color.parseColor("#CBD5E1")
        paint.strokeWidth = 1f
        canvas.drawLine(margin, currentY, pageWidth - margin, currentY, paint)

        // Bill To Section
        currentY += 15
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        paint.textSize = 10f
        paint.color = Color.parseColor("#0F172A")
        canvas.drawText("Billed To:", margin + 16, currentY, paint)

        paint.typeface = Typeface.DEFAULT
        paint.textSize = 9f
        currentY += 14
        canvas.drawText(data.customerName ?: "Cash Customer", margin + 16, currentY, paint)
        data.customerMobile?.let {
            currentY += 12
            canvas.drawText("Mobile: $it", margin + 16, currentY, paint)
        }
        data.customerGstin?.let {
            currentY += 12
            canvas.drawText("GSTIN: $it", margin + 16, currentY, paint)
        }

        // Table Header
        currentY += 20
        paint.color = Color.parseColor("#0F763E")
        canvas.drawRect(margin, currentY, pageWidth - margin, currentY + 22, paint)

        paint.color = Color.WHITE
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        paint.textSize = 9f
        val headerBaseline = currentY + 15
        canvas.drawText("#", margin + 8, headerBaseline, paint)
        canvas.drawText("Item Description", margin + 30, headerBaseline, paint)
        canvas.drawText("HSN", margin + 220, headerBaseline, paint)
        canvas.drawText("Qty", margin + 270, headerBaseline, paint)
        canvas.drawText("Rate", margin + 320, headerBaseline, paint)
        canvas.drawText("GST %", margin + 380, headerBaseline, paint)
        canvas.drawText("Total", pageWidth - margin - 50, headerBaseline, paint)

        // Table Rows
        currentY += 22
        paint.typeface = Typeface.DEFAULT
        paint.textSize = 9f
        paint.color = Color.parseColor("#0F172A")

        var index = 1
        for (item in data.items) {
            val rowY = currentY + 16
            // Zebra striping
            if (index % 2 == 0) {
                paint.color = Color.parseColor("#F8FAFC")
                canvas.drawRect(margin, currentY, pageWidth - margin, currentY + 22, paint)
            }

            paint.color = Color.parseColor("#0F172A")
            canvas.drawText("$index", margin + 8, rowY, paint)
            canvas.drawText(item.name.take(28), margin + 30, rowY, paint)
            canvas.drawText(item.hsn ?: "-", margin + 220, rowY, paint)
            canvas.drawText("${item.quantity} ${item.unit}", margin + 270, rowY, paint)
            canvas.drawText("₹${item.rate.toInt()}", margin + 320, rowY, paint)
            canvas.drawText("${item.gstRate.toInt()}%", margin + 380, rowY, paint)
            canvas.drawText("₹${item.total.toInt()}", pageWidth - margin - 50, rowY, paint)

            currentY += 22
            index++
        }

        // Totals Section Line
        paint.color = Color.parseColor("#CBD5E1")
        canvas.drawLine(margin, currentY, pageWidth - margin, currentY, paint)

        // Summary Box
        currentY += 15
        val summaryX = pageWidth - margin - 180
        paint.textSize = 9f
        paint.color = Color.parseColor("#334155")
        canvas.drawText("Subtotal:", summaryX, currentY, paint)
        canvas.drawText("₹%.2f".format(data.subtotal), pageWidth - margin - 20, currentY, paint)

        if (data.discount > 0) {
            currentY += 14
            canvas.drawText("Discount:", summaryX, currentY, paint)
            canvas.drawText("-₹%.2f".format(data.discount), pageWidth - margin - 20, currentY, paint)
        }
        if (data.cgst > 0) {
            currentY += 14
            canvas.drawText("CGST:", summaryX, currentY, paint)
            canvas.drawText("₹%.2f".format(data.cgst), pageWidth - margin - 20, currentY, paint)
        }
        if (data.sgst > 0) {
            currentY += 14
            canvas.drawText("SGST:", summaryX, currentY, paint)
            canvas.drawText("₹%.2f".format(data.sgst), pageWidth - margin - 20, currentY, paint)
        }

        currentY += 18
        paint.color = Color.parseColor("#0F763E")
        canvas.drawRect(summaryX - 5, currentY - 12, pageWidth - margin - 2, currentY + 14, paint)
        paint.color = Color.WHITE
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        paint.textSize = 11f
        canvas.drawText("GRAND TOTAL:", summaryX, currentY + 6, paint)
        canvas.drawText(CurrencyFormatter.format(data.grandTotal), pageWidth - margin - 60, currentY + 6, paint)

        // Amount in Words
        val wordsY = pageHeight - margin - 120
        paint.color = Color.parseColor("#0F172A")
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        paint.textSize = 9f
        canvas.drawText("Amount in Words:", margin + 16, wordsY, paint)
        paint.typeface = Typeface.DEFAULT
        canvas.drawText(IndianNumberToWords.convert(data.grandTotal), margin + 16, wordsY + 14, paint)

        // UPI QR Code on Invoice
        if (!data.businessUpiId.isNullOrBlank()) {
            val upiPayload = UpiQrGenerator.createUpiUri(
                upiId = data.businessUpiId,
                payeeName = data.businessName,
                amount = data.grandTotal,
                invoiceNumber = data.invoiceNumber
            )
            val qrBitmap = UpiQrGenerator.generateQrBitmap(upiPayload, 80)
            if (qrBitmap != null) {
                canvas.drawBitmap(qrBitmap, margin + 16, wordsY + 30, null)
                paint.textSize = 8f
                paint.color = Color.parseColor("#64748B")
                canvas.drawText("Scan to Pay via UPI", margin + 105, wordsY + 65, paint)
            }
        }

        // Footer & Signatory
        paint.color = Color.parseColor("#0F172A")
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        paint.textSize = 9f
        canvas.drawText("For ${data.businessName}", pageWidth - margin - 160, pageHeight - margin - 40, paint)
        paint.typeface = Typeface.DEFAULT
        paint.textSize = 8f
        canvas.drawText("Authorized Signatory", pageWidth - margin - 160, pageHeight - margin - 15, paint)

        pdfDocument.finishPage(page)

        // Save PDF to Internal Directory
        val dir = File(context.getExternalFilesDir(null), "invoices")
        if (!dir.exists()) dir.mkdirs()
        val file = File(dir, "${data.invoiceNumber}.pdf")
        val out = FileOutputStream(file)
        pdfDocument.writeTo(out)
        out.close()
        pdfDocument.close()

        return file
    }
}
