package com.vyaparai.app.domain.usecases

import androidx.room.withTransaction
import com.vyaparai.app.core.database.AppDatabase
import com.vyaparai.app.core.database.entities.*

data class CartItem(
    val product: ProductEntity,
    val quantity: Double,
    val unitPrice: Double = product.sellingPrice,
    val discount: Double = 0.0,
    val gstRate: Double = product.gstRate,
    val isTaxInclusive: Boolean = product.isTaxInclusive
)

data class BillingCheckoutRequest(
    val cartItems: List<CartItem>,
    val customer: CustomerEntity? = null,
    val paymentMethod: String = "CASH", // CASH, UPI, CARD, CREDIT, SPLIT
    val amountPaid: Double,
    val cashGiven: Double = 0.0,
    val splitDetailsJson: String? = null,
    val notes: String? = null
)

class AtomicBillingUseCase(private val database: AppDatabase) {

    suspend fun execute(request: BillingCheckoutRequest): InvoiceEntity {
        require(request.cartItems.isNotEmpty()) { "Cannot create invoice with empty cart" }

        return database.withTransaction {
            val settingsDao = database.settingsBusinessDao()
            val invoiceDao = database.invoiceDao()
            val productDao = database.productDao()
            val customerDao = database.customerKhataDao()

            // 1. Fetch & increment invoice sequence
            val invoiceSettings = settingsDao.getInvoiceSettings() ?: InvoiceSettingsEntity()
            val sequenceNum = invoiceSettings.nextInvoiceNumber
            val prefix = invoiceSettings.prefix
            val invoiceNumber = "%s%06d".format(prefix, sequenceNum)
            settingsDao.incrementInvoiceSequence()

            // 2. Compute Item-level GST & Subtotals
            var subtotal = 0.0
            var totalDiscount = 0.0
            var totalCgst = 0.0
            var totalSgst = 0.0
            var totalIgst = 0.0
            var totalCess = 0.0
            var grandTotal = 0.0

            val invoiceItems = mutableListOf<InvoiceItemEntity>()

            for (cartItem in request.cartItems) {
                val taxResult = GstCalculationUseCase.calculateItemTax(
                    unitPrice = cartItem.unitPrice,
                    quantity = cartItem.quantity,
                    discount = cartItem.discount,
                    gstRate = cartItem.gstRate,
                    cessRate = cartItem.product.cessRate,
                    isTaxInclusive = cartItem.isTaxInclusive
                )

                subtotal += (cartItem.unitPrice * cartItem.quantity)
                totalDiscount += cartItem.discount
                totalCgst += taxResult.cgstAmount
                totalSgst += taxResult.sgstAmount
                totalIgst += taxResult.igstAmount
                totalCess += taxResult.cessAmount
                grandTotal += taxResult.finalTotal

                invoiceItems.add(
                    InvoiceItemEntity(
                        invoiceId = 0, // Will be set after invoice insert
                        productId = cartItem.product.id,
                        productName = cartItem.product.name,
                        barcode = cartItem.product.barcode,
                        hsnCode = cartItem.product.sku,
                        quantity = cartItem.quantity,
                        unit = cartItem.product.unit,
                        unitPrice = cartItem.unitPrice,
                        purchasePrice = cartItem.product.purchasePrice,
                        discountAmount = cartItem.discount,
                        gstRate = cartItem.gstRate,
                        isTaxInclusive = cartItem.isTaxInclusive,
                        taxableAmount = taxResult.taxableAmount,
                        cgstAmount = taxResult.cgstAmount,
                        sgstAmount = taxResult.sgstAmount,
                        igstAmount = taxResult.igstAmount,
                        cessAmount = taxResult.cessAmount,
                        totalAmount = taxResult.finalTotal
                    )
                )
            }

            val totalGst = totalCgst + totalSgst + totalIgst + totalCess
            val creditAmount = (grandTotal - request.amountPaid).coerceAtLeast(0.0)
            val paymentStatus = when {
                creditAmount <= 0.001 -> "PAID"
                request.amountPaid > 0.0 -> "PARTIAL"
                else -> "UNPAID"
            }

            // 3. Create Invoice Entity
            val invoice = InvoiceEntity(
                invoiceNumber = invoiceNumber,
                customerId = request.customer?.id,
                customerName = request.customer?.name,
                customerMobile = request.customer?.mobile,
                subtotal = subtotal,
                totalDiscount = totalDiscount,
                totalGst = totalGst,
                cgst = totalCgst,
                sgst = totalSgst,
                igst = totalIgst,
                cess = totalCess,
                grandTotal = grandTotal,
                amountPaid = request.amountPaid,
                creditAmount = creditAmount,
                paymentStatus = paymentStatus,
                paymentMethod = request.paymentMethod,
                splitDetailsJson = request.splitDetailsJson,
                notes = request.notes
            )

            val invoiceId = invoiceDao.insertInvoice(invoice)

            // 4. Attach invoiceId & Insert items
            val finalizedItems = invoiceItems.map { it.copy(invoiceId = invoiceId) }
            invoiceDao.insertInvoiceItems(finalizedItems)

            // 5. Update Inventory & Record Stock Transactions
            for (item in finalizedItems) {
                val currentProduct = productDao.getProductById(item.productId)
                val beforeStock = currentProduct?.currentStock ?: 0.0
                val afterStock = beforeStock - item.quantity

                productDao.adjustProductStock(item.productId, -item.quantity)

                productDao.insertInventoryTransaction(
                    InventoryTransactionEntity(
                        productId = item.productId,
                        transactionType = "SALE",
                        quantity = -item.quantity,
                        stockBefore = beforeStock,
                        stockAfter = afterStock,
                        referenceType = "INVOICE",
                        referenceId = invoiceId,
                        notes = "Sold in Invoice $invoiceNumber"
                    )
                )
            }

            // 6. Record Payment
            if (request.amountPaid > 0.0) {
                invoiceDao.insertPayment(
                    PaymentEntity(
                        referenceType = "INVOICE",
                        referenceId = invoiceId,
                        amount = request.amountPaid,
                        paymentMethod = request.paymentMethod,
                        notes = "Payment for $invoiceNumber"
                    )
                )
            }

            // 7. Update Customer & Khata if Credit/Udhaar exists
            if (creditAmount > 0.0 && request.customer != null) {
                val customerId = request.customer.id
                val updatedBalance = request.customer.currentCreditBalance + creditAmount

                customerDao.updateCustomerBalance(customerId, creditAmount, spentDelta = grandTotal)

                customerDao.insertCustomerTransaction(
                    CustomerTransactionEntity(
                        customerId = customerId,
                        invoiceId = invoiceId,
                        transactionType = "SALE_CREDIT",
                        amount = creditAmount,
                        balanceAfter = updatedBalance,
                        paymentMethod = "CREDIT",
                        notes = "Credit purchase under $invoiceNumber"
                    )
                )
            } else if (request.customer != null) {
                customerDao.updateCustomerBalance(request.customer.id, 0.0, spentDelta = grandTotal)
            }

            // 8. Loyalty Calculation (1 point per ₹100 spent)
            if (request.customer != null) {
                val pointsEarned = (grandTotal / 100.0).toInt()
                if (pointsEarned > 0) {
                    val existingAccount = customerDao.getLoyaltyAccount(request.customer.id)
                        ?: LoyaltyAccountEntity(customerId = request.customer.id)

                    val updatedAccount = existingAccount.copy(
                        totalPointsEarned = existingAccount.totalPointsEarned + pointsEarned,
                        currentBalancePoints = existingAccount.currentBalancePoints + pointsEarned,
                        lastUpdated = System.currentTimeMillis()
                    )
                    customerDao.insertOrUpdateLoyaltyAccount(updatedAccount)

                    customerDao.insertLoyaltyTransaction(
                        LoyaltyTransactionEntity(
                            customerId = request.customer.id,
                            invoiceId = invoiceId,
                            type = "EARN",
                            points = pointsEarned,
                            equivalentValue = pointsEarned * 0.5
                        )
                    )
                }
            }

            // 9. Record Audit Log & Sync
            settingsDao.insertAuditLog(
                AuditLogEntity(
                    action = "CREATE_INVOICE",
                    entityType = "INVOICE",
                    entityId = invoiceId,
                    details = "Created bill $invoiceNumber for ₹$grandTotal"
                )
            )

            settingsDao.enqueueSync(
                SyncQueueEntity(
                    entityType = "INVOICE",
                    entityId = invoiceId,
                    operation = "CREATE",
                    payloadJson = """{"invoiceNumber":"$invoiceNumber","total":$grandTotal}"""
                )
            )

            invoice.copy(id = invoiceId)
        }
    }
}
