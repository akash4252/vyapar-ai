package com.vyaparai.app.core.database.daos

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import com.vyaparai.app.core.database.entities.ExpenseEntity
import com.vyaparai.app.core.database.entities.PurchaseEntity
import com.vyaparai.app.core.database.entities.PurchaseItemEntity
import com.vyaparai.app.core.database.entities.PurchaseOrderEntity
import com.vyaparai.app.core.database.entities.PurchaseOrderItemEntity
import com.vyaparai.app.core.database.entities.PurchaseReturnEntity
import com.vyaparai.app.core.database.entities.PurchaseReturnItemEntity
import com.vyaparai.app.core.database.entities.SupplierEntity
import com.vyaparai.app.core.database.entities.SupplierTransactionEntity
import kotlinx.coroutines.flow.Flow

data class PurchaseWithItems(
    @androidx.room.Embedded val purchase: PurchaseEntity,
    @androidx.room.Relation(
        parentColumn = "id",
        entityColumn = "purchaseId"
    )
    val items: List<PurchaseItemEntity>
)

data class PurchaseOrderWithItems(
    @androidx.room.Embedded val order: PurchaseOrderEntity,
    @androidx.room.Relation(
        parentColumn = "id",
        entityColumn = "purchaseOrderId"
    )
    val items: List<PurchaseOrderItemEntity>
)

@Dao
interface SupplierPurchaseDao {
    @Query("SELECT * FROM suppliers ORDER BY name ASC")
    fun getAllSuppliersFlow(): Flow<List<SupplierEntity>>

    @Query("SELECT * FROM suppliers ORDER BY name ASC")
    suspend fun getAllSuppliers(): List<SupplierEntity>

    @Query("SELECT * FROM suppliers WHERE id = :id")
    suspend fun getSupplierById(id: Long): SupplierEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSupplier(supplier: SupplierEntity): Long

    @Update
    suspend fun updateSupplier(supplier: SupplierEntity)

    @Query("UPDATE suppliers SET currentOutstanding = currentOutstanding + :delta WHERE id = :supplierId")
    suspend fun updateSupplierOutstanding(supplierId: Long, delta: Double)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSupplierTransaction(tx: SupplierTransactionEntity): Long

    @Query("SELECT * FROM supplier_transactions WHERE supplierId = :supplierId ORDER BY date DESC")
    fun getSupplierTransactionsFlow(supplierId: Long): Flow<List<SupplierTransactionEntity>>

    // Purchases
    @Transaction
    @Query("SELECT * FROM purchases ORDER BY createdAt DESC")
    fun getAllPurchasesWithItemsFlow(): Flow<List<PurchaseWithItems>>

    @Transaction
    @Query("SELECT * FROM purchases WHERE id = :id")
    suspend fun getPurchaseWithItemsById(id: Long): PurchaseWithItems?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPurchase(purchase: PurchaseEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPurchaseItems(items: List<PurchaseItemEntity>)

    // Purchase Orders
    @Transaction
    @Query("SELECT * FROM purchase_orders ORDER BY orderDate DESC")
    fun getAllPurchaseOrdersWithItemsFlow(): Flow<List<PurchaseOrderWithItems>>

    @Transaction
    @Query("SELECT * FROM purchase_orders WHERE id = :id")
    suspend fun getPurchaseOrderWithItemsById(id: Long): PurchaseOrderWithItems?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPurchaseOrder(order: PurchaseOrderEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPurchaseOrderItems(items: List<PurchaseOrderItemEntity>)

    @Update
    suspend fun updatePurchaseOrder(order: PurchaseOrderEntity)

    // Purchase Returns
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPurchaseReturn(returnEntity: PurchaseReturnEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPurchaseReturnItems(items: List<PurchaseReturnItemEntity>)

    // Expenses
    @Query("SELECT * FROM expenses ORDER BY date DESC")
    fun getAllExpensesFlow(): Flow<List<ExpenseEntity>>

    @Query("SELECT SUM(amount) FROM expenses WHERE date BETWEEN :startTime AND :endTime")
    fun getExpensesSumBetweenDatesFlow(startTime: Long, endTime: Long): Flow<Double?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertExpense(expense: ExpenseEntity): Long
}
