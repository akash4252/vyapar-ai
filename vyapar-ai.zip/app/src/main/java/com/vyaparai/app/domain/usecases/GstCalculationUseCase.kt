package com.vyaparai.app.domain.usecases

data class GstCalculationResult(
    val taxableAmount: Double,
    val cgstAmount: Double,
    val sgstAmount: Double,
    val igstAmount: Double,
    val cessAmount: Double,
    val totalGst: Double,
    val finalTotal: Double
)

object GstCalculationUseCase {

    fun calculateItemTax(
        unitPrice: Double,
        quantity: Double,
        discount: Double = 0.0,
        gstRate: Double = 0.0, // e.g. 18.0 for 18%
        cessRate: Double = 0.0,
        isTaxInclusive: Boolean = true,
        isInterState: Boolean = false
    ): GstCalculationResult {
        val grossPrice = (unitPrice * quantity) - discount

        if (gstRate <= 0.0 && cessRate <= 0.0) {
            return GstCalculationResult(
                taxableAmount = grossPrice,
                cgstAmount = 0.0,
                sgstAmount = 0.0,
                igstAmount = 0.0,
                cessAmount = 0.0,
                totalGst = 0.0,
                finalTotal = grossPrice
            )
        }

        val totalTaxRatePercentage = (gstRate + cessRate) / 100.0

        val taxableAmount: Double
        val totalTax: Double
        val finalTotal: Double

        if (isTaxInclusive) {
            // Price includes GST: Taxable = Gross / (1 + (Rate / 100))
            taxableAmount = grossPrice / (1.0 + totalTaxRatePercentage)
            totalTax = grossPrice - taxableAmount
            finalTotal = grossPrice
        } else {
            // Price excludes GST: Taxable = Gross, Total = Gross + Tax
            taxableAmount = grossPrice
            totalTax = grossPrice * totalTaxRatePercentage
            finalTotal = grossPrice + totalTax
        }

        val gstFraction = if (totalTaxRatePercentage > 0) gstRate / (gstRate + cessRate) else 0.0
        val actualGstAmount = totalTax * gstFraction
        val cessAmount = totalTax - actualGstAmount

        val cgst: Double
        val sgst: Double
        val igst: Double

        if (isInterState) {
            igst = actualGstAmount
            cgst = 0.0
            sgst = 0.0
        } else {
            cgst = actualGstAmount / 2.0
            sgst = actualGstAmount / 2.0
            igst = 0.0
        }

        return GstCalculationResult(
            taxableAmount = taxableAmount,
            cgstAmount = cgst,
            sgstAmount = sgst,
            igstAmount = igst,
            cessAmount = cessAmount,
            totalGst = totalTax,
            finalTotal = finalTotal
        )
    }
}
