package com.vyaparai.app.presentation.screens.purchases

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vyaparai.app.VyaparAiApplication
import com.vyaparai.app.core.theme.VyaparGreenPrimary
import com.vyaparai.app.core.theme.VyaparSecondaryAmber
import com.vyaparai.app.core.utils.CurrencyFormatter
import com.vyaparai.app.domain.usecases.SmartPoUseCase
import com.vyaparai.app.domain.usecases.SmartPurchaseSuggestion
import com.vyaparai.app.presentation.common.VyaparPrimaryButton
import com.vyaparai.app.presentation.common.VyaparTopBar

@Composable
fun SmartPurchaseOrderScreen(
    onBackClick: () -> Unit
) {
    val context = LocalContext.current
    val app = context.applicationContext as VyaparAiApplication

    val lowStockList by app.container.productRepository.getLowStockProducts().collectAsState(initial = emptyList())
    val business by app.container.settingsRepository.getBusiness().collectAsState(initial = null)

    val suggestions = remember(lowStockList) {
        SmartPoUseCase.generateSuggestions(lowStockList)
    }

    val totalEstimatedCost = suggestions.sumOf { it.estimatedCost }

    fun sharePoViaWhatsApp() {
        val bizName = business?.name ?: "Our Store"
        val sb = StringBuilder()
        sb.append("*PURCHASE ORDER — $bizName*\n")
        sb.append("Please deliver the following replenishment items:\n\n")

        suggestions.forEachIndexed { idx, s ->
            sb.append("${idx + 1}. *${s.product.name}* — ${s.suggestedQuantity.toInt()} ${s.product.unit}\n")
        }
        sb.append("\n*Estimated Total:* ${CurrencyFormatter.format(totalEstimatedCost)}\n")
        sb.append("Thank you!")

        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://api.whatsapp.com/send?text=" + Uri.encode(sb.toString())))
        try {
            context.startActivity(intent)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    Scaffold(
        topBar = {
            VyaparTopBar(
                title = "Smart Purchase Order",
                subtitle = "AI Replenishment Engine",
                showBackButton = true,
                onBackClick = onBackClick
            )
        },
        bottomBar = {
            if (suggestions.isNotEmpty()) {
                Surface(color = MaterialTheme.colorScheme.surface, shadowElevation = 6.dp) {
                    Box(modifier = Modifier.fillMaxWidth().padding(16.dp)) {
                        VyaparPrimaryButton(
                            text = "SHARE PO VIA WHATSAPP (${CurrencyFormatter.format(totalEstimatedCost)})",
                            onClick = { sharePoViaWhatsApp() },
                            icon = Icons.Default.Share
                        )
                    }
                }
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
        ) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = VyaparSecondaryAmber.copy(alpha = 0.12f))
            ) {
                Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = VyaparSecondaryAmber, modifier = Modifier.size(32.dp))
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text("AI Replenishment Analysis", fontWeight = FontWeight.Bold, color = Color(0xFF78350F))
                        Text(
                            text = "Calculated using target maximum stock levels and stock deficits.",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFF92400E)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            if (suggestions.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("All product stocks are sufficient! No replenishment needed.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            } else {
                Text(text = "Suggested Reorder Items (${suggestions.size})", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(8.dp))

                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(suggestions) { item ->
                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .padding(14.dp)
                                    .fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(text = item.product.name, fontWeight = FontWeight.Bold)
                                    Text(
                                        text = "In Stock: ${item.currentStock.toInt()} ${item.product.unit} | Min: ${item.product.minimumStock.toInt()}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Text(
                                        text = item.reason,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.error
                                    )
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    Text(
                                        text = "Order: +${item.suggestedQuantity.toInt()} ${item.product.unit}",
                                        fontWeight = FontWeight.ExtraBold,
                                        color = VyaparGreenPrimary,
                                        fontSize = 15.sp
                                    )
                                    Text(
                                        text = CurrencyFormatter.format(item.estimatedCost),
                                        style = MaterialTheme.typography.bodySmall,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
