package com.vyaparai.app.presentation.screens.onboarding

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.vyaparai.app.VyaparAiApplication
import com.vyaparai.app.core.theme.VyaparGreenContainer
import com.vyaparai.app.core.theme.VyaparGreenOnContainer
import com.vyaparai.app.presentation.common.VyaparPrimaryButton
import com.vyaparai.app.presentation.common.VyaparTopBar
import kotlinx.coroutines.launch

@Composable
fun BackupSetupScreen(
    onFinishSetup: () -> Unit,
    onBackClick: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val app = context.applicationContext as VyaparAiApplication

    var enableAutoBackup by remember { mutableStateOf(true) }

    Scaffold(
        topBar = {
            VyaparTopBar(
                title = "Backup & Recovery",
                subtitle = "Step 5 of 5",
                showBackButton = true,
                onBackClick = onBackClick
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(20.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text(
                    text = "Automated Encrypted Backups",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Your store's products, bills, and Khata records are encrypted with AES-256 and backed up safely.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(24.dp))

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(VyaparGreenContainer, shape = RoundedCornerShape(16.dp))
                        .padding(16.dp)
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Security, contentDescription = null, tint = VyaparGreenOnContainer)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Hardware-Backed Security", fontWeight = FontWeight.Bold, color = VyaparGreenOnContainer)
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Backups are encrypted using Android Keystore keys that never leave your device.",
                            style = MaterialTheme.typography.bodySmall,
                            color = VyaparGreenOnContainer.copy(alpha = 0.9f)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text("Automatic Daily Backup", fontWeight = FontWeight.SemiBold)
                        Text("Creates a secure snapshot every night", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Switch(checked = enableAutoBackup, onCheckedChange = { enableAutoBackup = it })
                }
            }

            VyaparPrimaryButton(
                text = "FINISH SETUP & OPEN STORE",
                onClick = {
                    scope.launch {
                        app.container.backupRepository.createEncryptedBackup(context)
                        onFinishSetup()
                    }
                },
                icon = Icons.Default.Check
            )
        }
    }
}
