package com.vyaparai.app.presentation.screens.security

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Backspace
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.fragment.app.FragmentActivity
import com.vyaparai.app.VyaparAiApplication
import com.vyaparai.app.core.security.BiometricAuthManager
import com.vyaparai.app.core.security.PinSecurityManager
import com.vyaparai.app.core.theme.VyaparGreenPrimary
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun AppLockSecurityScreen(
    onUnlockSuccess: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val app = context.applicationContext as VyaparAiApplication

    var pinInput by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var storedPinHash by remember { mutableStateOf<String?>(null) }
    var isBiometricEnabled by remember { mutableStateOf(false) }
    var lockoutSeconds by remember { mutableIntStateOf(0) }

    LaunchedEffect(Unit) {
        val settings = app.container.database.settingsBusinessDao().getAppSettings()
        storedPinHash = settings?.pinHash
        isBiometricEnabled = settings?.isBiometricEnabled ?: false

        if (isBiometricEnabled && context is FragmentActivity && BiometricAuthManager.isBiometricAvailable(context)) {
            BiometricAuthManager.showBiometricPrompt(
                activity = context,
                onSuccess = onUnlockSuccess,
                onError = { /* fallback to PIN */ }
            )
        }
    }

    LaunchedEffect(lockoutSeconds) {
        if (lockoutSeconds > 0) {
            delay(1000)
            lockoutSeconds--
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(top = 48.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(64.dp)
                    .clip(CircleShape)
                    .background(VyaparGreenPrimary.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Lock,
                    contentDescription = null,
                    tint = VyaparGreenPrimary,
                    modifier = Modifier.size(32.dp)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "Enter Security PIN",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(24.dp))

            // PIN Dots
            Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                for (i in 0 until 4) {
                    val isFilled = i < pinInput.length
                    Box(
                        modifier = Modifier
                            .size(16.dp)
                            .clip(CircleShape)
                            .background(if (isFilled) VyaparGreenPrimary else MaterialTheme.colorScheme.outline)
                    )
                }
            }

            if (errorMessage != null) {
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = errorMessage!!,
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }

        // Numeric Keypad
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            val rows = listOf(
                listOf("1", "2", "3"),
                listOf("4", "5", "6"),
                listOf("7", "8", "9"),
                listOf("BIO", "0", "DEL")
            )

            for (row in rows) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    for (digit in row) {
                        KeypadButton(
                            text = digit,
                            enabled = lockoutSeconds == 0,
                            onClick = {
                                when (digit) {
                                    "DEL" -> if (pinInput.isNotEmpty()) pinInput = pinInput.dropLast(1)
                                    "BIO" -> {
                                        if (isBiometricEnabled && context is FragmentActivity) {
                                            BiometricAuthManager.showBiometricPrompt(
                                                activity = context,
                                                onSuccess = onUnlockSuccess,
                                                onError = { msg -> errorMessage = msg }
                                            )
                                        }
                                    }
                                    else -> {
                                        if (pinInput.length < 4) {
                                            pinInput += digit
                                            if (pinInput.length == 4) {
                                                if (storedPinHash == null || PinSecurityManager.verifyPin(pinInput, storedPinHash!!)) {
                                                    onUnlockSuccess()
                                                } else {
                                                    if (PinSecurityManager.isLockedOut()) {
                                                        lockoutSeconds = PinSecurityManager.getRemainingLockoutSeconds()
                                                        errorMessage = "Too many failed attempts. Locked for $lockoutSeconds s"
                                                    } else {
                                                        errorMessage = "Incorrect PIN. Try again."
                                                    }
                                                    pinInput = ""
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun KeypadButton(
    text: String,
    enabled: Boolean,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .size(72.dp)
            .clip(CircleShape)
            .background(if (text.isNotBlank()) MaterialTheme.colorScheme.surfaceVariant else Color.Transparent)
            .clickable(enabled = enabled) { onClick() },
        contentAlignment = Alignment.Center
    ) {
        if (text == "DEL") {
            Icon(Icons.AutoMirrored.Filled.Backspace, contentDescription = "Delete")
        } else if (text == "BIO") {
            Icon(Icons.Default.Fingerprint, contentDescription = "Biometric", tint = VyaparGreenPrimary)
        } else {
            Text(text = text, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        }
    }
}
