package com.vyaparai.app.data.repositories

import com.vyaparai.app.core.database.AppDatabase
import com.vyaparai.app.core.database.entities.AppSettingsEntity
import com.vyaparai.app.core.database.entities.BusinessEntity
import com.vyaparai.app.core.database.entities.InvoiceSettingsEntity
import com.vyaparai.app.data.demo.DemoDataPopulator
import com.vyaparai.app.domain.repositories.SettingsRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

class SettingsRepositoryImpl(
    private val database: AppDatabase
) : SettingsRepository {

    private val dao = database.settingsBusinessDao()

    override fun getBusiness(): Flow<BusinessEntity?> = dao.getBusinessFlow()

    override suspend fun getBusinessOnce(): BusinessEntity? = withContext(Dispatchers.IO) {
        dao.getBusiness()
    }

    override suspend fun saveBusiness(business: BusinessEntity): Long = withContext(Dispatchers.IO) {
        dao.insertOrUpdateBusiness(business)
    }

    override fun getInvoiceSettings(): Flow<InvoiceSettingsEntity?> = dao.getInvoiceSettingsFlow()

    override suspend fun saveInvoiceSettings(settings: InvoiceSettingsEntity): Long = withContext(Dispatchers.IO) {
        dao.insertOrUpdateInvoiceSettings(settings)
    }

    override fun getAppSettings(): Flow<AppSettingsEntity?> = dao.getAppSettingsFlow()

    override suspend fun saveAppSettings(settings: AppSettingsEntity): Long = withContext(Dispatchers.IO) {
        dao.insertOrUpdateAppSettings(settings)
    }

    override suspend fun loadDemoData(): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            DemoDataPopulator.populateDemoStore(database)
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun clearDemoData(): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            DemoDataPopulator.clearAllData(database)
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
