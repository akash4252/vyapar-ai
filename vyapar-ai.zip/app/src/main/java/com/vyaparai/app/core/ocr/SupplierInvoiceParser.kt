package com.vyaparai.app.core.ocr

data class ExtractedSupplierInvoice(
    val supplierName: String?,
    val invoiceNumber: String?,
    val invoiceDate: String?,
    val items: List<ExtractedInvoiceItem>,
    val totalAmount: Double?
)

data class ExtractedInvoiceItem(
    val productName: String,
    val quantity: Double,
    val unit: String = "pcs",
    val purchasePrice: Double,
    val gstRate: Double = 0.0,
    val hsn: String? = null
)

object SupplierInvoiceParser {

    fun parseOcrText(rawText: String): ExtractedSupplierInvoice {
        val lines = rawText.lines().map { it.trim() }.filter { it.isNotBlank() }

        var supplierName: String? = null
        var invoiceNumber: String? = null
        var invoiceDate: String? = null
        var totalAmount: Double? = null
        val items = mutableListOf<ExtractedInvoiceItem>()

        val invoiceNoRegex = Regex("""(?:Inv(?:oice)?\s*(?:No|#|\.)?[:\s]*)([A-Za-z0-9\-_/]+)""", RegexOption.IGNORE_CASE)
        val dateRegex = Regex("""(?:Date[:\s]*)([0-9]{1,2}[\-/.][0-9]{1,2}[\-/.][0-9]{2,4})""", RegexOption.IGNORE_CASE)
        val totalRegex = Regex("""(?:Total|Grand Total|Net Amount|Amount Payable)[:\s]*₹?\s*([0-9,]+(?:\.[0-9]{2})?)""", RegexOption.IGNORE_CASE)

        for ((index, line) in lines.withIndex()) {
            // First 3 non-empty lines are often company/supplier header
            if (supplierName == null && index < 3 && !line.contains("Invoice", true) && !line.contains("GST", true)) {
                supplierName = line
            }

            if (invoiceNumber == null) {
                val match = invoiceNoRegex.find(line)
                if (match != null) invoiceNumber = match.groupValues[1]
            }

            if (invoiceDate == null) {
                val match = dateRegex.find(line)
                if (match != null) invoiceDate = match.groupValues[1]
            }

            if (totalAmount == null) {
                val match = totalRegex.find(line)
                if (match != null) {
                    val rawNum = match.groupValues[1].replace(",", "")
                    totalAmount = rawNum.toDoubleOrNull()
                }
            }

            // Line items extraction heuristic: Line containing Name, Quantity and Price
            // e.g. "Maggi Noodles 70g  10  8.00  80.00" or "Tata Salt 1kg x 5 @ 20 = 100"
            val itemPattern = Regex("""^([A-Za-z0-9\s\-]+?)\s+(\d+(?:\.\d+)?)\s+(?:pcs|kg|pkt)?\s*[x@\s]\s*₹?(\d+(?:\.\d+)?)""")
            val itemMatch = itemPattern.find(line)
            if (itemMatch != null) {
                val name = itemMatch.groupValues[1].trim()
                val qty = itemMatch.groupValues[2].toDoubleOrNull() ?: 1.0
                val price = itemMatch.groupValues[3].toDoubleOrNull() ?: 0.0
                if (name.length > 2 && price > 0) {
                    items.add(ExtractedInvoiceItem(productName = name, quantity = qty, purchasePrice = price))
                }
            }
        }

        return ExtractedSupplierInvoice(
            supplierName = supplierName,
            invoiceNumber = invoiceNumber,
            invoiceDate = invoiceDate,
            items = items,
            totalAmount = totalAmount
        )
    }
}
