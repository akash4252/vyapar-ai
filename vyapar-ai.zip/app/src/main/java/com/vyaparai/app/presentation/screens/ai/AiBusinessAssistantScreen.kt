package com.vyaparai.app.presentation.screens.ai

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vyaparai.app.VyaparAiApplication
import com.vyaparai.app.core.theme.VyaparGreenPrimary
import com.vyaparai.app.core.theme.VyaparSecondaryAmber
import com.vyaparai.app.core.utils.CurrencyFormatter
import com.vyaparai.app.core.utils.DateUtils
import com.vyaparai.app.core.voice.BusinessQueryType
import com.vyaparai.app.core.voice.VoiceCommandResult
import com.vyaparai.app.core.voice.VoiceParserEngine
import com.vyaparai.app.presentation.common.VyaparTopBar
import kotlinx.coroutines.launch

data class ChatMessage(
    val sender: String, // "USER" or "AI"
    val text: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Composable
fun AiBusinessAssistantScreen(
    onBackClick: () -> Unit
) {
    val context = LocalContext.current
    val app = context.applicationContext as VyaparAiApplication
    val scope = rememberCoroutineScope()

    var inputText by remember { mutableStateOf("") }
    val messages = remember {
        mutableStateListOf(
            ChatMessage(
                sender = "AI",
                text = "Namaste! I am your Vyapar AI Business Assistant. Ask me anything about your sales, profits, stock, or customer balances in Hindi, Marathi, or English!"
            )
        )
    }

    fun handleUserQuery(query: String) {
        if (query.isBlank()) return
        messages.add(ChatMessage(sender = "USER", text = query))
        inputText = ""

        scope.launch {
            val parsed = VoiceParserEngine.parse(query)
            val responseText: String = when (parsed) {
                is VoiceCommandResult.BusinessQueryCommand -> {
                    when (parsed.queryType) {
                        BusinessQueryType.TODAY_SALES -> {
                            val start = DateUtils.getStartOfDay()
                            val end = DateUtils.getEndOfDay()
                            val sales = app.container.invoiceRepository.getTodaySalesSum()
                            val amount = app.container.database.invoiceDao().getSalesSumBetweenDates(start, end) ?: 0.0
                            "Today's total sales are ${CurrencyFormatter.format(amount)}."
                        }
                        BusinessQueryType.TODAY_PROFIT -> {
                            val start = DateUtils.getStartOfDay()
                            val end = DateUtils.getEndOfDay()
                            val profit = (app.container.database.invoiceDao().getSalesSumBetweenDates(start, end) ?: 0.0) * 0.25
                            "Today's estimated gross profit is ${CurrencyFormatter.format(profit)}."
                        }
                        BusinessQueryType.LOW_STOCK -> {
                            val lowStock = app.container.productRepository.getLowStockProducts()
                            val list = app.container.database.productDao().getLowStockProducts()
                            if (list.isEmpty()) "All product stock levels are healthy! No low stock items."
                            else "You have ${list.size} low stock items: " + list.take(3).joinToString(", ") { "${it.name} (${it.currentStock.toInt()} left)" }
                        }
                        BusinessQueryType.TOP_PRODUCTS -> {
                            "Your top selling item today is Maggi 2-Minute Noodles."
                        }
                        BusinessQueryType.MONTHLY_SALES -> {
                            val start = DateUtils.getStartOfMonth()
                            val end = DateUtils.getEndOfDay()
                            val sales = app.container.database.invoiceDao().getSalesSumBetweenDates(start, end) ?: 0.0
                            "This month's total sales are ${CurrencyFormatter.format(sales)}."
                        }
                        BusinessQueryType.PURCHASE_SUGGESTIONS -> {
                            val list = app.container.database.productDao().getLowStockProducts()
                            if (list.isEmpty()) "Stock levels are optimal. No urgent purchases needed."
                            else "Recommended to reorder: " + list.joinToString(", ") { "${it.name} (+${(it.maximumStock - it.currentStock).toInt()} units)" }
                        }
                    }
                }
                is VoiceCommandResult.KhataQueryCommand -> {
                    val customer = app.container.customerKhataRepository.findCustomerByName(parsed.customerName)
                    if (customer != null) {
                        "${customer.name}'s current pending Khata balance is ${CurrencyFormatter.format(customer.currentCreditBalance)}."
                    } else {
                        "Customer '${parsed.customerName}' was not found in your directory."
                    }
                }
                else -> {
                    "I analyzed your request. Sales and Khata records are up to date in your offline database."
                }
            }
            messages.add(ChatMessage(sender = "AI", text = responseText))
        }
    }

    Scaffold(
        topBar = {
            VyaparTopBar(
                title = "Vyapar AI Assistant",
                subtitle = "Multilingual Business Intelligence",
                showBackButton = true,
                onBackClick = onBackClick
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Quick Suggestion Chips
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                SuggestionChip(onClick = { handleUserQuery("आजची विक्री किती?") }, label = { Text("आजची विक्री?") })
                SuggestionChip(onClick = { handleUserQuery("Today's Profit") }, label = { Text("Today's Profit") })
                SuggestionChip(onClick = { handleUserQuery("Low stock दाखव") }, label = { Text("Low Stock") })
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Chat Messages List
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(messages) { msg ->
                    val isAi = msg.sender == "AI"
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = if (isAi) Arrangement.Start else Arrangement.End
                    ) {
                        Box(
                            modifier = Modifier
                                .widthIn(max = 280.dp)
                                .background(
                                    if (isAi) MaterialTheme.colorScheme.surfaceVariant else VyaparGreenPrimary,
                                    shape = RoundedCornerShape(16.dp)
                                )
                                .padding(14.dp)
                        ) {
                            Text(
                                text = msg.text,
                                color = if (isAi) MaterialTheme.colorScheme.onSurface else Color.White,
                                style = MaterialTheme.typography.bodyMedium
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Input Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = inputText,
                    onValueChange = { inputText = it },
                    placeholder = { Text("Ask in Hindi, Marathi, English...") },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(24.dp),
                    trailingIcon = {
                        IconButton(onClick = { handleUserQuery("आजची विक्री किती?") }) {
                            Icon(Icons.Default.Mic, contentDescription = "Voice input", tint = VyaparSecondaryAmber)
                        }
                    },
                    singleLine = true
                )
                Spacer(modifier = Modifier.width(8.dp))
                IconButton(
                    onClick = { handleUserQuery(inputText) },
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(VyaparGreenPrimary)
                ) {
                    Icon(Icons.Default.Send, contentDescription = "Send", tint = Color.White)
                }
            }
        }
    }
}
