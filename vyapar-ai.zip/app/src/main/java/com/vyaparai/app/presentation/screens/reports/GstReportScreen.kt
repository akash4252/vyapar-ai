package com.vyaparai.app.presentation.screens.reports

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vyaparai.app.VyaparAiApplication
import com.vyaparai.app.core.theme.VyaparGreenPrimary
import com.vyaparai.app.core.theme.VyaparTertiaryBlue
import com.vyaparai.app.core.utils.CurrencyFormatter
import com.vyaparai.app.presentation.common.StatCard
import com.vyaparai.app.presentation.common.VyaparTopBar

@Composable
fun GstReportScreen(
    onBackClick: () -> Unit
) {
    val context = LocalContext.current
    val app = context.applicationContext as VyaparAiApplication

    val invoices by app.container.invoiceRepository.getAllInvoices().collectAsState(initial = emptyList())

    val totalTaxable = invoices.sumOf { it.invoice.subtotal }
    val totalCgst = invoices.sumOf { it.invoice.cgst }
    val totalSgst = invoices.sumOf { it.invoice.sgst }
    val totalIgst = invoices.sumOf { it.invoice.igst }
    val totalGstCollected = totalCgst + totalSgst + totalIgst

    Scaffold(
        topBar = {
            VyaparTopBar(
                title = "GST Tax Report",
                subtitle = "GSTR-1 Sales Summary",
                showBackButton = true,
                onBackClick = onBackClick
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            StatCard(
                title = "Total GST Tax Collected",
                value = CurrencyFormatter.format(totalGstCollected),
                subtitle = "Across ${invoices.size} invoices",
                iconTint = VyaparTertiaryBlue,
                modifier = Modifier.fillMaxWidth()
            )

            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("GST Breakdown", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                    HorizontalDivider()

                    GstTaxRow("Total Taxable Value", CurrencyFormatter.format(totalTaxable))
                    GstTaxRow("Central GST (CGST)", CurrencyFormatter.format(totalCgst))
                    GstTaxRow("State GST (SGST)", CurrencyFormatter.format(totalSgst))
                    GstTaxRow("Integrated GST (IGST)", CurrencyFormatter.format(totalIgst))

                    HorizontalDivider()
                    GstTaxRow("Total Tax Liability", CurrencyFormatter.format(totalGstCollected), isBold = true)
                }
            }
        }
    }
}

@Composable
private fun GstTaxRow(label: String, value: String, isBold: Boolean = false) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = label, fontWeight = if (isBold) FontWeight.Bold else FontWeight.Normal)
        Text(text = value, fontWeight = if (isBold) FontWeight.ExtraBold else FontWeight.Bold, color = if (isBold) VyaparGreenPrimary else MaterialTheme.colorScheme.onSurface)
    }
}
